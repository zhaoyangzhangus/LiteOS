#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-.}"
TARGET="$ROOT/kernel/drivers/xhci.c"
PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH="$PATCH_DIR/LiteOS_xhci_B10B_hotplug_SAFE_FIX2.patch"

cd "$ROOT"

if [ ! -f "kernel/drivers/xhci.c" ]; then
    echo "ERROR: kernel/drivers/xhci.c not found"
    exit 1
fi

current="$(git hash-object kernel/drivers/xhci.c)"

if [ "$current" != "87cb66d92058744e1f2746400ae80c67cf425d35" ]; then
    echo "ERROR: source is not the expected clean GitHub version."
    echo "current : $current"
    echo "expected: 87cb66d92058744e1f2746400ae80c67cf425d35"
    echo
    echo "If the previous FIX1 package is currently applied, restore first:"
    echo "  git restore kernel/drivers/xhci.c"
    exit 2
fi

git apply --check "$PATCH"
git apply "$PATCH"

after="$(git hash-object kernel/drivers/xhci.c)"
if [ "$after" != "53d0c672abeb8a0b622431ecdb8676ccf1d8eef2" ]; then
    echo "ERROR: patched blob mismatch: $after"
    exit 3
fi

echo "PASS: LiteOS xHCI B10B SAFE FIX2 installed"
echo "blob: $after"
