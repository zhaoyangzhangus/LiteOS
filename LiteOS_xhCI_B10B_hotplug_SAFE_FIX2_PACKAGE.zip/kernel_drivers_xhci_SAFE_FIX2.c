#include <arch/x86_64/paging.h>
#include <usb/device.h>
#include <usb/hub.h>

#include <arch/x86_64/cpu.h>
#include <kernel/dma.h>
#include <kernel/kmem.h>
#include <kernel/input.h>
#include <kernel/bluetooth.h>
#include <kernel/audio.h>
#include <kernel/deferred.h>
#include <kernel/console.h>
#include <kernel/irq.h>
#include <kernel/pci.h>
#include <kernel/xhci.h>

#define XHCI_CLASS_SERIAL_BUS 0x0CU
#define XHCI_SUBCLASS_USB     0x03U
#define XHCI_PROG_IF         0x30U

#define XHCI_MMIO_VA          (X86_64_MMIO_BASE + 0x14000000ULL)
#define XHCI_MMIO_MAX_SIZE    0x00100000ULL
#define XHCI_RING_TRB_COUNT   256U
#define XHCI_COMMAND_RING_TYPE 9U
#define XHCI_ADDRESS_DEVICE_TYPE 11U
#define XHCI_CONFIGURE_ENDPOINT_TYPE 12U
#define XHCI_SET_TR_DEQUEUE_POINTER_TYPE 16U
#define XHCI_RESET_ENDPOINT_TYPE 14U
#define XHCI_STOP_ENDPOINT_TYPE 15U
#define XHCI_DISABLE_SLOT_TYPE 10U
#define XHCI_LINK_TRB_TYPE     6U
#define XHCI_NORMAL_TRB_TYPE   1U
#define XHCI_ISOCH_TRB_TYPE    5U
#define XHCI_SETUP_STAGE_TYPE  2U
#define XHCI_DATA_STAGE_TYPE   3U
#define XHCI_STATUS_STAGE_TYPE 4U
#define XHCI_TRANSFER_EVENT_TYPE 32U
#define XHCI_COMMAND_COMPLETION_TYPE 33U

#define XHCI_USBCMD            0x00U
#define XHCI_USBSTS            0x04U
#define XHCI_PAGESIZE          0x08U
#define XHCI_CRCR              0x18U
#define XHCI_DCBAAP            0x30U
#define XHCI_CONFIG            0x38U
#define XHCI_PORT_REGISTER_BASE 0x400U
#define XHCI_PORT_REGISTER_STRIDE 0x10U

#define XHCI_USBCMD_RUN        (1U << 0)
#define XHCI_USBCMD_HCRST      (1U << 1)
#define XHCI_USBCMD_INTE       (1U << 2)
#define XHCI_USBSTS_HCH        (1U << 0)
#define XHCI_USBSTS_CNR        (1U << 11)

#define XHCI_RUNTIME_IMAN      0x00U
#define XHCI_RUNTIME_ERSTSZ    0x08U
#define XHCI_RUNTIME_ERSTBA    0x10U
#define XHCI_RUNTIME_ERDP      0x18U
#define XHCI_RUNTIME_INTR0     0x20U
#define XHCI_IMAN_IE           (1U << 1)
#define XHCI_IMAN_IP           (1U << 0)
#define XHCI_ERDP_EHB          (1ULL << 3)

#define XHCI_TRB_CYCLE         (1U << 0)
#define XHCI_TRB_CHAIN         (1U << 4)
#define XHCI_TRB_INTERRUPT_ON_COMPLETION (1U << 5)
#define XHCI_TRB_IMMEDIATE_DATA (1U << 6)
#define XHCI_TRB_DIRECTION_IN  (1U << 16)
#define XHCI_TRB_SIA           (1U << 31)
#define XHCI_TRB_LINK_TOGGLE_CYCLE (1U << 1)
#define XHCI_TRB_TRANSFER_TYPE_SHIFT 16U
#define XHCI_TRB_TYPE_SHIFT    10U
#define XHCI_TRB_SLOT_SHIFT    24U
#define XHCI_TRB_ENDPOINT_SHIFT 16U
#define XHCI_COMPLETION_SHIFT  24U
#define XHCI_COMPLETION_SUCCESS 1U
/* Interrupt-IN devices may legally return less than wMaxPacketSize.  The
 * xHCI completion code for that case is Short Packet; it is a completed
 * transfer, not an endpoint failure. */
#define XHCI_COMPLETION_SHORT_PACKET 13U
#define XHCI_PORT_STATUS_CHANGE_TYPE 34U

#define XHCI_PORTSC_CCS        (1U << 0)
#define XHCI_PORTSC_PED        (1U << 1)
#define XHCI_PORTSC_PR         (1U << 4)
#define XHCI_PORTSC_SPEED_SHIFT 10U
#define XHCI_PORTSC_SPEED_MASK 0x0FU
#define XHCI_PORTSC_PRC        (1U << 21)

#define XHCI_SETUP_GET_DESCRIPTOR 6U
#define XHCI_SETUP_GET_STATUS     0U
#define XHCI_SETUP_SET_FEATURE    3U
#define XHCI_SETUP_SET_CONFIGURATION 9U
#define XHCI_SETUP_SET_INTERFACE 11U
#define XHCI_DESCRIPTOR_DEVICE    1U
#define XHCI_DESCRIPTOR_CONFIGURATION 2U
#define XHCI_DESCRIPTOR_INTERFACE 4U
#define XHCI_DESCRIPTOR_ENDPOINT 5U
#define XHCI_DESCRIPTOR_CS_INTERFACE 0x24U
#define XHCI_DESCRIPTOR_HUB       0x29U
#define XHCI_DESCRIPTOR_DEVICE_LENGTH 18U
#define XHCI_CONTROL_TRANSFER_IN 3U
#define XHCI_CONTROL_TRANSFER_OUT 2U

#define USB_CLASS_AUDIO           0x01U
#define USB_AUDIO_SUBCLASS_STREAM 0x02U
#define USB_CLASS_HID             0x03U
#define USB_HID_SUBCLASS_BOOT      0x01U
#define USB_HID_PROTOCOL_KEYBOARD  0x01U
#define USB_HID_PROTOCOL_MOUSE     0x02U
#define USB_HID_SET_PROTOCOL       0x0BU
#define USB_HID_PROTOCOL_BOOT      0x00U
#define USB_CLASS_HUB             0x09U
#define USB_CLASS_WIRELESS        0xE0U
#define USB_BT_SUBCLASS           0x01U
#define USB_BT_PROTOCOL           0x01U
#define USB_TRANSFER_BULK         0x02U
#define USB_TRANSFER_INTERRUPT    0x03U
#define USB_TRANSFER_ISOCHRONOUS  0x01U
#define USB_HUB_FEATURE_PORT_RESET 4U
#define USB_HUB_FEATURE_PORT_POWER 8U

/*
 * V3.10.6B10B2-FIX3 SLOT HUB AND TT SEMANTICS
 *
 * xHCI Slot Context:
 *
 * DW0 bit 25  = MTT
 * DW0 bit 26  = Hub
 * DW1 31:24   = Number of Ports
 * DW2  7:0    = TT Hub Slot ID
 * DW2 15:8    = TT Port Number
 * DW2 17:16   = TT Think Time
 */
#define XHCI_SLOT_MTT                 (1U << 25)
#define XHCI_SLOT_HUB                 (1U << 26)
#define XHCI_SLOT_MAX_PORTS_SHIFT     24U
#define XHCI_SLOT_TT_PORT_SHIFT       8U
#define XHCI_SLOT_TT_THINK_SHIFT      16U

#define USB_HUB_PROTOCOL_MULTI_TT     2U


#define XHCI_DEFERRED_EVENT_COUNT 32U

typedef struct __attribute__((packed)) xhci_trb {
    uint64_t parameter;
    uint32_t status;
    uint32_t control;
} xhci_trb_t;

_Static_assert(sizeof(xhci_trb_t) == 16U, "xHCI TRB ABI");

typedef struct __attribute__((packed)) xhci_erst_entry {
    uint64_t ring_segment_base;
    uint16_t ring_segment_size;
    uint16_t reserved0;
    uint32_t reserved1;
} xhci_erst_entry_t;

_Static_assert(sizeof(xhci_erst_entry_t) == 16U, "xHCI ERST ABI");

typedef struct xhci_dma_page {
    page_t *page;
    dma_mapping_t mapping;
    void *cpu;
} xhci_dma_page_t;

#define XHCI_DEVICE_FIELDS \
    xhci_dma_page_t input_context; \
    xhci_dma_page_t output_context; \
    xhci_dma_page_t ep0_ring; \
    xhci_dma_page_t descriptor_buffer; \
    xhci_dma_page_t hid_ring; \
    xhci_dma_page_t hid_report; \
    xhci_dma_page_t audio_ring; \
    xhci_dma_page_t audio_buffer; \
    xhci_dma_page_t bt_event_ring; \
    xhci_dma_page_t bt_event_buffer; \
    xhci_dma_page_t bt_acl_in_ring; \
    xhci_dma_page_t bt_acl_in_buffer; \
    xhci_dma_page_t bt_acl_out_ring; \
    xhci_dma_page_t bt_acl_out_buffer; \
    xhci_dma_page_t hub_ring; \
    xhci_dma_page_t hub_report; \
    uint8_t device_slot; \
    uint8_t device_port; \
    uint8_t device_speed; \
    uint8_t root_port; \
    uint8_t parent_slot; \
    uint8_t parent_port; \
    uint32_t route_string; \
    uint32_t ep0_enqueue; \
    uint8_t configuration_value; \
    uint8_t hid_interface; \
    uint8_t hid_protocol; \
    uint8_t hid_endpoint; \
    uint16_t hid_max_packet; \
    uint8_t hid_interval; \
    uint32_t hid_enqueue; \
    uint8_t hid_cycle; \
    bool hid_transfer_pending; \
    uint8_t hid_previous_modifier; \
    uint8_t hid_previous_keys[6]; \
    uint8_t hid_previous_buttons; \
    uint8_t audio_interface; \
    uint8_t audio_alt_setting; \
    uint8_t audio_endpoint; \
    uint8_t audio_interval; \
    uint16_t audio_max_packet; \
    uint8_t audio_channels; \
    uint8_t audio_bit_resolution; \
    uint32_t audio_sample_rate; \
    bool audio_endpoint_in; \
    uint32_t audio_enqueue; \
    uint8_t audio_cycle; \
    bool audio_transfer_pending; \
    uint32_t audio_completed; \
    audio_stream_t *audio_stream; \
    uint32_t audio_period; \
    uint32_t audio_frames; \
    bool audio_stream_running; \
    bool audio_stream_queued; \
    bool audio_stream_bound; \
    uint8_t hub_interface; \
    bool hub_interface_present; \
    uint8_t hub_port_count; \
    uint8_t hub_protocol; \
    uint8_t hub_tt_think_time; \
    bool hub_configured; \
    uint8_t hub_endpoint; \
    uint16_t hub_max_packet; \
    uint8_t hub_interval; \
    uint32_t hub_enqueue; \
    uint8_t hub_cycle; \
    bool hub_transfer_pending; \
    uint32_t hub_change_bitmap; \
    uint8_t bt_event_endpoint; \
    uint8_t bt_acl_in_endpoint; \
    uint8_t bt_acl_out_endpoint; \
    uint8_t bt_event_interval; \
    uint16_t bt_event_max_packet; \
    uint16_t bt_acl_in_max_packet; \
    uint16_t bt_acl_out_max_packet; \
    uint32_t bt_event_enqueue; \
    uint8_t bt_event_cycle; \
    bool bt_event_transfer_pending; \
    uint32_t bt_acl_in_enqueue; \
    uint8_t bt_acl_in_cycle; \
    bool bt_acl_in_transfer_pending; \
    uint32_t bt_acl_out_enqueue; \
    uint8_t bt_acl_out_cycle; \
    bool bt_acl_out_transfer_pending; \
    bt_controller_t *bt_controller;

typedef struct xhci_device_context {
    XHCI_DEVICE_FIELDS
} xhci_device_context_t;

/*
 * Canonical xHCI Slot Table.
 *
 * A published Slot owns its permanent xhci_device_context_t.
 * Topology, runtime event routing and teardown all begin from
 * hardware Slot ID.
 */

#define XHCI_MAX_SLOT_TABLE 256U


typedef struct xhci_slot_device {

    bool used;

    uint8_t slot_id;

    uint8_t speed;

    uint8_t device_class;

    uint8_t device_protocol;


    uint8_t parent_slot;

    uint8_t parent_port;

    uint8_t root_port;


    uint32_t route_string;


    uint8_t tt_slot;

    uint8_t tt_port;

    bool tt_multi;


    bool is_hub;

    uint8_t hub_port_count;

    uint8_t hub_protocol;


    /*
     * Downstream device slots.
     *
     * Index:
     *   port number - 1
     *
     * Value:
     *   child Slot ID
     */
    uint8_t child_slots[16];


    xhci_device_context_t context;



    /*
     * V3.10.6B8A SLOT INVENTORY LOCATOR REMOVED
     *
     * Published device identity is permanently:
     *
     *     Slot ID -> Slot.context
     *
     * There is no secondary context-location state.
     */


} xhci_slot_device_t;


static xhci_slot_device_t
g_xhci_slot_devices[
    XHCI_MAX_SLOT_TABLE]
    __attribute__((used));

/*
 * V3.10.6B8B INVENTORY CONTEXT SHADOW REMOVED
 * V3.10.6B8C INVENTORY REMOVED
 *
 * Slot Table is the sole directory for published USB devices.
 * No secondary device directory or context store exists.
 */


/*
 * V3.10.6B8I COMMENT BASELINE
 *
 * state->device is enumeration working storage.
 * g_xhci_slot_devices[slot].context is published runtime state.
 */
typedef struct xhci_state {
    const pci_device_t *pci;
    volatile uint8_t *mmio;
    uint64_t mmio_span;
    uint32_t operational_offset;
    uint32_t runtime_offset;
    uint32_t doorbell_offset;
    uint32_t max_slots;
    uint32_t max_ports;
    uint32_t context_size;
    uint32_t command_index;
    uint8_t command_cycle;
    uint32_t event_index;
    uint8_t event_cycle;
    xhci_dma_page_t dcbaa;
    xhci_dma_page_t command_ring;
    xhci_dma_page_t event_ring;
    xhci_dma_page_t erst;
    union {
        xhci_device_context_t device;
        struct { XHCI_DEVICE_FIELDS };
    };
    /* 同步控制传输期间到达的异步事件暂存于此，避免被等待循环丢弃。 */
    xhci_trb_t deferred_events[XHCI_DEFERRED_EVENT_COUNT];
    uint32_t deferred_event_head;
    uint32_t deferred_event_tail;
    uint32_t deferred_event_count;
    spinlock_t event_lock;
    uint8_t irq_vector;
    bool initialized;
} xhci_state_t;

/*
 * V3.10.6B8D SLOT CONTEXT MIRROR REMOVED
 * V3.10.6B8G HID-ONLY WORKING CONTEXT FALLBACK
 *
 * Ownership invariant:
 *
 *   published device
 *       -> g_xhci_slot_devices[slot].context
 *
 *   unpublished enumeration transaction
 *       -> state->device
 *
 * HID alone may resolve state->device for a pre-publication
 * interrupt completion. Published Slot.context always wins.
 */


#undef XHCI_DEVICE_FIELDS

static xhci_state_t g_xhci;

/*
 * V3.7.7 BT SLOT TRANSPORT
 *
 * Bluetooth Core callbacks must identify a USB device by its
 * permanent xHCI Slot ID, never by whichever context happens
 * to be installed in state->device.
 */
typedef struct xhci_bt_transport {
    xhci_state_t *state;
    uint8_t slot;
} xhci_bt_transport_t;


static xhci_bt_transport_t
g_xhci_bt_transports[
    XHCI_MAX_SLOT_TABLE];


static uint32_t g_xhci_error;
/* HID recovery diagnostics: counters only, never printed from IRQ/deferred
 * context.  A nonzero failure stage is retained for debugger inspection. */
static volatile uint32_t g_xhci_hid_recovery_attempts;
static volatile uint32_t g_xhci_hid_recovery_failures;
static volatile uint32_t g_xhci_hid_recovery_stage;
static volatile uint32_t g_xhci_hid_recovery_command_error;
static bool g_xhci_present;
static bool g_xhci_usb_enumerated;
static uint32_t g_xhci_usb_device_count;
static bool g_xhci_usb_hid;
static bool g_xhci_usb_mouse;
static bool g_xhci_usb_audio;
static uint8_t g_xhci_audio_slot;
static bool g_xhci_usb_hub;
static uint8_t g_xhci_usb_hub_ports;
static bool g_xhci_usb_hub_present;
static uint8_t g_xhci_usb_hub_inventory_ports;
static bool g_xhci_usb_hub_downstream;
static bool g_xhci_usb_bluetooth;
static bool g_xhci_runtime_ready;
static uint32_t g_xhci_runtime_event_batches;
static atomic_bool g_xhci_work_queued;
static atomic_bool g_xhci_irq_pending;
static atomic_bool g_xhci_input_seen;
static atomic_bool g_xhci_mouse_input_seen;
static atomic_bool g_xhci_irq_seen;
static atomic_bool g_xhci_hid_transfer_seen;
/* Runtime-only completion counter used by the wrap regression test. */
static atomic_uint g_xhci_hid_completion_count;
static atomic_uint g_xhci_hid_completion_milestone;

static bool xhci_submit_command(xhci_state_t *state, uint32_t type,
                                uint8_t slot, uint64_t parameter,
                                uint8_t *result_slot);
static bool xhci_submit_command_ex(xhci_state_t *state, uint32_t type,
                                   uint8_t slot, uint8_t endpoint,
                                   uint64_t parameter, uint8_t *result_slot);
static bool xhci_enumerate_device(xhci_state_t *state, uint8_t slot,
                                  uint8_t port, uint8_t speed,
                                  uint8_t root_port, uint8_t parent_slot,
                                  uint8_t parent_port, uint32_t route_string);
static bool xhci_handle_bt_transfer_event(xhci_state_t *state,
                                          const xhci_trb_t *event);
static bool xhci_handle_hub_transfer_event(xhci_state_t *state,
                                           const xhci_trb_t *event);
static bool xhci_probe_hub_downstream(xhci_state_t *state);
static bool xhci_find_hub_child(
    uint8_t parent_slot,
    uint8_t parent_port,
    uint8_t *child_slot);
static bool xhci_handle_root_port_event(xhci_state_t *state, uint8_t port,
                                        uint32_t portsc);
static bool xhci_reconcile_hub_topology(xhci_state_t *state);
static bool xhci_remove_device_subtree(
    xhci_state_t *state,
    uint8_t slot);
static void xhci_msix_handler(uint8_t vector, struct arch_trap_frame *frame,
                              void *context);
static bool xhci_bind_msix(xhci_state_t *state);
static void xhci_unbind_msix(xhci_state_t *state);
static void xhci_init_ring_link(xhci_dma_page_t *ring);
static void xhci_init_endpoint_context(xhci_state_t *state, uint32_t *endpoint,
                                       uint8_t interval, uint8_t type,
                                       uint16_t max_packet,
                                       const dma_mapping_t *ring);
static bool xhci_write32(const xhci_state_t *state, uint32_t offset,
                         uint32_t value);
static bool xhci_write64(const xhci_state_t *state, uint32_t offset,
                         uint64_t value);
static uint64_t xhci_dma_address(const dma_mapping_t *mapping);
static bool xhci_event_pending(const xhci_state_t *state);
static void xhci_event_handler_complete(xhci_state_t *state);
static void xhci_report_hid_completion_milestones(void);

static void xhci_msix_handler(uint8_t vector, struct arch_trap_frame *frame,
                              void *context) {
    xhci_state_t *state = (xhci_state_t *)context;
    (void)vector;
    (void)frame;
    if (state == 0 || !state->initialized || state->irq_vector == 0U) return;
    if (!atomic_exchange_explicit(&g_xhci_irq_seen, true,
                                  memory_order_acq_rel)) {
        liteos_serial_write("LITEOS_XHCI_IRQ_FIRED\r\n");
    }
    /* The ISR only acknowledges the interrupter and queues bounded work.  It
     * never walks the event ring or emits user input at interrupt level. */
    /* IMAN.IP is RW1C.  Clear the pending bit while retaining IE; leaving IP
     * set after the first HID completion makes QEMU suppress subsequent
     * interrupt edges, leaving hid_transfer_pending stuck forever. */
    (void)xhci_write32(state, state->runtime_offset + XHCI_RUNTIME_INTR0,
                       XHCI_IMAN_IP | XHCI_IMAN_IE);
    atomic_store_explicit(&g_xhci_irq_pending, true, memory_order_release);
    (void)xhci_schedule_deferred_work();
}

static bool xhci_bind_msix(xhci_state_t *state) {
    paddr_t table;
    uint16_t entries;
    uint8_t vector = 0x58U;
    if (state == 0 || state->pci == 0 ||
        pci_msix_table(state->pci, &table, &entries) != K_OK ||
        entries == 0U || vector > IRQ_VECTOR_LAST) return false;
    /* Enumeration may have left the interrupter pending while MSI-X was
     * disabled.  Clear that stale edge before enabling the PCI vector; new
     * transfer completions will then generate a fresh interrupt. */
    xhci_event_handler_complete(state);
    if (!xhci_write32(state, state->runtime_offset + XHCI_RUNTIME_INTR0,
                      XHCI_IMAN_IP | XHCI_IMAN_IE)) return false;
    if (irq_register(vector, xhci_msix_handler, state) != K_OK) return false;
    state->irq_vector = vector;
    if (pci_msix_configure((pci_device_t *)state->pci, 0U,
                           x86_current_apic_id(), vector) != K_OK ||
        pci_msix_mask((pci_device_t *)state->pci, 0U, false) != K_OK) {
        (void)irq_unregister(vector, xhci_msix_handler, state);
        state->irq_vector = 0U;
        return false;
    }
    return true;
}

static void xhci_unbind_msix(xhci_state_t *state) {
    if (state == 0 || state->irq_vector == 0U) return;
    (void)pci_msix_mask((pci_device_t *)state->pci, 0U, true);
    (void)irq_unregister(state->irq_vector, xhci_msix_handler, state);
    state->irq_vector = 0U;
}

static bool xhci_event_pending(const xhci_state_t *state) {
    const volatile xhci_trb_t *event_ring;
    uint32_t control;
    if (state == 0 || !state->initialized) return false;
    if (state->deferred_event_count != 0U) return true;
    event_ring = (const volatile xhci_trb_t *)state->event_ring.cpu;
    if (event_ring == 0) return false;
    dma_sync_for_cpu((dma_mapping_t *)&state->event_ring.mapping);
    control = event_ring[state->event_index].control;
    return (control & XHCI_TRB_CYCLE) == state->event_cycle;
}

static void xhci_event_handler_complete(xhci_state_t *state) {
    uint64_t dequeue;
    if (state == 0 || !state->initialized) return;
    dequeue = xhci_dma_address(&state->event_ring.mapping) +
              (uint64_t)state->event_index * sizeof(xhci_trb_t);
    /* EHB is RW1C: software must write one to clear the controller's event
     * handler busy state after consuming a batch.  Writing ERDP without EHB
     * leaves the bit set on QEMU and suppresses all later HID interrupts. */
    (void)xhci_write64(state, state->runtime_offset + XHCI_RUNTIME_INTR0 +
                       XHCI_RUNTIME_ERDP, dequeue | XHCI_ERDP_EHB);
    (void)xhci_write32(state, state->runtime_offset + XHCI_RUNTIME_INTR0,
                       XHCI_IMAN_IP | XHCI_IMAN_IE);
}

static void xhci_zero_device_context(xhci_device_context_t *context) {
    if (context == 0) return;
    for (size_t i = 0; i < sizeof(*context); ++i) {
        ((uint8_t *)context)[i] = 0U;
    }
}


/*
 * V3.10.6B8B
 *
 * xhci_copy_device_context() removed.
 * No published device context is copied between ownership stores.
 */


static void xhci_clear_device_flags(void) {
    g_xhci_usb_enumerated = false;
    g_xhci_usb_hid = false;
    g_xhci_usb_mouse = false;
    g_xhci_usb_audio = false;
    g_xhci_usb_hub = false;
    g_xhci_usb_hub_ports = 0U;
    g_xhci_usb_bluetooth = false;
}

/*
 * V3.10.6B9C-FIX1
 *
 * xhci_set_device_kind() removed.
 * Published runtime state is recomputed from Slot Table.
 */


static uint64_t xhci_dma_address(const dma_mapping_t *mapping) {
    return mapping != 0 && mapping->segment_count != 0 ?
           mapping->segments[0].addr.value : 0;
}

static uint32_t xhci_read32(const xhci_state_t *state, uint32_t offset) {
    if (state == 0 || state->mmio == 0 || offset > state->mmio_span - sizeof(uint32_t)) {
        return UINT32_MAX;
    }
    return *(volatile const uint32_t *)(state->mmio + offset);
}

static bool xhci_write32(const xhci_state_t *state, uint32_t offset, uint32_t value) {
    if (state == 0 || state->mmio == 0 || offset > state->mmio_span - sizeof(uint32_t)) {
        return false;
    }
    *(volatile uint32_t *)(state->mmio + offset) = value;
    __asm__ volatile ("mfence" : : : "memory");
    return true;
}

static bool xhci_write64(const xhci_state_t *state, uint32_t offset, uint64_t value) {
    return xhci_write32(state, offset, (uint32_t)value) &&
           xhci_write32(state, offset + sizeof(uint32_t), (uint32_t)(value >> 32));
}

static bool xhci_map_mmio(xhci_state_t *state) {
    uint32_t bar_index = PCI_MAX_BARS;
    if (state == 0 || state->pci == 0) return false;
    for (uint32_t i = 0; i < PCI_MAX_BARS; ++i) {
        if ((state->pci->bars[i].flags & PCI_RESOURCE_MEMORY) != 0 &&
            state->pci->bars[i].length != 0) {
            bar_index = i;
            break;
        }
    }
    if (bar_index == PCI_MAX_BARS) {
        g_xhci_error = 10U;
        return false;
    }
    uint64_t span = state->pci->bars[bar_index].length;
    if (span > XHCI_MMIO_MAX_SIZE) span = XHCI_MMIO_MAX_SIZE;
    span = (span + PAGE_SIZE - 1ULL) & ~(uint64_t)(PAGE_SIZE - 1ULL);
    if (span == 0 || span > X86_64_MMIO_END - XHCI_MMIO_VA + 1ULL ||
        state->pci->bars[bar_index].address > UINT64_MAX - span) {
        g_xhci_error = 11U;
        return false;
    }
    uint64_t mapped = 0;
    while (mapped < span) {
        if (x86_map_page(x86_current_root_table(), XHCI_MMIO_VA + mapped,
                         paddr_make(state->pci->bars[bar_index].address + mapped),
                         X86_PAGE_WRITE | X86_PAGE_GLOBAL, X86_CACHE_UC) != K_OK) {
            while (mapped != 0) {
                mapped -= PAGE_SIZE;
                (void)x86_unmap_page(x86_current_root_table(), XHCI_MMIO_VA + mapped, 0);
            }
            g_xhci_error = 12U;
            return false;
        }
        mapped += PAGE_SIZE;
    }
    state->mmio = (volatile uint8_t *)(uintptr_t)XHCI_MMIO_VA;
    state->mmio_span = span;
    return true;
}

static void xhci_unmap_mmio(xhci_state_t *state) {
    if (state == 0 || state->mmio == 0) return;
    for (uint64_t offset = 0; offset < state->mmio_span; offset += PAGE_SIZE) {
        (void)x86_unmap_page(x86_current_root_table(), XHCI_MMIO_VA + offset, 0);
    }
    state->mmio = 0;
    state->mmio_span = 0;
}

static bool xhci_alloc_page(xhci_state_t *state, xhci_dma_page_t *dma,
                            enum dma_direction direction) {
    if (state == 0 || state->pci == 0 || dma == 0) return false;
    dma->page = page_alloc(0, PAGE_ALLOC_ZERO | PAGE_ALLOC_DMA32);
    if (dma->page == 0) return false;
    page_t *pages[1] = {dma->page};
    if (dma_map_pages((device_t *)&state->pci->device, pages, 1U, direction,
                      &dma->mapping) != K_OK) {
        page_free(dma->page);
        dma->page = 0;
        return false;
    }
    dma->cpu = phys_to_direct(page_to_phys(dma->page));
    if (dma->cpu == 0 || xhci_dma_address(&dma->mapping) == 0) {
        if (dma_unmap_checked(&dma->mapping) != K_OK) {
            dma->cpu = 0;
            return false;
        }
        page_free(dma->page);
        dma->page = 0;
        dma->cpu = 0;
        return false;
    }
    return true;
}

static bool xhci_free_page(xhci_dma_page_t *dma) {
    if (dma == 0) return false;
    if (dma->mapping.device != 0 &&
        dma_unmap_checked(&dma->mapping) != K_OK) return false;
    if (dma->page != 0) page_free(dma->page);
    dma->page = 0;
    dma->cpu = 0;
    return true;
}

static bool xhci_free_rings(xhci_state_t *state) {
    bool erst;
    bool event_ring;
    bool command_ring;
    bool dcbaa;
    if (state == 0) return false;
    erst = xhci_free_page(&state->erst);
    event_ring = xhci_free_page(&state->event_ring);
    command_ring = xhci_free_page(&state->command_ring);
    dcbaa = xhci_free_page(&state->dcbaa);
    return erst && event_ring && command_ring && dcbaa;
}

/*
 * V3.10.6B6C EXPLICIT DEVICE RESOURCE TEARDOWN
 *
 * DMA/resource lifetime belongs to an explicit device context.
 */

static bool xhci_free_device_resources_device(
    xhci_device_context_t *device) {
    bool released = true;
    if (device == 0) return false;
    if (device->audio_stream != 0) {
        /* 热拔出先让统一音频对象进入 DISCONNECTED，再释放其端点 DMA。 */
        audio_stream_t *stream = device->audio_stream;
        device->audio_stream = 0;
        device->audio_stream_running = false;
        device->audio_stream_queued = false;
        device->audio_stream_bound = false;
        (void)audio_stream_disconnect(stream);
    }
    if (device->bt_controller != 0) {
        (void)bt_controller_disconnect(device->bt_controller);
        bt_controller_destroy(device->bt_controller);
        device->bt_controller = 0;
    }
    if(!xhci_free_page(
           &device->descriptor_buffer))
    {
        released =
            false;
    }
    if(!xhci_free_page(
           &device->hid_report))
    {
        released =
            false;
    }
    if(!xhci_free_page(
           &device->hid_ring))
    {
        released =
            false;
    }
    if(!xhci_free_page(
           &device->audio_buffer))
    {
        released =
            false;
    }
    if(!xhci_free_page(
           &device->audio_ring))
    {
        released =
            false;
    }
    if(!xhci_free_page(
           &device->bt_acl_out_ring))
    {
        released =
            false;
    }
    if(!xhci_free_page(
           &device->bt_acl_out_buffer))
    {
        released =
            false;
    }
    if(!xhci_free_page(
           &device->bt_acl_in_buffer))
    {
        released =
            false;
    }
    if(!xhci_free_page(
           &device->bt_acl_in_ring))
    {
        released =
            false;
    }
    if(!xhci_free_page(
           &device->bt_event_buffer))
    {
        released =
            false;
    }
    if(!xhci_free_page(
           &device->bt_event_ring))
    {
        released =
            false;
    }
    if(!xhci_free_page(
           &device->hub_report))
    {
        released =
            false;
    }
    if(!xhci_free_page(
           &device->hub_ring))
    {
        released =
            false;
    }
    if(!xhci_free_page(
           &device->ep0_ring))
    {
        released =
            false;
    }
    if(!xhci_free_page(
           &device->input_context))
    {
        released =
            false;
    }
    if(!xhci_free_page(
           &device->output_context))
    {
        released =
            false;
    }
    if (!released) return false;
    device->device_slot = 0;
    device->device_port = 0;
    device->device_speed = 0;
    device->root_port = 0U;
    device->parent_slot = 0U;
    device->parent_port = 0U;
    device->route_string = 0U;
    device->ep0_enqueue = 0;
    device->configuration_value = 0;
    device->hid_interface = 0U;
    device->hid_protocol = 0U;
    device->hid_endpoint = 0;
    device->hid_max_packet = 0;
    device->hid_interval = 0;
    device->hid_enqueue = 0;
    device->hid_cycle = 1U;
    device->hid_transfer_pending = false;
    device->hid_previous_modifier = 0U;
    for (uint32_t i = 0; i < 6U; ++i) device->hid_previous_keys[i] = 0U;
    device->hid_previous_buttons = 0U;
    device->audio_interface = 0U;
    device->audio_alt_setting = 0U;
    device->audio_endpoint = 0U;
    device->audio_interval = 0U;
    device->audio_max_packet = 0U;
    device->audio_channels = 0U;
    device->audio_bit_resolution = 0U;
    device->audio_sample_rate = 0U;
    device->audio_endpoint_in = false;
    device->audio_enqueue = 0U;
    device->audio_cycle = 1U;
    device->audio_transfer_pending = false;
    device->audio_completed = 0U;
    device->audio_stream = 0;
    device->audio_period = 0U;
    device->audio_frames = 0U;
    device->audio_stream_running = false;
    device->audio_stream_queued = false;
    device->audio_stream_bound = false;
    device->hub_interface = 0U;
    device->hub_interface_present = false;
    device->hub_port_count = 0U;
    device->hub_protocol = 0U;
    device->hub_tt_think_time = 0U;
    device->hub_configured = false;
    device->hub_endpoint = 0U;
    device->hub_max_packet = 0U;
    device->hub_interval = 0U;
    device->hub_enqueue = 0U;
    device->hub_cycle = 1U;
    device->hub_transfer_pending = false;
    device->hub_change_bitmap = 0U;
    device->bt_event_endpoint = 0U;
    device->bt_acl_in_endpoint = 0U;
    device->bt_acl_out_endpoint = 0U;
    device->bt_event_interval = 0U;
    device->bt_event_max_packet = 0U;
    device->bt_acl_in_max_packet = 0U;
    device->bt_acl_out_max_packet = 0U;
    device->bt_event_enqueue = 0U;
    device->bt_event_cycle = 1U;
    device->bt_event_transfer_pending = false;
    device->bt_acl_in_enqueue = 0U;
    device->bt_acl_in_cycle = 1U;
    device->bt_acl_in_transfer_pending = false;
    device->bt_acl_out_enqueue = 0U;
    device->bt_acl_out_cycle = 1U;
    device->bt_acl_out_transfer_pending = false;
    return true;
}

/*
 * Compatibility wrapper for unpublished/new-device enumeration.
 */
static bool xhci_free_device_resources(
    xhci_state_t *state)
{
    if(state == 0)
    {
        return false;
    }

    return
        xhci_free_device_resources_device(
            &state->device);
}


static uint8_t xhci_context_kind(const xhci_device_context_t *context) {
    if (context == 0) return 0U;
    if (context->hid_endpoint != 0U) return 1U;
    if (context->audio_endpoint != 0U) return 2U;
    if (context->bt_event_endpoint != 0U) return 3U;
    if (context->hub_configured || context->hub_interface_present) return 4U;
    return 0U;
}

/*
 * 在释放端点环之前先停止所有仍有 TRB 在飞的端点。Disable Slot 会让
 * 设备失效，但显式 Stop Endpoint 能把“控制器仍可能消费 DMA 环”的
 * 生命周期边界前移；即使设备已突然拔出，命令失败也只影响诊断，
 * 后续仍会执行最小化的资源回收。
 */
/*
 * V3.10.6B6C EXPLICIT ENDPOINT STOP
 */
static bool xhci_stop_pending_endpoints_device(
    xhci_state_t *state,
    xhci_device_context_t *device) {
    uint8_t endpoints[6];
    uint32_t count = 0U;
    bool stopped = true;
    if (state == 0 ||
        device == 0 ||
        device->device_slot == 0U) return true;
    if (device->hid_transfer_pending && device->hid_endpoint != 0U) {
        endpoints[count++] = (uint8_t)(device->hid_endpoint * 2U + 1U);
    }
    if (device->audio_transfer_pending && device->audio_endpoint != 0U) {
        endpoints[count++] = (uint8_t)(device->audio_endpoint * 2U +
                                       (device->audio_endpoint_in ? 1U : 0U));
    }
    if (device->hub_transfer_pending && device->hub_endpoint != 0U) {
        endpoints[count++] = (uint8_t)(device->hub_endpoint * 2U + 1U);
    }
    if (device->bt_event_transfer_pending && device->bt_event_endpoint != 0U) {
        endpoints[count++] = (uint8_t)(device->bt_event_endpoint * 2U + 1U);
    }
    if (device->bt_acl_in_transfer_pending && device->bt_acl_in_endpoint != 0U) {
        endpoints[count++] = (uint8_t)(device->bt_acl_in_endpoint * 2U + 1U);
    }
    if (device->bt_acl_out_transfer_pending && device->bt_acl_out_endpoint != 0U) {
        endpoints[count++] = (uint8_t)(device->bt_acl_out_endpoint * 2U);
    }
    for (uint32_t i = 0U; i < count; ++i) {
        bool duplicate = false;
        for (uint32_t previous = 0U; previous < i; ++previous) {
            if (endpoints[previous] == endpoints[i]) duplicate = true;
        }
        if (duplicate || endpoints[i] > 31U) continue;
        if (!xhci_submit_command_ex(state, XHCI_STOP_ENDPOINT_TYPE,
                                    device->device_slot, endpoints[i], 0U, 0)) {
            stopped = false;
        }
    }
    return stopped;
}

/*
 * Compatibility wrapper for the unpublished working context.
 */
/*
 * V3.10.6B9E-FIX1 STOP ENDPOINT WRAPPER REMOVED
 *
 * Endpoint teardown always receives an explicit
 * xhci_device_context_t *.
 */



/* 设备可以在 active context 和 inventory 之间移动，拓扑标记必须随之重算。 */
/*
 * V3.7.1 SLOT TABLE TOPOLOGY STATE
 *
 * Slot Table is now the authoritative device/topology index.
 *
 * inventory[] remains only temporary context storage and is no longer
 * consulted for:
 *
 *   device count
 *   HID presence
 *   mouse presence
 *   Hub presence
 *   downstream presence
 */
static void xhci_recompute_topology(
    xhci_state_t *state)
{
    bool hub_present =
        false;

    bool downstream =
        false;

    bool hid_present =
        false;

    bool mouse_present =
        false;

    bool audio_present =
        false;

    bool bluetooth_present =
        false;

    uint8_t hub_ports =
        0U;

    uint32_t count =
        0U;


    if(state == 0)
    {
        return;
    }


    uint32_t slot_limit =
        state->max_slots;


    if(slot_limit >=
       XHCI_MAX_SLOT_TABLE)
    {
        slot_limit =
            XHCI_MAX_SLOT_TABLE - 1U;
    }


    for(uint32_t slot = 1U;
        slot <= slot_limit;
        ++slot)
    {
        xhci_slot_device_t *slot_dev =
            &g_xhci_slot_devices[
                slot];


        if(!slot_dev->used)
        {
            continue;
        }


        /*
         * V3.2 creates a tentative Slot Table node before
         * enumeration has completely succeeded.
         *
         * Only a published context whose hardware Slot ID
         * matches the table index counts as a live USB device.
         *
         * This prevents a failed enumeration from becoming a
         * phantom device in global topology state.
         */
        if(slot_dev->context.device_slot !=
           (uint8_t)slot)
        {
            continue;
        }


        ++count;


        xhci_device_context_t *device =
            &slot_dev->context;


        if(device->hid_endpoint != 0U)
        {
            hid_present =
                true;


            if(device->hid_protocol ==
               USB_HID_PROTOCOL_MOUSE)
            {
                mouse_present =
                    true;
            }
        }


        if(device->audio_endpoint != 0U)
        {
            audio_present =
                true;
        }


        if(device->bt_event_endpoint != 0U ||
           device->bt_controller != 0)
        {
            bluetooth_present =
                true;
        }


        if(slot_dev->is_hub)
        {
            hub_present =
                true;


            if(hub_ports == 0U)
            {
                hub_ports =
                    slot_dev->
                        hub_port_count;

                /*
                 * Compatibility fallback while Hub fields are
                 * still being migrated out of xHCI context.
                 */
                if(hub_ports == 0U)
                {
                    hub_ports =
                        device->
                            hub_port_count;
                }
            }
        }


        /*
         * Any non-root device proves that a downstream topology
         * exists, including:
         *
         * Hub -> device
         * Hub -> Hub
         * Hub -> Hub -> device
         */
        if(slot_dev->parent_slot != 0U ||
           device->parent_slot != 0U)
        {
            downstream =
                true;
        }
    }


    g_xhci_usb_device_count =
        count;

    g_xhci_usb_enumerated =
        count != 0U;

    g_xhci_usb_hid =
        hid_present;

    g_xhci_usb_mouse =
        mouse_present;

    g_xhci_usb_audio =
        audio_present;

    g_xhci_usb_bluetooth =
        bluetooth_present;

    g_xhci_usb_hub_present =
        hub_present;

    g_xhci_usb_hub =
        hub_present;

    g_xhci_usb_hub_ports =
        hub_ports;

    /*
     * Keep the existing public/runtime diagnostic field alive
     * until Hub class migration removes the legacy name.
     */
    g_xhci_usb_hub_inventory_ports =
        hub_ports;

    g_xhci_usb_hub_downstream =
        downstream;
}



/* V3.10.6B7D-FIX1 removed xhci_take_active_device(): runtime devices never activate state->device. */



/* V3.10.6B7D-FIX1 removed xhci_restore_active_device(): runtime devices never activate state->device. */



/*
 * V3.6.6 SLOT UNPUBLISH
 *
 * Hardware teardown is still owned by xHCI.
 *
 * Once Disable Slot has been issued, remove the same device from:
 *
 *   xHCI Slot Table
 *   parent Hub child map
 *   USB Hub Core
 *   USB Device Core
 */
static void xhci_unpublish_slot_device(
    uint8_t slot,
    uint8_t parent_slot,
    uint8_t parent_port)
{
    if(slot == 0U)
    {
        return;
    }

    /*
     * Detach from parent first.
     */
    if(parent_slot != 0U &&
       parent_port != 0U)
    {
        usb_hub_port_disconnect(
            parent_slot,
            parent_port,
            slot);

        /*
         * Current xHCI fast child map contains 16 entries.
         */
        if(parent_port <= 16U)
        {
            xhci_slot_device_t *parent =
                &g_xhci_slot_devices[
                    parent_slot];

            if(parent->used &&
               parent->child_slots[
                   parent_port - 1U] ==
                   slot)
            {
                parent->child_slots[
                    parent_port - 1U] =
                    0U;
            }
        }
    }

    /*
     * Safe for non-Hub devices too:
     * usb_hub_remove() simply clears the corresponding class slot.
     */
    usb_hub_remove(
        slot);

    usb_release_device(
        slot);

        /*
     * bt_controller_disconnect/destroy runs before unpublish.
     * The callback binding can now be invalidated safely.
     */
    __builtin_memset(
        &g_xhci_bt_transports[slot],
        0,
        sizeof(g_xhci_bt_transports[slot]));


__builtin_memset(
        &g_xhci_slot_devices[slot],
        0,
        sizeof(g_xhci_slot_devices[slot]));
}


static bool xhci_release_device_context(
    xhci_state_t *state,
    xhci_device_context_t *device);

/*
 * V3.10.6B9D UNIFIED EXPLICIT TEARDOWN
 *
 * state->device is unpublished enumeration working storage.
 *
 * Its resource lifetime uses the same explicit device-context
 * teardown core as a published Slot.context.
 */
static bool xhci_release_working_device(
    xhci_state_t *state)
{
    if(state == 0 ||
       state->device.device_slot == 0U)
    {
        return true;
    }


    return
        xhci_release_device_context(
            state,
            &state->device);
}

/*
 * V3.10.6B6C EXPLICIT DEVICE TEARDOWN
 *
 * Destroy one device context without installing it in state->device.
 *
 * The caller owns current-device kind/flag bookkeeping.
 */
static bool xhci_release_device_context(
    xhci_state_t *state,
    xhci_device_context_t *device)
{
    if(state == 0 ||
       device == 0 ||
       device->device_slot == 0U)
    {
        return true;
    }

    /*
     * Resource teardown clears identity fields, therefore preserve
     * software topology identity first.
     */
    uint8_t released_slot =
        device->device_slot;

    uint8_t released_parent_slot =
        device->parent_slot;

    uint8_t released_parent_port =
        device->parent_port;

    if(!xhci_stop_pending_endpoints_device(
           state,
           device))
    {
        g_xhci_error =
            60U;
    }

    if(!xhci_submit_command(
           state,
           XHCI_DISABLE_SLOT_TYPE,
           device->device_slot,
           0U,
           0))
    {
        /*
         * A disconnected device may no longer produce a Disable
         * Slot completion, but its software/DMA ownership still
         * has to be released.
         */
        g_xhci_error =
            61U;
    }

    bool released =
        xhci_free_device_resources_device(
            device);

    /*
     * Hardware Slot lifetime has ended.
     */
    xhci_unpublish_slot_device(
        released_slot,
        released_parent_slot,
        released_parent_port);

    xhci_recompute_topology(
        state);

    return released;
}


/*
 * V3.9.2 DIRECT SLOT RELEASE
 *
 * Hardware/device lifetime is now terminated directly by Slot ID.
 *
 * No:
 *
 *     inventory scan
 *     inventory index lookup
 *     inventory context
 *
 * is needed to stop endpoints, Disable Slot, release DMA or
 * unpublish topology.
 */
/*
 * V3.10.6B6C CANONICAL SLOT TEARDOWN
 *
 * Published Slot.context is destroyed in place.
 * state->device remains untouched unless it is itself the target.
 */
/*
 * V3.10.6B9C PURE PUBLISHED SLOT RELEASE
 *
 * This function owns one published hardware Slot only:
 *
 *     Slot ID
 *        |
 *        v
 *   Slot.context
 *        |
 *        v
 * xhci_release_device_context()
 *
 * state->device is a separate unpublished enumeration lifetime and
 * is intentionally invisible here.
 */
static bool xhci_release_slot_device(
    xhci_state_t *state,
    uint8_t slot)
{
    if(state == 0 ||
       slot == 0U)
    {
        return false;
    }


    xhci_slot_device_t *slot_dev =
        &g_xhci_slot_devices[
            slot];


    if(!slot_dev->used ||
       slot_dev->context.device_slot !=
           slot)
    {
        return false;
    }


    return
        xhci_release_device_context(
            state,
            &slot_dev->context);
}


/*
 * inventory[] compatibility wrapper.
 *
 * Initial enumeration still uses inventory metadata, but hardware
 * teardown itself is now purely Slot-based.
 */

/*
 * V3.10.6B8C
 *
 * xhci_release_inventory_entry() removed.
 * Teardown is Slot-ID based.
 */




/*
 * V3.9.6 SLOT ONLY SAVE
 *
 * Slot Table is the permanent device store.
 *

*/

/*
 * V3.10.6B8C
 *
 * xhci_save_active_device() removed.
 * Publication is Slot.context-only.
 */




/*
 * V3.10.6B2 CANONICAL SELF TEST CONTEXT
 *
 * xhci_load_inventory_device() removed.
 *
 * Hardware self-test resolves initialization inventory directly
 * to canonical Slot.context and never installs published device
 * state into state->device.
 */



/*
 * V3.9.5 SLOT TABLE CONTROLLER TEARDOWN
 *
 * Controller destruction is driven exclusively by hardware Slot
 * identity.
 *
 * inventory[] is not inspected.
 */
static bool xhci_free_slot_resources(
    xhci_state_t *state)
{
    bool released =
        true;


    if(state == 0)
    {
        return false;
    }


    /*
     * First handle the current working context.
     *
     * A fully enumerated active device should also exist in the
     * Slot Table.  A partially constructed enumeration context may
     * not, so retain a raw-resource fallback for that case.
     */
    if(state->device.device_slot != 0U)
    {
        /*
         * V3.10.6B9B WORKING CONTEXT TEARDOWN
         *
         * Slot.used may already be true during enumeration before
         * Slot.context has been published.
         *
         * Therefore state->device always owns its own teardown path.
         */
        if(!xhci_release_working_device(
               state))
        {
            released =
                false;
        }
    }


    uint32_t limit =
        state->max_slots;


    if(limit >=
       XHCI_MAX_SLOT_TABLE)
    {
        limit =
            XHCI_MAX_SLOT_TABLE -
            1U;
    }


    /*
     * Every remaining published device is parked in Slot.context.
     *
     * xhci_release_slot_device() performs:
     *
     *     Stop Endpoint
     *        ↓
     *     Disable Slot
     *        ↓
     *     release DMA
     *        ↓
     *     unlink parent
     *        ↓
     *     remove USB Core / Hub Core object
     *        ↓
     *     clear Slot Table entry
     */
    for(uint32_t slot = 1U;
        slot <= limit;
        ++slot)
    {
        xhci_slot_device_t *slot_dev =
            &g_xhci_slot_devices[
                slot];


        if(!slot_dev->used)
        {
            continue;
        }


        /*
         * Ignore an uncommitted/stale tentative node here.
         *
         * If it somehow still owns the active working context it
         * was handled above.  A published parked Slot must have a
         * matching canonical context.
         */
        if(slot_dev->context.device_slot !=
           (uint8_t)slot)
        {
            __builtin_memset(
                slot_dev,
                0,
                sizeof(*slot_dev));

            released =
                false;

            continue;
        }


        if(!xhci_release_slot_device(
                state,
                (uint8_t)slot))
        {
            released =
                false;
        }
    }


    /*
     * Nothing may remain installed after controller teardown.
     */
    xhci_zero_device_context(
        &state->device);

    xhci_clear_device_flags();


    return released;
}


static bool xhci_reset(xhci_state_t *state) {
    uint32_t command = xhci_read32(state, state->operational_offset + XHCI_USBCMD);
    if (command == UINT32_MAX || !xhci_write32(state,
                                                state->operational_offset + XHCI_USBCMD,
                                                command & ~XHCI_USBCMD_RUN)) return false;
    for (uint32_t spin = 0; spin < 100000U; ++spin) {
        uint32_t status = xhci_read32(state, state->operational_offset + XHCI_USBSTS);
        if ((status & XHCI_USBSTS_HCH) != 0) break;
        __asm__ volatile ("pause");
    }
    command = xhci_read32(state, state->operational_offset + XHCI_USBCMD);
    if (command == UINT32_MAX || !xhci_write32(state,
                                                state->operational_offset + XHCI_USBCMD,
                                                command | XHCI_USBCMD_HCRST)) return false;
    for (uint32_t spin = 0; spin < 100000U; ++spin) {
        command = xhci_read32(state, state->operational_offset + XHCI_USBCMD);
        uint32_t status = xhci_read32(state, state->operational_offset + XHCI_USBSTS);
        if ((command & XHCI_USBCMD_HCRST) == 0 && (status & XHCI_USBSTS_CNR) == 0) {
            return true;
        }
        __asm__ volatile ("pause");
    }
    return false;
}

static bool xhci_setup_rings(xhci_state_t *state) {
    if (!xhci_alloc_page(state, &state->dcbaa, DMA_BIDIRECTIONAL) ||
        !xhci_alloc_page(state, &state->command_ring, DMA_BIDIRECTIONAL) ||
        !xhci_alloc_page(state, &state->event_ring, DMA_FROM_DEVICE) ||
        !xhci_alloc_page(state, &state->erst, DMA_BIDIRECTIONAL)) return false;

    xhci_trb_t *command_ring = (xhci_trb_t *)state->command_ring.cpu;
    command_ring[XHCI_RING_TRB_COUNT - 1U].parameter =
        xhci_dma_address(&state->command_ring.mapping);
    command_ring[XHCI_RING_TRB_COUNT - 1U].control =
        (XHCI_LINK_TRB_TYPE << XHCI_TRB_TYPE_SHIFT) | XHCI_TRB_CYCLE;
    xhci_erst_entry_t *erst = (xhci_erst_entry_t *)state->erst.cpu;
    erst[0].ring_segment_base = xhci_dma_address(&state->event_ring.mapping);
    erst[0].ring_segment_size = XHCI_RING_TRB_COUNT;
    uint64_t dcbaa = xhci_dma_address(&state->dcbaa.mapping);
    uint64_t command_ring_address = xhci_dma_address(&state->command_ring.mapping) | 1ULL;
    uint64_t erst_address = xhci_dma_address(&state->erst.mapping);
    uint64_t event_ring_address = xhci_dma_address(&state->event_ring.mapping);
    /* runtime 区前 0x20 字节是 MFINDEX，第 0 个 interrupter 从 0x20 开始。 */
    uint32_t runtime = state->runtime_offset + XHCI_RUNTIME_INTR0;
    uint32_t operational = state->operational_offset;
    dma_sync_for_device(&state->dcbaa.mapping);
    dma_sync_for_device(&state->command_ring.mapping);
    dma_sync_for_device(&state->event_ring.mapping);
    dma_sync_for_device(&state->erst.mapping);
    if (!xhci_write64(state, operational + XHCI_DCBAAP, dcbaa) ||
        !xhci_write64(state, operational + XHCI_CRCR, command_ring_address) ||
        !xhci_write32(state, operational + XHCI_CONFIG, state->max_slots) ||
        !xhci_write32(state, runtime + XHCI_RUNTIME_IMAN, XHCI_IMAN_IE) ||
        !xhci_write32(state, runtime + XHCI_RUNTIME_ERSTSZ, 1U) ||
        !xhci_write64(state, runtime + XHCI_RUNTIME_ERSTBA, erst_address) ||
        /* 初始事件队列尚未被控制器处理，ERDP 不应携带 EHB。 */
        !xhci_write64(state, runtime + XHCI_RUNTIME_ERDP, event_ring_address) ||
        !xhci_write32(state, operational + XHCI_USBCMD,
                      XHCI_USBCMD_RUN | XHCI_USBCMD_INTE)) return false;
    for (uint32_t spin = 0; spin < 100000U; ++spin) {
        if ((xhci_read32(state, operational + XHCI_USBSTS) & XHCI_USBSTS_HCH) == 0) {
            return true;
        }
        __asm__ volatile ("pause");
    }
    return false;
}

static bool xhci_next_ring_event(xhci_state_t *state, xhci_trb_t *event) {
    const volatile xhci_trb_t *event_ring;
    uint32_t control;
    if (state == 0 || event == 0) return false;
    /*
     * The xHCI event ring is controller-owned.  Software consumes it solely
     * by advancing ERDP; it must never clear or otherwise rewrite an Event
     * TRB.  Clearing the cycle bit makes an empty, stale entry look valid
     * when the consumer cycle state wraps, after which HID completions are
     * permanently missed.
     */
    event_ring = (const volatile xhci_trb_t *)state->event_ring.cpu;
    dma_sync_for_cpu(&state->event_ring.mapping);
    control = event_ring[state->event_index].control;
    if ((control & XHCI_TRB_CYCLE) != state->event_cycle) return false;
    event->parameter = event_ring[state->event_index].parameter;
    event->status = event_ring[state->event_index].status;
    event->control = control;
    state->event_index = (state->event_index + 1U) % XHCI_RING_TRB_COUNT;
    if (state->event_index == 0) state->event_cycle ^= 1U;
    uint64_t event_dequeue = xhci_dma_address(&state->event_ring.mapping) +
                             (uint64_t)state->event_index * sizeof(xhci_trb_t);
    (void)xhci_write64(state, state->runtime_offset + XHCI_RUNTIME_INTR0 +
                       XHCI_RUNTIME_ERDP, event_dequeue | XHCI_ERDP_EHB);
    return true;
}

static bool xhci_defer_event(xhci_state_t *state, const xhci_trb_t *event) {
    if (state == 0 || event == 0 ||
        state->deferred_event_count >= XHCI_DEFERRED_EVENT_COUNT) {
        if (state != 0) g_xhci_error = 28U;
        return false;
    }
    state->deferred_events[state->deferred_event_tail] = *event;
    state->deferred_event_tail =
        (state->deferred_event_tail + 1U) % XHCI_DEFERRED_EVENT_COUNT;
    ++state->deferred_event_count;
    return true;
}

/* 统一事件消费者优先处理同步等待阶段暂存的事件，再读取硬件事件环。 */
static bool xhci_next_event(xhci_state_t *state, xhci_trb_t *event) {
    if (state == 0 || event == 0) return false;
    if (state->deferred_event_count != 0U) {
        *event = state->deferred_events[state->deferred_event_head];
        state->deferred_event_head =
            (state->deferred_event_head + 1U) % XHCI_DEFERRED_EVENT_COUNT;
        --state->deferred_event_count;
        return true;
    }
    return xhci_next_ring_event(state, event);
}

static bool xhci_hid_report_contains(const uint8_t *report, uint8_t key) {
    if (report == 0 || key == 0U) return false;
    for (uint32_t i = 2U; i < 8U; ++i) {
        if (report[i] == key) return true;
    }
    return false;
}

static bool xhci_hid_previous_contains(const xhci_device_context_t *device,
                                       uint8_t key) {
    if (device == 0 || key == 0U) return false;
    for (uint32_t i = 0U; i < 6U; ++i) {
        if (device->hid_previous_keys[i] == key) return true;
    }
    return false;
}

static uint32_t xhci_hid_input_device_id(const xhci_device_context_t *context) {
    /* A slot remains unique until Disable Slot, which also bounds the
     * lifetime of events generated from its DMA report buffer. */
    return context == 0 ? 0x5848U : 0x58480000U | context->device_slot;
}

static void xhci_hid_emit_event(const xhci_device_context_t *context,
                                uint16_t type, uint32_t code, int32_t value) {
    input_event_t event = {
        .timestamp = 0U,
        .device_id = xhci_hid_input_device_id(context),
        .type = type,
        .flags = 0U,
        .code = code,
        .value = value,
    };
    if (!atomic_exchange_explicit(&g_xhci_input_seen, true,
                                  memory_order_acq_rel)) {
        liteos_serial_write("LITEOS_USB_INPUT_EVENT_OK\r\n");
    }
    (void)input_core_push(&event);
}

static void xhci_hid_emit_key(const xhci_device_context_t *context,
                              uint8_t key, int32_t value) {
    xhci_hid_emit_event(context, INPUT_EVENT_KEY, key, value);
}

static void xhci_hid_consume_keyboard_report(xhci_device_context_t *state,
                                              const uint8_t *report) {
    uint8_t modifier;
    if (state == 0 || report == 0) return;
    modifier = report[0];
    for (uint8_t bit = 0U; bit < 8U; ++bit) {
        uint8_t mask = (uint8_t)(1U << bit);
        if ((modifier & mask) != (state->hid_previous_modifier & mask)) {
            xhci_hid_emit_key(state, (uint8_t)(0xE0U + bit),
                              (modifier & mask) != 0U ? INPUT_VALUE_PRESS :
                                                        INPUT_VALUE_RELEASE);
        }
    }
    for (uint32_t i = 2U; i < 8U; ++i) {
        uint8_t previous = state->hid_previous_keys[i - 2U];
        if (previous != 0U && !xhci_hid_report_contains(report, previous)) {
            xhci_hid_emit_key(state, previous, INPUT_VALUE_RELEASE);
        }
    }
    for (uint32_t i = 2U; i < 8U; ++i) {
        uint8_t current = report[i];
        if (current >= 4U && !xhci_hid_previous_contains(state, current)) {
            xhci_hid_emit_key(state, current, INPUT_VALUE_PRESS);
        }
        state->hid_previous_keys[i - 2U] = current;
    }
    state->hid_previous_modifier = modifier;
}

static void xhci_hid_consume_mouse_report(xhci_device_context_t *state,
                                           const uint8_t *report,
                                           uint32_t report_length) {
    static const uint32_t buttons[] = {
        INPUT_BUTTON_LEFT,
        INPUT_BUTTON_RIGHT,
        INPUT_BUTTON_MIDDLE,
    };
    uint8_t current_buttons;
    if (state == 0 || report == 0 || report_length < 3U) return;
    if (!atomic_exchange_explicit(&g_xhci_mouse_input_seen, true,
                                  memory_order_acq_rel)) {
        liteos_serial_write("LITEOS_USB_MOUSE_EVENT_OK\r\n");
    }
    current_buttons = report[0] & 0x07U;
    for (uint32_t bit = 0U; bit < sizeof(buttons) / sizeof(buttons[0]); ++bit) {
        uint8_t mask = (uint8_t)(1U << bit);
        if ((current_buttons & mask) != (state->hid_previous_buttons & mask)) {
            xhci_hid_emit_event(state, INPUT_EVENT_BUTTON, buttons[bit],
                                (current_buttons & mask) != 0U ?
                                    INPUT_VALUE_PRESS : INPUT_VALUE_RELEASE);
        }
    }
    /* Boot mouse reports use signed 8-bit relative coordinates.  The input
     * ABI deliberately uses screen coordinates (positive X right, positive Y
     * down).  QEMU's USB boot-mouse backend, like conventional desktop HID
     * stacks, reports a physical downward movement as a positive Y delta, so
     * forward the value unchanged rather than applying a second inversion. */
    int32_t delta_x = (int32_t)(int8_t)report[1];
    int32_t hid_delta_y = (int32_t)(int8_t)report[2];
    if (delta_x != 0) {
        xhci_hid_emit_event(state, INPUT_EVENT_RELATIVE, INPUT_REL_X, delta_x);
    }
    if (hid_delta_y != 0) {
        xhci_hid_emit_event(state, INPUT_EVENT_RELATIVE, INPUT_REL_Y, hid_delta_y);
    }
    /* The optional fourth byte is the Boot mouse wheel.  Preserve its HID
     * signed direction; consumers can apply their own scroll convention. */
    if (report_length >= 4U && report[3] != 0U) {
        xhci_hid_emit_event(state, INPUT_EVENT_RELATIVE, INPUT_REL_WHEEL,
                            (int32_t)(int8_t)report[3]);
    }
    state->hid_previous_buttons = current_buttons;
}

static void xhci_hid_consume_report(xhci_device_context_t *device,
                                    uint32_t report_length) {
    const uint8_t *report;
    if (device == 0 || device->hid_report.cpu == 0) return;
    report = (const uint8_t *)device->hid_report.cpu;
    if (device->hid_protocol == USB_HID_PROTOCOL_KEYBOARD && report_length >= 8U) {
        xhci_hid_consume_keyboard_report(device, report);
    } else if (device->hid_protocol == USB_HID_PROTOCOL_MOUSE &&
               report_length >= 3U) {
        xhci_hid_consume_mouse_report(device, report, report_length);
    }
}

static bool xhci_queue_hid_report(xhci_state_t *state,
                                  xhci_device_context_t *device) {
    xhci_trb_t *ring;
    uint32_t index;
    uint32_t endpoint_id;
    if (state == 0 || device == 0 || !state->initialized ||
        device->hid_ring.cpu == 0 || device->hid_report.cpu == 0 ||
        device->hid_transfer_pending || device->device_slot == 0U) return false;
    index = device->hid_enqueue;
    if (index >= XHCI_RING_TRB_COUNT - 1U) return false;
    endpoint_id = (uint32_t)device->hid_endpoint * 2U + 1U;
    if (device->hid_endpoint == 0U || endpoint_id > 31U) return false;
    ring = (xhci_trb_t *)device->hid_ring.cpu;
    ring[index].parameter = xhci_dma_address(&device->hid_report.mapping);
    ring[index].status = device->hid_max_packet;
    ring[index].control = (XHCI_NORMAL_TRB_TYPE << XHCI_TRB_TYPE_SHIFT) |
                          XHCI_TRB_INTERRUPT_ON_COMPLETION | device->hid_cycle;
    ++index;
    if (index == XHCI_RING_TRB_COUNT - 1U) {
        ring[XHCI_RING_TRB_COUNT - 1U].control =
            (XHCI_LINK_TRB_TYPE << XHCI_TRB_TYPE_SHIFT) |
            device->hid_cycle | XHCI_TRB_LINK_TOGGLE_CYCLE;
        device->hid_enqueue = 0U;
        device->hid_cycle ^= 1U;
    } else {
        device->hid_enqueue = index;
    }
    device->hid_transfer_pending = true;
    dma_sync_for_device(&device->hid_ring.mapping);
    dma_sync_for_device(&device->hid_report.mapping);
    dma_wmb();
    *(volatile uint32_t *)(state->mmio + state->doorbell_offset +
                           (uint32_t)device->device_slot * sizeof(uint32_t)) = endpoint_id;
    __asm__ volatile ("mfence" : : : "memory");
    return true;
}

/* A topology transition (or a controller-side endpoint stop) can complete an
 * interrupt-IN TRB with "Stopped".  Clearing hid_transfer_pending alone is
 * not enough: the endpoint remains stopped and every later doorbell is
 * ignored, leaving the user input waiter asleep forever.  Reset the endpoint
 * before arming the next report.  This is deliberately event-driven; no
 * polling loop is added to the HID path. */
static bool xhci_restart_hid_endpoint(xhci_state_t *state,
                                      xhci_device_context_t *device) {
    uint32_t endpoint_id;
    xhci_trb_t *ring;
    if (state == 0 || device == 0 || device->device_slot == 0U ||
        device->hid_endpoint == 0U || device->hid_ring.cpu == 0) return false;
    ++g_xhci_hid_recovery_attempts;
    g_xhci_hid_recovery_stage = 1U;
    endpoint_id = (uint32_t)device->hid_endpoint * 2U + 1U;
    if (endpoint_id > 31U) {
        ++g_xhci_hid_recovery_failures;
        g_xhci_hid_recovery_stage = 2U;
        return false;
    }
    /* A transfer event with completion code Stopped leaves the endpoint in
     * the Stopped state.  Reset Endpoint is invalid in that state (QEMU
     * returns Context State Error); Set TR Dequeue Pointer is the prescribed
     * recovery.  Reinitialize the producer ring and point the controller at
     * its first TRB with DCS=1, then ring the endpoint doorbell below. */
    ring = (xhci_trb_t *)device->hid_ring.cpu;
    for (uint32_t i = 0U; i < XHCI_RING_TRB_COUNT - 1U; ++i) {
        ring[i].parameter = 0U;
        ring[i].status = 0U;
        ring[i].control = 0U;
    }
    xhci_init_ring_link(&device->hid_ring);
    device->hid_enqueue = 0U;
    device->hid_cycle = 1U;
    device->hid_transfer_pending = false;
    dma_sync_for_device(&device->hid_ring.mapping);
    g_xhci_hid_recovery_stage = 2U;
    if (!xhci_submit_command_ex(state, XHCI_SET_TR_DEQUEUE_POINTER_TYPE,
                                device->device_slot, (uint8_t)endpoint_id,
                                xhci_dma_address(&device->hid_ring.mapping) | 1ULL,
                                0)) {
        g_xhci_hid_recovery_command_error = g_xhci_error;
        /* QEMU can report Stopped for a transfer that has already resumed by
         * the time the deferred worker observes it.  In that transient case
         * Set TR Dequeue Pointer correctly returns Context State Error; the
         * endpoint is still usable, so retry the producer without issuing a
         * second state-changing command. */
        g_xhci_hid_recovery_stage = 3U;
        device->hid_transfer_pending = false;
        if (!xhci_queue_hid_report(state, device)) {
            ++g_xhci_hid_recovery_failures;
            g_xhci_hid_recovery_stage = 4U;
            return false;
        }
        g_xhci_error = 0U;
        g_xhci_hid_recovery_stage = 0U;
        return true;
    }
    g_xhci_hid_recovery_stage = 4U;
    if (!xhci_queue_hid_report(state, device)) {
        ++g_xhci_hid_recovery_failures;
        g_xhci_hid_recovery_stage = 5U;
        return false;
    }
    g_xhci_hid_recovery_stage = 0U;
    return true;
}

/* 向 USB Audio 等时端点提交一个周期。统一音频对象的周期页通过一页
   受控 staging buffer 送入 xHCI，避免让端点直接依赖可变的用户请求。 */
/* Hub 状态端点返回一个位图：bit0 是 Hub 自身，bit1 开始对应下游端口。 */

/*
 * V3.10.6B4 EXPLICIT HUB STATUS QUEUE
 *
 * Hub interrupt-IN state belongs to an explicit device context.
 */
static bool xhci_queue_hub_status_device(xhci_state_t *state,
    xhci_device_context_t *device) {
    xhci_trb_t *ring;
    uint32_t index;
    uint32_t endpoint_id;
    if (state == 0 || !state->initialized || device->hub_ring.cpu == 0 ||
        device->hub_report.cpu == 0 || device->hub_endpoint == 0U ||
        device->hub_max_packet == 0U || device->hub_transfer_pending) return false;
    if (device->hub_max_packet > PAGE_SIZE) return false;
    index = device->hub_enqueue;
    if (index >= XHCI_RING_TRB_COUNT - 1U) return false;
    endpoint_id = (uint32_t)device->hub_endpoint * 2U + 1U;
    if (endpoint_id > 31U) return false;
    for (uint32_t i = 0U; i < device->hub_max_packet; ++i) {
        ((uint8_t *)device->hub_report.cpu)[i] = 0U;
    }
    ring = (xhci_trb_t *)device->hub_ring.cpu;
    ring[index].parameter = xhci_dma_address(&device->hub_report.mapping);
    ring[index].status = device->hub_max_packet;
    ring[index].control = (XHCI_NORMAL_TRB_TYPE << XHCI_TRB_TYPE_SHIFT) |
                          XHCI_TRB_INTERRUPT_ON_COMPLETION | device->hub_cycle;
    ++index;
    if (index == XHCI_RING_TRB_COUNT - 1U) {
        ring[XHCI_RING_TRB_COUNT - 1U].control =
            (XHCI_LINK_TRB_TYPE << XHCI_TRB_TYPE_SHIFT) |
            device->hub_cycle | XHCI_TRB_LINK_TOGGLE_CYCLE;
        device->hub_enqueue = 0U;
        device->hub_cycle ^= 1U;
    } else {
        device->hub_enqueue = index;
    }
    device->hub_transfer_pending = true;
    dma_sync_for_device(&device->hub_ring.mapping);
    dma_sync_for_device(&device->hub_report.mapping);
    dma_wmb();
    *(volatile uint32_t *)(state->mmio + state->doorbell_offset +
                           (uint32_t)device->device_slot * sizeof(uint32_t)) = endpoint_id;
    __asm__ volatile ("mfence" : : : "memory");
    return true;
}

/*
 * Compatibility wrapper for unpublished enumeration/setup paths.
 * Published Hub runtime events never use this wrapper.
 */
static bool xhci_queue_hub_status(
    xhci_state_t *state)
{
    if(state == 0)
    {
        return false;
    }

    return xhci_queue_hub_status_device(
        state,
        &state->device);
}


static bool xhci_configure_hub_endpoint(xhci_state_t *state) {
    uint32_t endpoint_id;
    uint32_t *input;
    uint32_t *control;
    uint32_t *input_slot;
    uint32_t *output_slot;
    uint32_t *endpoint;
    if (state == 0 || state->hub_endpoint == 0U ||
        state->hub_max_packet == 0U || state->hub_max_packet > PAGE_SIZE) return false;
    endpoint_id = (uint32_t)state->hub_endpoint * 2U + 1U;
    if (endpoint_id > 31U ||
        !xhci_alloc_page(state, &state->hub_ring, DMA_BIDIRECTIONAL) ||
        !xhci_alloc_page(state, &state->hub_report, DMA_FROM_DEVICE)) {
        xhci_free_page(&state->hub_ring);
        xhci_free_page(&state->hub_report);
        return false;
    }
    xhci_init_ring_link(&state->hub_ring);
    state->hub_enqueue = 0U;
    state->hub_cycle = 1U;
    state->hub_transfer_pending = false;
    state->hub_change_bitmap = 0U;
    input = (uint32_t *)state->input_context.cpu;
    control = input;
    input_slot = (uint32_t *)((uint8_t *)input + state->context_size);
    output_slot = (uint32_t *)state->output_context.cpu;
    endpoint = (uint32_t *)((uint8_t *)input +
                            state->context_size * (endpoint_id + 1U));
    for (uint32_t i = 0U;
         i < 4U;
         ++i)
    {
        input_slot[i] =
            output_slot[i];
    }

    /*
     * Tell the xHC that this Slot is a Hub.
     */
    input_slot[0] |=
        XHCI_SLOT_HUB;

    /*
     * MTT is valid only for a High-Speed multi-TT Hub.
     */
    input_slot[0] &=
        ~XHCI_SLOT_MTT;

    if(state->device_speed == 3U &&
       state->hub_protocol ==
           USB_HUB_PROTOCOL_MULTI_TT)
    {
        input_slot[0] |=
            XHCI_SLOT_MTT;
    }

    /*
     * Number of downstream ports.
     */
    input_slot[1] &=
        ~(0xFFU <<
          XHCI_SLOT_MAX_PORTS_SHIFT);

    input_slot[1] |=
        (uint32_t)state->hub_port_count <<
        XHCI_SLOT_MAX_PORTS_SHIFT;

    /*
     * TT Think Time applies to High-Speed USB2 Hubs.
     * Full-Speed Hub Slot Context must leave it zero.
     */
    input_slot[2] &=
        ~(0x03U <<
          XHCI_SLOT_TT_THINK_SHIFT);

    if(state->device_speed == 3U)
    {
        input_slot[2] |=
            ((uint32_t)
                 state->hub_tt_think_time &
             0x03U) <<
            XHCI_SLOT_TT_THINK_SHIFT;
    }

    input_slot[0] &=
        ~(0x1FU << 27);
    input_slot[0] |= endpoint_id << 27;
    control[0] = 0U;
    control[1] = 1U | (1U << endpoint_id);
    xhci_init_endpoint_context(state, endpoint,
        state->hub_interval == 0U ? 1U : state->hub_interval, 7U,
        state->hub_max_packet, &state->hub_ring.mapping);
    dma_sync_for_device(&state->input_context.mapping);
    dma_sync_for_device(&state->hub_ring.mapping);
    dma_sync_for_device(&state->hub_report.mapping);
    if (!xhci_submit_command(state, XHCI_CONFIGURE_ENDPOINT_TYPE,
                             state->device_slot,
                             xhci_dma_address(&state->input_context.mapping), 0)) {
        xhci_free_page(&state->hub_ring);
        xhci_free_page(&state->hub_report);
        return false;
    }
    return xhci_queue_hub_status(state);
}

/*
 * V3.10.4A EXPLICIT AUDIO QUEUE
 *
 * Controller state remains in xhci_state_t.
 * Audio endpoint/ring/runtime producer state belongs to device.
 */
static bool xhci_queue_audio_transfer_device(
    xhci_state_t *state,
    xhci_device_context_t *device) {
    if(device == 0 ||
       device->device_slot == 0U)
    {
        return false;
    }


    xhci_trb_t *ring;
    uint32_t index;
    uint32_t endpoint_id;
    uint32_t transfer_bytes;
    if (state == 0 || !state->initialized || device->audio_ring.cpu == 0 ||
        device->audio_buffer.cpu == 0 || device->audio_transfer_pending ||
        device->audio_endpoint == 0U || device->audio_max_packet == 0U) return false;
    if (device->audio_stream != 0) {
        if (!device->audio_stream_queued || device->audio_frames == 0U) return false;
        uint64_t bytes = audio_stream_bytes_for_frames(device->audio_stream,
                                                       device->audio_frames);
        if (bytes == 0U || bytes > PAGE_SIZE) return false;
        transfer_bytes = (uint32_t)bytes;
        if (!device->audio_endpoint_in &&
            audio_stream_period_read(device->audio_stream, device->audio_period,
                                     device->audio_buffer.cpu, bytes) != K_OK) {
            return false;
        }
    } else {
        transfer_bytes = device->audio_max_packet;
    }
    index = device->audio_enqueue;
    if (index >= XHCI_RING_TRB_COUNT - 1U) return false;
    endpoint_id = (uint32_t)device->audio_endpoint * 2U +
                  (device->audio_endpoint_in ? 1U : 0U);
    ring = (xhci_trb_t *)device->audio_ring.cpu;
    ring[index].parameter = xhci_dma_address(&device->audio_buffer.mapping);
    ring[index].status = transfer_bytes;
    ring[index].control = (XHCI_ISOCH_TRB_TYPE << XHCI_TRB_TYPE_SHIFT) |
                          XHCI_TRB_INTERRUPT_ON_COMPLETION | XHCI_TRB_SIA |
                          (device->audio_endpoint_in ? XHCI_TRB_DIRECTION_IN : 0U) |
                          device->audio_cycle;
    ++index;
    if (index == XHCI_RING_TRB_COUNT - 1U) {
        ring[XHCI_RING_TRB_COUNT - 1U].control =
            (XHCI_LINK_TRB_TYPE << XHCI_TRB_TYPE_SHIFT) |
            device->audio_cycle | XHCI_TRB_LINK_TOGGLE_CYCLE;
        device->audio_enqueue = 0U;
        device->audio_cycle ^= 1U;
    } else {
        device->audio_enqueue = index;
    }
    device->audio_transfer_pending = true;
    dma_sync_for_device(&device->audio_ring.mapping);
    dma_sync_for_device(&device->audio_buffer.mapping);
    dma_wmb();
    *(volatile uint32_t *)(state->mmio + state->doorbell_offset +
                           (uint32_t)device->device_slot * sizeof(uint32_t)) = endpoint_id;
    __asm__ volatile ("mfence" : : : "memory");
    return true;
}


/*
 * V3.10.6B7A-FIX2 AUDIO WRAPPER REMOVED
 *
 * xhci_queue_audio_transfer() removed.
 *
 * Unpublished setup paths configure Audio directly, while published
 * runtime Audio uses xhci_queue_audio_transfer_device(state, device).
 */



static bool xhci_configure_audio_endpoint(xhci_state_t *state) {
    uint32_t endpoint_id;
    uint32_t endpoint_type;
    if (state == 0 || state->audio_endpoint == 0U ||
        state->audio_max_packet == 0U || state->audio_max_packet > PAGE_SIZE) return false;
    endpoint_id = (uint32_t)state->audio_endpoint * 2U +
                  (state->audio_endpoint_in ? 1U : 0U);
    endpoint_type = state->audio_endpoint_in ? 5U : 1U;
    if (endpoint_id > 31U ||
        !xhci_alloc_page(state, &state->audio_ring, DMA_BIDIRECTIONAL) ||
        !xhci_alloc_page(state, &state->audio_buffer,
                         state->audio_endpoint_in ? DMA_FROM_DEVICE : DMA_TO_DEVICE)) {
        xhci_free_page(&state->audio_ring);
        xhci_free_page(&state->audio_buffer);
        return false;
    }
    state->audio_enqueue = 0U;
    state->audio_cycle = 1U;
    state->audio_transfer_pending = false;
    for (uint32_t i = 0; i < PAGE_SIZE; ++i) {
        ((uint8_t *)state->audio_buffer.cpu)[i] = 0U;
    }

    uint8_t *input = (uint8_t *)state->input_context.cpu;
    uint32_t *control = (uint32_t *)input;
    uint32_t *input_slot = (uint32_t *)(input + state->context_size);
    uint32_t *output_slot = (uint32_t *)state->output_context.cpu;
    uint32_t *endpoint = (uint32_t *)(input + state->context_size * (endpoint_id + 1U));
    for (uint32_t i = 0; i < 4U; ++i) input_slot[i] = output_slot[i];
    input_slot[0] &= ~(0x1FU << 27);
    input_slot[0] |= endpoint_id << 27;
    control[0] = 0U;
    control[1] = 1U | (1U << endpoint_id);
    endpoint[0] = ((uint32_t)state->audio_interval << 16);
    endpoint[1] = (3U << 1) | (endpoint_type << 3) |
                  ((uint32_t)state->audio_max_packet << 16);
    endpoint[2] = (uint32_t)xhci_dma_address(&state->audio_ring.mapping) | 1U;
    endpoint[3] = (uint32_t)(xhci_dma_address(&state->audio_ring.mapping) >> 32);
    endpoint[4] = 0U;
    xhci_trb_t *ring = (xhci_trb_t *)state->audio_ring.cpu;
    ring[XHCI_RING_TRB_COUNT - 1U].parameter =
        xhci_dma_address(&state->audio_ring.mapping);
    ring[XHCI_RING_TRB_COUNT - 1U].control =
        (XHCI_LINK_TRB_TYPE << XHCI_TRB_TYPE_SHIFT) |
        XHCI_TRB_CYCLE | XHCI_TRB_LINK_TOGGLE_CYCLE;
    dma_sync_for_device(&state->input_context.mapping);
    dma_sync_for_device(&state->audio_ring.mapping);
    dma_sync_for_device(&state->audio_buffer.mapping);
    if (!xhci_submit_command(state, XHCI_CONFIGURE_ENDPOINT_TYPE,
                             state->device_slot,
                             xhci_dma_address(&state->input_context.mapping), 0)) {
        xhci_free_page(&state->audio_ring);
        xhci_free_page(&state->audio_buffer);
        return false;
    }
    /* 端点配置完成后等待统一音频服务提交第一个周期。 */
    return true;
}

/*
 * V3.10.6B9E
 *
 * xhci_detach_device() removed.
 *
 * Working and published device lifetimes now use the explicit
 * teardown architecture directly.
 */


static bool xhci_prepare_connected_port(xhci_state_t *state, uint8_t port,
                                        uint8_t *speed_out) {
    uint32_t offset;
    uint32_t portsc;
    if (state == 0 || speed_out == 0 || port == 0U || port > state->max_ports) {
        return false;
    }
    offset = state->operational_offset + XHCI_PORT_REGISTER_BASE +
             (uint32_t)(port - 1U) * XHCI_PORT_REGISTER_STRIDE;
    portsc = xhci_read32(state, offset);
    if (portsc == UINT32_MAX || (portsc & XHCI_PORTSC_CCS) == 0U) return false;
    if ((portsc & XHCI_PORTSC_PED) == 0U) {
        if (!xhci_write32(state, offset, XHCI_PORTSC_PR)) {
            g_xhci_error = 50U;
            return false;
        }
        bool enabled = false;
        for (uint32_t spin = 0; spin < 100000U; ++spin) {
            portsc = xhci_read32(state, offset);
            if ((portsc & XHCI_PORTSC_PED) != 0U &&
                (portsc & XHCI_PORTSC_PR) == 0U) {
                enabled = true;
                break;
            }
            __asm__ volatile ("pause");
        }
        if (!enabled) {
            g_xhci_error = 51U;
            return false;
        }
    }
    (void)xhci_write32(state, offset, XHCI_PORTSC_PRC);
    uint32_t speed = (portsc >> XHCI_PORTSC_SPEED_SHIFT) & XHCI_PORTSC_SPEED_MASK;
    if (speed == 0U) {
        g_xhci_error = 52U;
        return false;
    }
    *speed_out = (uint8_t)speed;
    return true;
}

static void xhci_attach_device(xhci_state_t *state, uint8_t port) {
    uint8_t speed = 0U;
    uint8_t slot = 0U;
    if (!xhci_prepare_connected_port(state, port, &speed)) return;
    if (!xhci_submit_command(state, XHCI_COMMAND_RING_TYPE, 0U, 0U, &slot) ||
        slot == 0U || !xhci_enumerate_device(state, slot, port, speed,
                                             port, 0U, 0U, 0U)) {
        if (slot != 0U) {
            (void)xhci_submit_command(state, XHCI_DISABLE_SLOT_TYPE, slot, 0U, 0);
        }
        xhci_free_device_resources(state);
        xhci_clear_device_flags();
        if (g_xhci_error == 0U) g_xhci_error = 62U;
    }
}

/*
 * V3.9.2 ROOT PORT SLOT LOOKUP
 *
 * Root-port discovery is entirely Slot Table based.
 */
static bool xhci_slot_has_root_port(
    const xhci_state_t *state,
    uint8_t port)
{
    if(state == 0 ||
       port == 0U)
    {
        return false;
    }


    uint32_t limit =
        state->max_slots;


    if(limit >=
       XHCI_MAX_SLOT_TABLE)
    {
        limit =
            XHCI_MAX_SLOT_TABLE -
            1U;
    }


    for(uint32_t slot = 1U;
        slot <= limit;
        ++slot)
    {
        const xhci_slot_device_t *slot_dev =
            &g_xhci_slot_devices[
                slot];


        if(!slot_dev->used ||
           slot_dev->context.device_slot !=
               (uint8_t)slot)
        {
            continue;
        }


        if(slot_dev->context.root_port ==
           port)
        {
            return true;
        }
    }


    return false;
}


/*
 * V3.10.6B6A LAST PUBLISHED ACTIVATOR REMOVED
 *
 * xhci_activate_next_slot_device() removed.
 *
 * Published devices are permanently addressed through
 * g_xhci_slot_devices[slot].context.
 *
 * state->device is not a runtime device-selection mechanism.
 */


/*
 * V3.9.2 ROOT PORT DIRECT SLOT REMOVE
 *
 * Root-port disconnect starts from root-level Slot nodes and lets
 * the Slot child topology recursively remove every descendant.
 *
 * No inventory traversal.
 */
static bool xhci_remove_root_port_devices(
    xhci_state_t *state,
    uint8_t port)
{
    bool changed =
        false;


    if(state == 0 ||
       port == 0U)
    {
        return false;
    }


    uint32_t limit =
        state->max_slots;


    if(limit >=
       XHCI_MAX_SLOT_TABLE)
    {
        limit =
            XHCI_MAX_SLOT_TABLE -
            1U;
    }


    /*
     * Normally one root port owns one top-level Slot.
     *
     * Scan all Slot IDs anyway so stale/corrupt topology cannot
     * leave a second root-level object alive.
     */
    for(uint32_t slot = 1U;
        slot <= limit;
        ++slot)
    {
        xhci_slot_device_t *slot_dev =
            &g_xhci_slot_devices[
                slot];


        if(!slot_dev->used ||
           slot_dev->context.device_slot !=
               (uint8_t)slot ||
           slot_dev->context.root_port !=
               port ||
           slot_dev->context.parent_slot !=
               0U)
        {
            continue;
        }







        if(xhci_remove_device_subtree(
               state,
               (uint8_t)slot))
        {
            changed =
                true;
        }
    }




    /*
     * V3.10.6B6A
     *
     * No published Slot is activated into state->device.
     */



    xhci_recompute_topology(
        state);


    return changed;
}

/*
 * V3.10.6B8C CANONICAL WORKING-CONTEXT PUBLICATION
 *
 * Publish a newly enumerated device directly into its
 * canonical Slot.context.
 *
 * No publication path uses a secondary device store or leaves a
 * published device installed in state->device.
 */
/*
 * V3.10.6B9E-FIX3 DMA DIAGNOSTIC CLEANUP
 *
 * The DMA ownership-move fix is runtime-validated.
 * Temporary 681..698 failure staging has been removed.
 */
/*
 * V3.10.6B9E-FIX2 DMA MAPPING OWNERSHIP MOVE
 *
 * xhci_device_context_t contains embedded dma_mapping_t objects.
 *
 * A published device therefore cannot be transferred with a raw
 * structure copy alone: DMA Core registers the address of each
 * dma_mapping_t.
 *
 * Copy ordinary device state first, hide the destination from Slot
 * lookup with device_slot == 0, then move all DMA mapping identities
 * to their permanent Slot.context addresses.
 */
static bool xhci_move_device_context(
    xhci_device_context_t *destination,
    xhci_device_context_t *source)
{
    if(destination == 0 ||
       source == 0 ||
       destination == source ||
       source->device_slot == 0U)
    {
        return false;
    }

    dma_mapping_t *destination_mappings[] = {
        &destination->input_context.mapping,
        &destination->output_context.mapping,
        &destination->ep0_ring.mapping,
        &destination->descriptor_buffer.mapping,
        &destination->hid_ring.mapping,
        &destination->hid_report.mapping,
        &destination->audio_ring.mapping,
        &destination->audio_buffer.mapping,
        &destination->bt_event_ring.mapping,
        &destination->bt_event_buffer.mapping,
        &destination->bt_acl_in_ring.mapping,
        &destination->bt_acl_in_buffer.mapping,
        &destination->bt_acl_out_ring.mapping,
        &destination->bt_acl_out_buffer.mapping,
        &destination->hub_ring.mapping,
        &destination->hub_report.mapping,
    };

    dma_mapping_t *source_mappings[] = {
        &source->input_context.mapping,
        &source->output_context.mapping,
        &source->ep0_ring.mapping,
        &source->descriptor_buffer.mapping,
        &source->hid_ring.mapping,
        &source->hid_report.mapping,
        &source->audio_ring.mapping,
        &source->audio_buffer.mapping,
        &source->bt_event_ring.mapping,
        &source->bt_event_buffer.mapping,
        &source->bt_acl_in_ring.mapping,
        &source->bt_acl_in_buffer.mapping,
        &source->bt_acl_out_ring.mapping,
        &source->bt_acl_out_buffer.mapping,
        &source->hub_ring.mapping,
        &source->hub_report.mapping,
    };

    uint32_t mapping_count =
        (uint32_t)(
            sizeof(destination_mappings) /
            sizeof(destination_mappings[0]));

    /*
     * A tentative Slot must not already own a published context.
     */
    if(destination->device_slot != 0U)
    {


        return false;
    }

    /*
     * Never overwrite an existing DMA owner.
     */
    for(uint32_t i = 0U;
        i < mapping_count;
        ++i)
    {
        dma_mapping_t *mapping =
            destination_mappings[i];

        if(mapping->device != 0 ||
           mapping->pages != 0 ||
           mapping->page_count != 0U ||
           mapping->segments != 0 ||
           mapping->segment_count != 0U ||
           mapping->mapped_length != 0U ||
           mapping->flags != 0U)
        {


            return false;
        }
    }

    uint8_t slot =
        source->device_slot;

    /*
     * Ordinary fields are movable by value.
     *
     * DMA mappings below are immediately replaced by real ownership
     * moves before the destination becomes visible as published.
     */
    *destination =
        *source;

    destination->device_slot =
        0U;

    /*
     * Remove the shallow mapping copies before dma_mapping_move().
     */
    for(uint32_t i = 0U;
        i < mapping_count;
        ++i)
    {
        *destination_mappings[i] =
            (dma_mapping_t){0};
    }

    uint32_t moved =
        0U;

    for(;
        moved < mapping_count;
        ++moved)
    {
        if(dma_mapping_move(
               destination_mappings[moved],
               source_mappings[moved]) !=
           K_OK)
        {
            /*
             * Publication has not happened yet.  Restore every
             * mapping already moved so state->device remains the
             * sole working owner on an ordinary failure.
             */
            uint32_t rollback =
                moved;

            while(rollback != 0U)
            {
                --rollback;

                if(dma_mapping_move(
                       source_mappings[rollback],
                       destination_mappings[rollback]) !=
                   K_OK)
                {
                    /*
                     * This indicates DMA registry corruption rather
                     * than an xHCI enumeration failure.  Keep both
                     * contexts intact for diagnosis.
                     */


                    return false;
                }
            }

            xhci_zero_device_context(
                destination);



            return false;
        }
    }

    /*
     * DMA ownership is now permanently registered against
     * Slot.context.  Publish identity last.
     */
    destination->device_slot =
        slot;

    /*
     * Source mappings were zeroed by dma_mapping_move(); clear the
     * remaining moved non-DMA state without touching the new owner.
     */
    xhci_zero_device_context(
        source);

    return true;
}


static bool xhci_publish_working_device(
    xhci_state_t *state)
{
    if(state == 0 ||
       state->device.device_slot == 0U)
    {
        return false;
    }

    uint8_t slot =
        state->device.device_slot;

    xhci_slot_device_t *slot_dev =
        &g_xhci_slot_devices[
            slot];

    if(!slot_dev->used)
    {
        return false;
    }

    if(!xhci_move_device_context(
           &slot_dev->context,
           &state->device))
    {
        return false;
    }

    /*
     * V3.10.6B10B2-FIX1 CANONICAL HUB CLASSIFICATION
     *
     * Slot.context is the permanent published device owner.
     *
     * Slot Table topology metadata must therefore be derived from
     * that canonical context at the publication boundary.
     *
     * Without this, a successfully enumerated Hub remains:
     *
     *     slot_dev->is_hub == false
     *
     * and xhci_probe_hub_downstream() skips it completely.
     */
    slot_dev->slot_id =
        slot_dev->context.device_slot;

    slot_dev->speed =
        slot_dev->context.device_speed;

    slot_dev->parent_slot =
        slot_dev->context.parent_slot;

    slot_dev->parent_port =
        slot_dev->context.parent_port;

    slot_dev->root_port =
        slot_dev->context.root_port;

    slot_dev->route_string =
        slot_dev->context.route_string;

    slot_dev->is_hub =
        slot_dev->context.hub_interface_present &&
        slot_dev->context.hub_port_count != 0U;

    slot_dev->hub_port_count =
        slot_dev->is_hub
            ? slot_dev->context.hub_port_count
            : 0U;

    slot_dev->hub_protocol =
        slot_dev->is_hub
            ? slot_dev->context.hub_protocol
            : 0U;


    /*
     * Publish the parent -> child cache edge only after Slot.context
     * owns the device permanently.
     *
     * parent_slot/parent_port in Slot Table remains canonical;
     * child_slots[] is only an acceleration cache.
     */
    if(slot_dev->parent_slot != 0U &&
       slot_dev->parent_port != 0U &&
       slot_dev->parent_port <= 16U)
    {
        xhci_slot_device_t *parent =
            &g_xhci_slot_devices[
                slot_dev->parent_slot];


        if(parent->used &&
           parent->is_hub &&
           parent->context.device_slot ==
               slot_dev->parent_slot)
        {
            parent->child_slots[
                slot_dev->parent_port - 1U] =
                slot;
        }
    }


    /*
     * Published devices require no secondary context locator.
     */




    xhci_clear_device_flags();

    /*
     * Slot Table is canonical, so rebuild every public presence
     * flag from the table.
     */
    xhci_recompute_topology(
        state);

    return true;
}


static bool xhci_attach_root_runtime_device(
    xhci_state_t *state,
    uint8_t port)
{
    if(state == 0 ||
       port == 0U ||
       port > state->max_ports)
    {
        return false;
    }

    /*
     * Runtime event processing is serialized.
     *
     * A published device must never be parked here. If this is
     * non-empty, another enumeration transaction owns the working
     * context and this topology operation must not destroy it.
     */
    if(state->device.device_slot != 0U)
    {
        return false;
    }

    xhci_attach_device(
        state,
        port);

    if(state->device.device_slot == 0U)
    {
        xhci_recompute_topology(
            state);

        return false;
    }

    /*
     * Enumeration must have produced a real functional device
     * before it can become canonical.
     */
    uint8_t kind =
        xhci_context_kind(
            &state->device);

    if(kind == 0U ||
       !xhci_publish_working_device(
           state))
    {
        if(state->device.device_slot != 0U)
        {
            (void)xhci_release_working_device(
                state);
        }

        xhci_recompute_topology(
            state);

        return false;
    }

    /*
     * Success invariant:
     *
     *     new runtime device -> Slot.context
     *     state->device      -> empty
     */
    return true;
}

static bool xhci_handle_root_port_event(xhci_state_t *state, uint8_t port,
                                        uint32_t portsc) {
    bool changed = false;
    if (state == 0 || port == 0U || port > state->max_ports ||
        portsc == UINT32_MAX) return false;
    if ((portsc & XHCI_PORTSC_CCS) == 0U) {
        changed = xhci_remove_root_port_devices(state, port);
    } else if (!xhci_slot_has_root_port(state, port)) {
        changed = xhci_attach_root_runtime_device(state, port);
    }
    uint32_t offset = state->operational_offset + XHCI_PORT_REGISTER_BASE +
                      (uint32_t)(port - 1U) * XHCI_PORT_REGISTER_STRIDE;
    (void)xhci_write32(state, offset, XHCI_PORTSC_PRC);
    if (changed) liteos_serial_write("LITEOS_USB_RUNTIME_ROOT_CHANGE\r\n");
    return changed || (portsc & XHCI_PORTSC_CCS) != 0U;
}

/*
 * V3.10.6B9E CANONICAL REENUMERATION SELF TEST
 *
 * The self-test receives a published Slot.context explicitly.
 *
 * Re-enumeration therefore follows the same ownership transitions
 * as a real runtime root-device replacement:
 *
 *     Slot.context
 *          |
 *          v
 *     remove Slot subtree
 *          |
 *          v
 *     state->device enumeration
 *          |
 *          v
 *     publish Slot.context
 */

static bool xhci_reenumerate_self_test(
    xhci_state_t *state,
    xhci_device_context_t *device)
{
    if(state == 0 ||
       device == 0 ||
       device->device_slot == 0U ||
       device->device_port == 0U)
    {
        return false;
    }


    /*
     * The self-test only re-enumerates a root device.
     *
     * A downstream device is already covered by the Hub topology
     * enumeration path and must not be detached independently from
     * its parent.
     */
    if(device->parent_slot != 0U)
    {
        return true;
    }


    uint8_t old_slot =
        device->device_slot;

    uint8_t port =
        device->root_port != 0U
        ? device->root_port
        : device->device_port;


    if(port == 0U ||
       port > state->max_ports)
    {
        g_xhci_error =
            66U;

        return false;
    }


    uint32_t offset =
        state->operational_offset +
        XHCI_PORT_REGISTER_BASE +
        (uint32_t)(port - 1U) *
            XHCI_PORT_REGISTER_STRIDE;


    /*
     * Published context must actually belong to the supplied Slot.
     */
    xhci_slot_device_t *old_slot_dev =
        &g_xhci_slot_devices[
            old_slot];


    if(!old_slot_dev->used ||
       &old_slot_dev->context !=
           device ||
       old_slot_dev->context.device_slot !=
           old_slot)
    {
        g_xhci_error =
            66U;

        return false;
    }


    /*
     * state->device must be free before beginning another
     * enumeration transaction.
     */
    if(state->device.device_slot != 0U)
    {
        g_xhci_error =
            66U;

        return false;
    }


    /*
     * Real published teardown:
     *
     * Hub roots also lose their downstream subtree here.
     */
    if(!xhci_remove_device_subtree(
           state,
           old_slot))
    {
        g_xhci_error =
            66U;

        return false;
    }


    uint32_t portsc =
        xhci_read32(
            state,
            offset);


    if(portsc == UINT32_MAX ||
       (portsc & XHCI_PORTSC_CCS) == 0U)
    {
        g_xhci_error =
            66U;

        return false;
    }


    /*
     * Re-enumerate into unpublished working storage.
     */
    xhci_attach_device(
        state,
        port);


    if(state->device.device_slot == 0U)
    {
        if(g_xhci_error == 0U)
        {
            g_xhci_error =
                67U;
        }

        return false;
    }


    uint8_t kind =
        xhci_context_kind(
            &state->device);


    if(kind == 0U ||
       !xhci_publish_working_device(
           state))
    {
        if(state->device.device_slot != 0U)
        {
            (void)
                xhci_release_working_device(
                    state);
        }

        if(g_xhci_error == 0U)
        {
            g_xhci_error =
                67U;
        }

        return false;
    }


    /*
     * A Hub root may have lost its complete downstream tree during
     * removal. Rebuild all visible Hub descendants before declaring
     * the controller ready for runtime.
     */
    if(!xhci_probe_hub_downstream(
           state))
    {
        if(g_xhci_error == 0U)
        {
            g_xhci_error =
                67U;
        }

        return false;
    }


    xhci_recompute_topology(
        state);


    /*
     * Publication empties working storage.
     */
    if(state->device.device_slot != 0U ||
       !xhci_slot_has_root_port(
           state,
           port))
    {
        g_xhci_error =
            67U;

        return false;
    }


    return true;
}

/*
 * V3.10.6B8H EXPLICIT WORKING DEVICE KIND
 *
 * xhci_current_device_kind() removed.
 *
 * Device classification is always performed on the explicit
 * context whose ownership is known at the call site.
 */


/*
 * V3.10.6B8C INVENTORY REMOVED
 *
 * Successful enumeration publishes directly to Slot.context.
 * Self-test selection scans the Slot Table directly.
 */
static bool xhci_probe_connected_ports(
    xhci_state_t *state,
    uint8_t *selected_slot)
{
    if(state == 0 ||
       selected_slot == 0)
    {
        return false;
    }

    *selected_slot =
        0U;


    for(uint32_t port = 1U;
        port <= state->max_ports;
        ++port)
    {
        uint32_t offset =
            state->operational_offset +
            XHCI_PORT_REGISTER_BASE +
            (port - 1U) *
                XHCI_PORT_REGISTER_STRIDE;

        uint32_t portsc =
            xhci_read32(
                state,
                offset);

        uint8_t speed =
            0U;

        uint8_t slot =
            0U;


        if(portsc == UINT32_MAX ||
           (portsc & XHCI_PORTSC_CCS) == 0U ||
           !xhci_prepare_connected_port(
               state,
               (uint8_t)port,
               &speed) ||
           !xhci_submit_command(
               state,
               XHCI_COMMAND_RING_TYPE,
               0U,
               0U,
               &slot) ||
           slot == 0U)
        {
            continue;
        }


        if(xhci_enumerate_device(
               state,
               slot,
               (uint8_t)port,
               speed,
               (uint8_t)port,
               0U,
               0U,
               0U))
        {
            uint8_t kind =
                xhci_context_kind(
                    &state->device);

            if(kind != 0U &&
               xhci_publish_working_device(
                   state))
            {
                continue;
            }
        }


        if(slot != 0U)
        {
            (void)xhci_submit_command(
                state,
                XHCI_DISABLE_SLOT_TYPE,
                slot,
                0U,
                0);
        }

        (void)xhci_free_device_resources(
            state);

        xhci_zero_device_context(
            &state->device);

        xhci_clear_device_flags();

        g_xhci_error =
            70U;

        return false;
    }


    if(!xhci_probe_hub_downstream(
           state))
    {
        return false;
    }


    xhci_recompute_topology(
        state);


    uint32_t limit =
        state->max_slots;

    if(limit >=
       XHCI_MAX_SLOT_TABLE)
    {
        limit =
            XHCI_MAX_SLOT_TABLE -
            1U;
    }


    /*
     * Preserve previous self-test preference:
     *
     * pass 0 -> non-Hub device
     * pass 1 -> Hub fallback
     */
    for(uint32_t pass = 0U;
        pass < 2U;
        ++pass)
    {
        for(uint32_t slot = 1U;
            slot <= limit;
            ++slot)
        {
            xhci_slot_device_t *slot_dev =
                &g_xhci_slot_devices[
                    slot];

            if(!slot_dev->used ||
               slot_dev->context.device_slot !=
                   (uint8_t)slot)
            {
                continue;
            }

            uint8_t kind =
                xhci_context_kind(
                    &slot_dev->context);

            if(kind == 0U)
            {
                continue;
            }

            if(pass == 0U &&
               kind == 4U)
            {
                continue;
            }

            *selected_slot =
                (uint8_t)slot;

            return true;
        }
    }


    return false;
}

/*
 * V3.10.6B4 CANONICAL HUB TRANSFER EVENT
 *
 * Transfer Event Slot ID is the permanent hardware identity.
 *
 *     Transfer Event Slot ID
 *              |
 *              v
 *         Slot.context
 *              |
 *              +--> completion state
 *              +--> status bitmap
 *              +--> interrupt-IN re-arm
 *
 * Published Hub state is never installed into state->device.
 * Inventory metadata is not part of runtime event routing.
 */
static bool xhci_handle_hub_transfer_event(
    xhci_state_t *state,
    const xhci_trb_t *event)
{
    /*
     * V3.10.6B10B3-DIAG1 HUB HOTPLUG PATH
     *
     * Print only when this Transfer Event belongs to a published
     * Hub Slot, so normal HID Transfer Events cannot spam serial.
     */
    if(event != 0)
    {
        uint8_t diag_slot =
            (uint8_t)(
                event->control >>
                XHCI_TRB_SLOT_SHIFT);

        if(diag_slot != 0U)
        {
            xhci_slot_device_t *diag_dev =
                &g_xhci_slot_devices[
                    diag_slot];

            if(diag_dev->used &&
               diag_dev->is_hub &&
               diag_dev->context.device_slot ==
                   diag_slot)
            {
                liteos_serial_write(
                    "LITEOS_DIAG_HUB_TRANSFER_EVENT\r\n");
            }
        }
    }


    if(state == 0 ||
       event == 0 ||
       ((event->control >>
         XHCI_TRB_TYPE_SHIFT) &
        0x3FU) !=
           XHCI_TRANSFER_EVENT_TYPE)
    {
        return false;
    }

    uint8_t slot =
        (uint8_t)(
            event->control >>
            XHCI_TRB_SLOT_SHIFT);

    if(slot == 0U)
    {
        return false;
    }

    xhci_slot_device_t *slot_dev =
        &g_xhci_slot_devices[slot];

    /*
     * Runtime Hub events are accepted only for a published,
     * internally consistent Hub Slot.
     */
    if(!slot_dev->used ||
       !slot_dev->is_hub ||
       slot_dev->context.device_slot != slot ||
       slot_dev->context.hub_endpoint == 0U)
    {
        return false;
    }

    xhci_device_context_t *device =
        &slot_dev->context;

    uint32_t endpoint_id =
        (event->control >>
         XHCI_TRB_ENDPOINT_SHIFT) &
        0x1FU;

    if(endpoint_id !=
       (uint32_t)device->hub_endpoint *
           2U + 1U)
    {
        return false;
    }

    uint32_t completion =
        event->status >>
        XHCI_COMPLETION_SHIFT;

    device->hub_transfer_pending =
        false;

    if(completion ==
       XHCI_COMPLETION_SUCCESS)
    {
        uint32_t bytes =
            (device->hub_port_count +
             8U) /
            8U;

        uint32_t bitmap =
            0U;

        if(bytes >
           device->hub_max_packet)
        {
            bytes =
                device->hub_max_packet;
        }

        if(bytes >
           PAGE_SIZE)
        {
            bytes =
                PAGE_SIZE;
        }

        dma_sync_for_cpu(
            &device->hub_report.mapping);

        for(uint32_t port = 1U;
            port <=
                device->hub_port_count;
            ++port)
        {
            uint32_t byte =
                port / 8U;

            uint32_t bit =
                port % 8U;

            if(byte < bytes &&
               (((const uint8_t *)
                    device->hub_report.cpu)
                    [byte] &
                 (1U << bit)) != 0U)
            {
                bitmap |=
                    1U <<
                    (port - 1U);
            }
        }

        device->hub_change_bitmap |=
            bitmap;

        (void)xhci_queue_hub_status_device(
            state,
            device);
    }
    else if(completion != 0U)
    {
        /*
         * Disconnect may stop/cancel interrupt-IN.
         * Topology reconciliation performs final removal.
         */
        g_xhci_error =
            73U +
            completion;
    }

    return true;
}



/*
 * HID context lookup is now independent of context storage.
 *
 * Slot ID is the only device identity.
 */
/*
 * V3.10.6B8G HID-ONLY WORKING CONTEXT FALLBACK
 *
 * HID is the one Transfer Event path that may legitimately see an
 * interrupt completion before enumeration has published state->device
 * into Slot.context.
 *
 * Ownership order is intentionally:
 *
 *     published Slot.context
 *              |
 *              v
 *     enumeration state->device fallback
 *
 * Never reverse this order: a published HID must always mutate the
 * permanent Slot.context.
 */
static xhci_device_context_t *
xhci_find_hid_context(
    xhci_state_t *state,
    uint8_t slot,
    uint32_t endpoint_id)
{
    if(state == 0 ||
       slot == 0U)
    {
        return 0;
    }


    xhci_device_context_t *device =
        0;

    xhci_slot_device_t *slot_dev =
        &g_xhci_slot_devices[
            slot];


    /*
     * Published HID always wins.
     *
     * This preserves the V3.9.6 mouse regression fix.
     */
    if(slot_dev->used &&
       slot_dev->context.device_slot ==
           slot)
    {
        device =
            &slot_dev->context;
    }
    else if(state->device.device_slot ==
            slot)
    {
        /*
         * Enumeration-only fallback.
         *
         * HID configuration posts its first interrupt-IN before
         * the completed working context is published.
         */
        device =
            &state->device;
    }


    if(device == 0 ||
       device->hid_endpoint == 0U)
    {
        return 0;
    }


    if(endpoint_id !=
       (uint32_t)
           device->hid_endpoint *
           2U + 1U)
    {
        return 0;
    }


    return device;
}



static bool xhci_handle_hid_transfer_event(xhci_state_t *state,
                                           const xhci_trb_t *event) {
    xhci_device_context_t *device;
    uint8_t slot;
    uint32_t endpoint_id;
    uint32_t completion;
    uint32_t residual;
    uint32_t report_length;
    if (state == 0 || event == 0 ||
        ((event->control >> XHCI_TRB_TYPE_SHIFT) & 0x3FU) !=
            XHCI_TRANSFER_EVENT_TYPE) return false;
    slot = (uint8_t)(event->control >> XHCI_TRB_SLOT_SHIFT);
    endpoint_id = (event->control >> XHCI_TRB_ENDPOINT_SHIFT) & 0x1FU;
    device = xhci_find_hid_context(state, slot, endpoint_id);
    if (device == 0) return false;
    completion = event->status >> XHCI_COMPLETION_SHIFT;
    residual = event->status & 0x00FFFFFFU;
    if (!atomic_exchange_explicit(&g_xhci_hid_transfer_seen, true,
                                  memory_order_acq_rel)) {
        liteos_serial_write("LITEOS_XHCI_HID_TRANSFER_OK\r\n");
    }
    (void)atomic_fetch_add_explicit(&g_xhci_hid_completion_count, 1U,
                                    memory_order_relaxed);
    device->hid_transfer_pending = false;
    if ((completion == XHCI_COMPLETION_SUCCESS ||
         completion == XHCI_COMPLETION_SHORT_PACKET) &&
        residual <= device->hid_max_packet) {
        report_length = device->hid_max_packet - residual;
        dma_sync_for_cpu(&device->hid_report.mapping);
        xhci_hid_consume_report(device, report_length);
        (void)xhci_queue_hid_report(state, device);
    } else if (completion != 0U) {
        /* Endpoint cancellation during unplug is recovered by the topology
         * path; for a still-visible HID context, reset the endpoint and arm a
         * fresh interrupt transfer.  Without this recovery a completion code
         * such as Stopped leaves the desktop's input waiter asleep forever. */
        if (!xhci_restart_hid_endpoint(state, device)) {
            g_xhci_error = 60U + completion;
        } else {
            g_xhci_error = 0U;
        }
    }
        /*
     * V3.10.6B8D
     *
     * device already is Slot.context for every published HID.
     * An unpublished enumeration context remains state->device
     * until explicit publication.
     */


return true;
}



/*
 * V3.8.5 AUDIO CANONICAL SLOT EVENT
 *
 * Audio completion ownership:
 *
 *      Transfer Event Slot ID
 *                |
 *                v
 *       xhci_slot_context_owner()
 *                |
 *          +-----+-----+
 *          |           |
 *       active     Slot.context
 *
 * inventory[].context is no longer an Audio event owner.
 */
/*
 * V3.10.6B7A CANONICAL AUDIO TRANSFER EVENT
 *
 * Transfer Event Slot ID is the permanent Audio device identity.
 *
 *     Transfer Event Slot ID
 *              |
 *              v
 *         Slot.context
 *              |
 *       completion/re-arm
 *
 * Published Audio state is never installed into state->device.
 * inventory[] is not part of Audio runtime routing.
 */
static bool xhci_handle_audio_transfer_event(
    xhci_state_t *state,
    const xhci_trb_t *event)
{
    if(state == 0 ||
       event == 0 ||
       ((event->control >>
         XHCI_TRB_TYPE_SHIFT) &
        0x3FU) !=
           XHCI_TRANSFER_EVENT_TYPE)
    {
        return false;
    }

    uint8_t slot =
        (uint8_t)(
            event->control >>
            XHCI_TRB_SLOT_SHIFT);

    if(slot == 0U)
    {
        return false;
    }

    xhci_slot_device_t *slot_dev =
        &g_xhci_slot_devices[
            slot];

    if(!slot_dev->used ||
       slot_dev->context.device_slot !=
           slot ||
       slot_dev->context.audio_endpoint ==
           0U)
    {
        return false;
    }

    xhci_device_context_t *device =
        &slot_dev->context;

    uint32_t endpoint_id =
        (event->control >>
         XHCI_TRB_ENDPOINT_SHIFT) &
        0x1FU;

    uint32_t expected_endpoint_id =
        (uint32_t)
            device->audio_endpoint *
            2U +
        (device->audio_endpoint_in
             ? 1U
             : 0U);

    if(endpoint_id !=
       expected_endpoint_id)
    {
        return false;
    }

    uint32_t completion =
        event->status >>
        XHCI_COMPLETION_SHIFT;

    device->audio_transfer_pending =
        false;

    if(completion ==
       XHCI_COMPLETION_SUCCESS)
    {
        dma_sync_for_cpu(
            &device->
                audio_buffer.mapping);

        ++device->
            audio_completed;

        if(device->audio_stream != 0)
        {
            if(device->audio_endpoint_in &&
               device->audio_stream_queued)
            {
                uint64_t bytes =
                    audio_stream_bytes_for_frames(
                        device->audio_stream,
                        device->audio_frames);

                if(bytes != 0U &&
                   bytes <= PAGE_SIZE)
                {
                    (void)
                        audio_stream_period_write(
                            device->audio_stream,
                            device->audio_period,
                            device->
                                audio_buffer.cpu,
                            bytes);
                }
            }

            device->audio_stream_queued =
                false;
        }
        else if(!device->
                    audio_stream_bound)
        {
            /*
             * Legacy autonomous mode:
             * explicit queue uses device->device_slot for doorbell.
             */
            (void)
                xhci_queue_audio_transfer_device(
                    state,
                    device);
        }
    }
    else if(completion != 0U)
    {
        device->audio_stream_queued =
            false;

        g_xhci_error =
            64U +
            completion;
    }

    return true;
}



static bool xhci_process_event_ring(xhci_state_t *state, uint32_t budget) {
    bool consumed = false;
    bool topology_event = false;
    if (state == 0 || !state->initialized) return false;
    for (uint32_t i = 0U; i < budget; ++i) {
        xhci_trb_t event;
        if (!xhci_next_event(state, &event)) break;
        uint32_t type = (event.control >> XHCI_TRB_TYPE_SHIFT) & 0x3FU;
        if (type == XHCI_PORT_STATUS_CHANGE_TYPE) {
            uint8_t port = (uint8_t)(event.parameter >> 24);
            if (port != 0U && port <= state->max_ports) {
                uint32_t port_offset = state->operational_offset + XHCI_PORT_REGISTER_BASE +
                                       (uint32_t)(port - 1U) * XHCI_PORT_REGISTER_STRIDE;
                uint32_t portsc = xhci_read32(state, port_offset);
                (void)xhci_handle_root_port_event(state, port, portsc);
                topology_event = true;
                consumed = true;
            }
        } else if (type == XHCI_TRANSFER_EVENT_TYPE &&
                   xhci_handle_bt_transfer_event(state, &event)) {
            consumed = true;
        } else if (type == XHCI_TRANSFER_EVENT_TYPE &&
                   xhci_handle_hub_transfer_event(state, &event)) {
            topology_event = true;
            consumed = true;
        } else if (type == XHCI_TRANSFER_EVENT_TYPE &&
                   xhci_handle_hid_transfer_event(state, &event)) {
            consumed = true;
        } else if(type == XHCI_TRANSFER_EVENT_TYPE &&
                   xhci_handle_audio_transfer_event(
                       state,
                       &event))
        {
            consumed =
                true;
        }
    }
    /* Hub status is reconciled only as a consequence of an xHCI event.  It
     * is never sampled from the APIC timer or another periodic poll source. */
    if (topology_event && g_xhci_usb_hub_present &&
        xhci_reconcile_hub_topology(state)) consumed = true;
    return consumed;
}

static bool xhci_submit_command_ex(xhci_state_t *state, uint32_t type,
                                   uint8_t slot, uint8_t endpoint,
                                   uint64_t parameter, uint8_t *result_slot) {
    xhci_trb_t *command_ring = (xhci_trb_t *)state->command_ring.cpu;
    /* 最后一个 TRB 固定为 Link，生产者只使用前 255 个槽位。 */
    if (state->command_index >= XHCI_RING_TRB_COUNT - 1U) {
        state->command_index = 0U;
        state->command_cycle ^= 1U;
    }
    xhci_trb_t *command = &command_ring[state->command_index];
    command->parameter = parameter;
    command->status = 0;
    command->control = (type << XHCI_TRB_TYPE_SHIFT) |
                      ((uint32_t)slot << XHCI_TRB_SLOT_SHIFT) |
                      ((uint32_t)(endpoint & 0x1FU) << XHCI_TRB_ENDPOINT_SHIFT) |
                      state->command_cycle;
    uint32_t next_command = state->command_index + 1U;
    if (next_command == XHCI_RING_TRB_COUNT - 1U) {
        /* 到达 Link TRB 时，下一轮从索引 0 继续并翻转 PCS。 */
        command_ring[XHCI_RING_TRB_COUNT - 1U].control =
            (XHCI_LINK_TRB_TYPE << XHCI_TRB_TYPE_SHIFT) |
            state->command_cycle | (1U << 1);
        state->command_index = 0U;
        state->command_cycle ^= 1U;
    } else {
        state->command_index = next_command;
    }
    dma_sync_for_device(&state->command_ring.mapping);
    dma_wmb();
    *(volatile uint32_t *)(state->mmio + state->doorbell_offset) = 0;
    __asm__ volatile ("mfence" : : : "memory");
    for (uint32_t spin = 0; spin < 200000U; ++spin) {
        xhci_trb_t event;
        if (!xhci_next_ring_event(state, &event)) {
            __asm__ volatile ("pause");
            continue;
        }
        uint32_t control = event.control;
        uint32_t event_type = (control >> XHCI_TRB_TYPE_SHIFT) & 0x3FU;
        if (event_type != XHCI_COMMAND_COMPLETION_TYPE) {
            (void)xhci_defer_event(state, &event);
            /* 非当前 PCS 的 TRB 不是新事件；若控制字非零则记录损坏迹象。 */
            continue;
        } else if (event_type == XHCI_COMMAND_COMPLETION_TYPE) {
            uint32_t completion = event.status >> XHCI_COMPLETION_SHIFT;
            uint8_t completed_slot = (uint8_t)(control >> XHCI_TRB_SLOT_SHIFT);
            if (result_slot != 0) *result_slot = completed_slot;
            if (completion != XHCI_COMPLETION_SUCCESS) {
                g_xhci_error = 32U + completion;
                return false;
            }
            g_xhci_error = 0U;
            return true;
        }
        __asm__ volatile ("pause");
    }
    if ((xhci_read32(state, state->operational_offset + XHCI_USBSTS) &
         XHCI_USBSTS_HCH) != 0U) {
        g_xhci_error = 26U;
    } else {
        g_xhci_error = 27U;
    }
    return false;
}

static bool xhci_submit_command(xhci_state_t *state, uint32_t type,
                                uint8_t slot, uint64_t parameter,
                                uint8_t *result_slot) {
    return xhci_submit_command_ex(state, type, slot, 0U, parameter, result_slot);
}

/*
 * V3.10.6B10B2-FIX3 EXTERNAL TT RESOLUTION
 *
 * Software topology uses parent_slot/parent_port.
 * Hardware Slot Context DW2 uses TT Hub Slot/TT Port instead.
 */
static bool xhci_resolve_tt(
    uint8_t child_speed,
    uint8_t parent_slot,
    uint8_t parent_port,
    uint8_t *tt_slot,
    uint8_t *tt_port,
    bool *tt_multi)
{
    if(tt_slot == 0 ||
       tt_port == 0 ||
       tt_multi == 0)
    {
        return false;
    }

    *tt_slot =
        0U;

    *tt_port =
        0U;

    *tt_multi =
        false;

    /*
     * Only Low/Full-Speed devices use an external USB2 TT.
     */
    if(child_speed > 2U ||
       parent_slot == 0U)
    {
        return true;
    }

    if(parent_port == 0U)
    {
        return false;
    }

    xhci_slot_device_t *parent =
        &g_xhci_slot_devices[
            parent_slot];

    if(!parent->used ||
       !parent->is_hub ||
       parent->context.device_slot !=
           parent_slot)
    {
        return false;
    }

    /*
     * Directly below a High-Speed Hub:
     * that Hub owns the split transaction.
     */
    if(parent->context.device_speed == 3U)
    {
        *tt_slot =
            parent_slot;

        *tt_port =
            parent_port;

        *tt_multi =
            parent->hub_protocol ==
                USB_HUB_PROTOCOL_MULTI_TT;

        return true;
    }

    /*
     * A Full/Low-Speed Hub may itself be behind a High-Speed TT.
     * All of its Full/Low-Speed descendants remain in that same
     * upstream TT domain.
     */
    if(parent->tt_slot != 0U)
    {
        *tt_slot =
            parent->tt_slot;

        *tt_port =
            parent->tt_port;

        *tt_multi =
            parent->tt_multi;
    }

    return true;
}


static bool xhci_prepare_device_resources(xhci_state_t *state, uint8_t slot,
                                          uint8_t port, uint8_t speed,
                                          uint8_t root_port, uint8_t parent_slot,
                                          uint8_t parent_port,
                                          uint8_t tt_slot,
                                          uint8_t tt_port,
                                          bool tt_multi,
                                          uint32_t route_string) {
    if (state == 0 || slot == 0U || port == 0U || speed == 0U ||
        root_port == 0U) return false;
    if (!xhci_alloc_page(state, &state->input_context, DMA_TO_DEVICE) ||
        !xhci_alloc_page(state, &state->output_context, DMA_BIDIRECTIONAL) ||
        !xhci_alloc_page(state, &state->ep0_ring, DMA_BIDIRECTIONAL) ||
        !xhci_alloc_page(state, &state->descriptor_buffer, DMA_BIDIRECTIONAL)) {
        g_xhci_error = 53U;
        xhci_free_device_resources(state);
        return false;
    }
    volatile uint64_t *dcbaa = (volatile uint64_t *)state->dcbaa.cpu;
    dcbaa[slot] = xhci_dma_address(&state->output_context.mapping);

    uint8_t *input = (uint8_t *)state->input_context.cpu;
    uint32_t *control = (uint32_t *)input;
    uint32_t *slot_context = (uint32_t *)(input + state->context_size);
    uint32_t *ep0_context = (uint32_t *)(input + state->context_size * 2U);
    control[0] = 0U;
    control[1] = 0x3U;
    slot_context[0] =
        ((uint32_t)(
            speed &
            XHCI_PORTSC_SPEED_MASK) <<
         20) |
        (route_string &
         0x000FFFFFU) |
        (1U << 27) |
        (tt_multi
             ? XHCI_SLOT_MTT
             : 0U);

    slot_context[1] =
        (uint32_t)root_port <<
        16;

    /*
     * DW2 is NOT software parent identity.
     *
     * It is the external High-Speed Transaction Translator that
     * services this Low/Full-Speed device.
     */
    slot_context[2] =
        (uint32_t)tt_slot |
        ((uint32_t)tt_port <<
         XHCI_SLOT_TT_PORT_SHIFT);
    slot_context[3] = 0U;
    uint32_t max_packet = speed >= 3U ? 64U : 8U;
    if (speed >= 4U) max_packet = 512U;
    ep0_context[0] = 0U;
    ep0_context[1] = (3U << 1) | (4U << 3) | (max_packet << 16);
    ep0_context[2] = (uint32_t)xhci_dma_address(&state->ep0_ring.mapping) | 1U;
    ep0_context[3] = (uint32_t)(xhci_dma_address(&state->ep0_ring.mapping) >> 32);
    ep0_context[4] = 0U;

    xhci_trb_t *ring = (xhci_trb_t *)state->ep0_ring.cpu;
    ring[XHCI_RING_TRB_COUNT - 1U].parameter =
        xhci_dma_address(&state->ep0_ring.mapping);
    ring[XHCI_RING_TRB_COUNT - 1U].control =
        (XHCI_LINK_TRB_TYPE << XHCI_TRB_TYPE_SHIFT) |
        XHCI_TRB_CYCLE | XHCI_TRB_LINK_TOGGLE_CYCLE;
    dma_sync_for_device(&state->dcbaa.mapping);
    dma_sync_for_device(&state->input_context.mapping);
    dma_sync_for_device(&state->output_context.mapping);
    dma_sync_for_device(&state->ep0_ring.mapping);
    dma_sync_for_device(&state->descriptor_buffer.mapping);
    state->device_slot = slot;
    state->device_port = port;
    state->device_speed = speed;
    state->root_port = root_port;
    state->parent_slot = parent_slot;
    state->parent_port = parent_port;
    state->route_string = route_string;
    state->ep0_enqueue = 0U;
    return true;
}

/*
 * V3.10.1A EXPLICIT EP0 DEVICE
 *
 * Controller-owned state:
 *   MMIO / doorbell / Event Ring
 *
 * Device-owned state:
 *   Slot ID / EP0 Ring / EP0 enqueue / descriptor buffer
 */
/*
 * V3.10.1F CONTROL WRAPPER REMOVED
 *
 * Every control-transfer caller now names its device context.
 * This stage changes API shape only; legacy callers explicitly
 * pass &state->device and retain identical ownership semantics.
 */
static bool xhci_submit_control_transfer_device(
    xhci_state_t *state,
    xhci_device_context_t *device,
    const uint8_t setup[8],
    uint32_t length,
    bool direction_in) {
    if (state == 0 || device == 0 || setup == 0 || length > PAGE_SIZE ||
        device->device_slot == 0U) return false;
    xhci_trb_t *ring = (xhci_trb_t *)device->ep0_ring.cpu;
    uint32_t index = device->ep0_enqueue;
    uint32_t transfer_trbs = length == 0U ? 2U : 3U;
    if (index + transfer_trbs >= XHCI_RING_TRB_COUNT) return false;
    uint64_t setup_value = 0;
    for (uint32_t i = 0; i < 8U; ++i) {
        setup_value |= (uint64_t)setup[i] << (i * 8U);
    }
    ring[index].parameter = setup_value;
    ring[index].status = 8U;
    ring[index].control = (XHCI_SETUP_STAGE_TYPE << XHCI_TRB_TYPE_SHIFT) |
                          XHCI_TRB_IMMEDIATE_DATA |
                          ((length != 0U ? XHCI_TRB_CHAIN : 0U)) |
                          ((length != 0U ?
                            (direction_in ? XHCI_CONTROL_TRANSFER_IN :
                             XHCI_CONTROL_TRANSFER_OUT) : 0U) <<
                           XHCI_TRB_TRANSFER_TYPE_SHIFT) | XHCI_TRB_CYCLE;
    uint32_t status_index;
    if (length != 0U) {
        ring[index + 1U].parameter =
            xhci_dma_address(&device->descriptor_buffer.mapping);
        ring[index + 1U].status = length;
        ring[index + 1U].control = (XHCI_DATA_STAGE_TYPE << XHCI_TRB_TYPE_SHIFT) |
                                   XHCI_TRB_CHAIN |
                                   (direction_in ? XHCI_TRB_DIRECTION_IN : 0U) |
                                   XHCI_TRB_CYCLE;
        status_index = index + 2U;
    } else {
        status_index = index + 1U;
    }
    ring[status_index].parameter = 0U;
    ring[status_index].status = 0U;
    ring[status_index].control = (XHCI_STATUS_STAGE_TYPE << XHCI_TRB_TYPE_SHIFT) |
                                 (direction_in ? 0U : XHCI_TRB_DIRECTION_IN) |
                                 XHCI_TRB_INTERRUPT_ON_COMPLETION | XHCI_TRB_CYCLE;
    device->ep0_enqueue = index + transfer_trbs;
    dma_sync_for_device(&device->ep0_ring.mapping);
    dma_sync_for_device(&device->descriptor_buffer.mapping);
    dma_wmb();
    *(volatile uint32_t *)(state->mmio + state->doorbell_offset +
                           (uint32_t)device->device_slot * sizeof(uint32_t)) = 1U;
    __asm__ volatile ("mfence" : : : "memory");
    for (uint32_t spin = 0; spin < 200000U; ++spin) {
        xhci_trb_t event;
        if (!xhci_next_ring_event(state, &event)) {
            __asm__ volatile ("pause");
            continue;
        }
        uint32_t type = (event.control >> XHCI_TRB_TYPE_SHIFT) & 0x3FU;
        if (type != XHCI_TRANSFER_EVENT_TYPE) {
            (void)xhci_defer_event(state, &event);
            continue;
        }
        if ((uint8_t)(event.control >> XHCI_TRB_SLOT_SHIFT) != device->device_slot ||
            ((event.control >> XHCI_TRB_ENDPOINT_SHIFT) & 0x1FU) != 1U) {
            /* 当前控制传输只消费本设备 EP0，其他事件交给统一轮询器。 */
            (void)xhci_defer_event(state, &event);
            continue;
        }
        uint32_t completion = event.status >> XHCI_COMPLETION_SHIFT;
        if (completion != XHCI_COMPLETION_SUCCESS) {
            g_xhci_error = 54U + completion;
            return false;
        }
        dma_sync_for_cpu(&device->descriptor_buffer.mapping);
        return true;
    }
    g_xhci_error = 54U;
    return false;
}

/*
 * Legacy working-context wrapper.
 *
 * V3.10.1A deliberately leaves every existing caller unchanged.
 * Later patches migrate individual subsystems to the explicit
 * device-context helper one at a time.
 */





static bool xhci_read_hub_descriptor(xhci_state_t *state) {
    static const uint8_t request[8] = {
        0xA0U, XHCI_SETUP_GET_DESCRIPTOR, 0x00U, XHCI_DESCRIPTOR_HUB,
        0x00U, 0x00U, 0x09U, 0x00U,
    };
    uint8_t *descriptor;
    if (state == 0 || !state->hub_interface_present ||
        !xhci_submit_control_transfer_device(state, &state->device,  request, 9U, true)) return false;
    descriptor = (uint8_t *)state->descriptor_buffer.cpu;
    if (descriptor[0] < 3U || descriptor[1] != XHCI_DESCRIPTOR_HUB ||
        descriptor[2] == 0U || descriptor[2] > 15U) {
        g_xhci_error = 68U;
        return false;
    }
    state->hub_port_count =
        descriptor[2];

    uint16_t hub_characteristics =
        (uint16_t)descriptor[3] |
        ((uint16_t)descriptor[4] << 8);

    state->hub_tt_think_time =
        (uint8_t)(
            (hub_characteristics >> 5) &
            0x03U);

    state->hub_configured =
        true;
    return true;
}

static bool xhci_parse_configuration(xhci_state_t *state) {
    uint8_t *descriptor;
    uint32_t total_length;
    bool hid_interface = false;
    uint8_t hid_interface_number = 0U;
    uint8_t hid_protocol = 0U;
    bool audio_interface = false;
    bool hub_interface = false;
    bool bt_interface = false;
    if (state == 0) return false;
    descriptor = (uint8_t *)state->descriptor_buffer.cpu;
    if (descriptor[0] < 9U || descriptor[1] != XHCI_DESCRIPTOR_CONFIGURATION) {
        return false;
    }
    total_length = (uint32_t)descriptor[2] | ((uint32_t)descriptor[3] << 8);
    if (total_length > PAGE_SIZE) total_length = PAGE_SIZE;
    state->configuration_value = descriptor[5];
    state->hid_interface = 0U;
    state->hid_protocol = 0U;
    state->hid_endpoint = 0U;
    state->hid_max_packet = 0U;
    state->hid_interval = 0U;
    state->audio_endpoint = 0U;
    state->audio_max_packet = 0U;
    state->audio_interval = 0U;
    state->audio_channels = 0U;
    state->audio_bit_resolution = 0U;
    state->audio_sample_rate = 0U;
    state->hub_interface = 0U;
    state->hub_interface_present = false;
    state->hub_port_count = 0U;
    state->hub_protocol = 0U;
    state->hub_tt_think_time = 0U;
    state->hub_configured = false;
    state->hub_endpoint = 0U;
    state->hub_max_packet = 0U;
    state->hub_interval = 0U;
    state->hub_enqueue = 0U;
    state->hub_cycle = 1U;
    state->hub_transfer_pending = false;
    state->hub_change_bitmap = 0U;
    state->bt_event_endpoint = 0U;
    state->bt_acl_in_endpoint = 0U;
    state->bt_acl_out_endpoint = 0U;
    state->bt_event_max_packet = 0U;
    state->bt_acl_in_max_packet = 0U;
    state->bt_acl_out_max_packet = 0U;
    state->bt_event_interval = 0U;
    for (uint32_t offset = 0U; offset + 2U <= total_length;) {
        uint8_t length = descriptor[offset];
        uint8_t type = descriptor[offset + 1U];
        if (length < 2U || offset + length > total_length) return false;
        if (type == XHCI_DESCRIPTOR_INTERFACE && length >= 9U) {
            uint8_t interface_class = descriptor[offset + 5U];
            uint8_t interface_subclass = descriptor[offset + 6U];
            uint8_t alternate = descriptor[offset + 3U];
            uint8_t interface_protocol = descriptor[offset + 7U];
            /* Boot protocol gives the driver a fixed report format, avoiding
             * a report-descriptor parser in the interrupt fast path. */
            hid_interface = interface_class == USB_CLASS_HID &&
                            interface_subclass == USB_HID_SUBCLASS_BOOT &&
                            (interface_protocol == USB_HID_PROTOCOL_KEYBOARD ||
                             interface_protocol == USB_HID_PROTOCOL_MOUSE) &&
                            alternate == 0U;
            if (hid_interface && state->hid_endpoint == 0U) {
                hid_interface_number = descriptor[offset + 2U];
                hid_protocol = interface_protocol;
            }
            audio_interface = interface_class == USB_CLASS_AUDIO &&
                              interface_subclass == USB_AUDIO_SUBCLASS_STREAM &&
                              alternate != 0U;
            hub_interface =
                interface_class == USB_CLASS_HUB &&
                alternate == 0U;
            bt_interface = interface_class == USB_CLASS_WIRELESS &&
                           interface_subclass == USB_BT_SUBCLASS &&
                           descriptor[offset + 7U] == USB_BT_PROTOCOL;
            if (audio_interface) {
                state->audio_interface = descriptor[offset + 2U];
                state->audio_alt_setting = alternate;
            }
            if (hub_interface) {
                state->hub_interface = descriptor[offset + 2U];
                state->hub_interface_present = true;
                state->hub_protocol = interface_protocol;
            }
        } else if (type == XHCI_DESCRIPTOR_CS_INTERFACE && length >= 8U &&
                   audio_interface && descriptor[offset + 2U] == 0x02U) {
            /* Audio Format Type I：记录 PCM 设备的基本约束，供上层选周期。 */
            state->audio_channels = descriptor[offset + 4U];
            state->audio_bit_resolution = descriptor[offset + 6U];
            if (descriptor[offset + 7U] == 1U && length >= 11U) {
                state->audio_sample_rate = (uint32_t)descriptor[offset + 8U] |
                    ((uint32_t)descriptor[offset + 9U] << 8) |
                    ((uint32_t)descriptor[offset + 10U] << 16);
            }
        } else if (type == XHCI_DESCRIPTOR_ENDPOINT && length >= 7U && hid_interface &&
                   (descriptor[offset + 2U] & 0x80U) != 0U &&
                   (descriptor[offset + 3U] & 0x03U) == 0x03U) {
            if (state->hid_endpoint == 0U) {
                uint8_t endpoint = descriptor[offset + 2U] & 0x0FU;
                uint16_t max_packet = (uint16_t)descriptor[offset + 4U] |
                                      ((uint16_t)descriptor[offset + 5U] << 8);
                if (endpoint != 0U && max_packet != 0U && max_packet <= PAGE_SIZE) {
                    state->hid_interface = hid_interface_number;
                    state->hid_protocol = hid_protocol;
                    state->hid_endpoint = endpoint;
                    state->hid_max_packet = max_packet;
                    state->hid_interval = descriptor[offset + 6U];
                }
            }
        } else if (type == XHCI_DESCRIPTOR_ENDPOINT && length >= 7U && hub_interface &&
                   (descriptor[offset + 2U] & 0x80U) != 0U &&
                   (descriptor[offset + 3U] & 0x03U) == USB_TRANSFER_INTERRUPT) {
            if (state->hub_endpoint == 0U) {
                state->hub_endpoint = descriptor[offset + 2U] & 0x0FU;
                state->hub_max_packet = (uint16_t)descriptor[offset + 4U] |
                                        ((uint16_t)descriptor[offset + 5U] << 8);
                state->hub_interval = descriptor[offset + 6U];
            }
        } else if (type == XHCI_DESCRIPTOR_ENDPOINT && length >= 7U && audio_interface &&
                   (descriptor[offset + 3U] & 0x03U) == USB_TRANSFER_ISOCHRONOUS &&
                   state->audio_endpoint == 0U) {
            state->audio_endpoint = descriptor[offset + 2U] & 0x0FU;
            state->audio_endpoint_in = (descriptor[offset + 2U] & 0x80U) != 0U;
            state->audio_max_packet = ((uint16_t)descriptor[offset + 4U] |
                                       ((uint16_t)descriptor[offset + 5U] << 8)) & 0x07FFU;
            state->audio_interval = descriptor[offset + 6U];
        } else if (type == XHCI_DESCRIPTOR_ENDPOINT && length >= 7U && bt_interface) {
            uint8_t endpoint = descriptor[offset + 2U] & 0x0FU;
            uint8_t direction_in = descriptor[offset + 2U] & 0x80U;
            uint8_t transfer_type = descriptor[offset + 3U] & 0x03U;
            uint16_t max_packet = (uint16_t)descriptor[offset + 4U] |
                                  ((uint16_t)descriptor[offset + 5U] << 8);
            if (endpoint == 0U || max_packet == 0U) continue;
            if (direction_in != 0U && transfer_type == USB_TRANSFER_INTERRUPT &&
                state->bt_event_endpoint == 0U) {
                state->bt_event_endpoint = endpoint;
                state->bt_event_max_packet = max_packet;
                state->bt_event_interval = descriptor[offset + 6U];
            } else if (direction_in != 0U && transfer_type == USB_TRANSFER_BULK &&
                       state->bt_acl_in_endpoint == 0U) {
                state->bt_acl_in_endpoint = endpoint;
                state->bt_acl_in_max_packet = max_packet;
            } else if (direction_in == 0U && transfer_type == USB_TRANSFER_BULK &&
                       state->bt_acl_out_endpoint == 0U) {
                state->bt_acl_out_endpoint = endpoint;
                state->bt_acl_out_max_packet = max_packet;
            }
        }
        offset += length;
    }
    return (state->hid_endpoint != 0U && state->hid_max_packet != 0U) ||
           (state->audio_endpoint != 0U && state->audio_max_packet != 0U) ||
           state->hub_interface_present ||
           (state->bt_event_endpoint != 0U &&
            (state->bt_acl_in_endpoint != 0U || state->bt_acl_out_endpoint != 0U));
}

/*
 * V3.10.1B EXPLICIT HUB GET STATUS
 *
 * Hub EP0 state belongs to the supplied device context.
 */
/*
 * V3.10.1E HUB CONTROL WRAPPERS REMOVED
 *
 * All Hub control callers now name the device context explicitly.
 * Runtime callers still pass &state->device in this stage.
 */
static bool xhci_hub_get_port_status_device(
    xhci_state_t *state,
    xhci_device_context_t *device,
    uint8_t port,
    uint32_t *status_out)
{
    uint8_t request[8] = {
        0xA3U,
        XHCI_SETUP_GET_STATUS,
        0x00U,
        0x00U,
        port,
        0x00U,
        0x04U,
        0x00U,
    };


    if(state == 0 ||
       device == 0 ||
       status_out == 0 ||
       port == 0U)
    {
        return false;
    }


    if(!xhci_submit_control_transfer_device(
           state,
           device,
           request,
           4U,
           true))
    {
        return false;
    }


    uint8_t *status =
        (uint8_t *)
            device->
                descriptor_buffer.cpu;


    *status_out =
        (uint32_t)status[0] |
        ((uint32_t)status[1] << 8) |
        ((uint32_t)status[2] << 16) |
        ((uint32_t)status[3] << 24);


    return true;
}


/*
 * Compatibility wrapper.
 *
 * V3.10.1B deliberately leaves every existing Hub caller on the
 * old state->device working-context behavior.
 */




/*
 * V3.10.1C EXPLICIT HUB SET FEATURE
 *
 * Hub EP0 state belongs to the supplied device context.
 */
static bool xhci_hub_set_port_feature_device(
    xhci_state_t *state,
    xhci_device_context_t *device,
    uint8_t port,
    uint16_t feature)
{
    uint8_t request[8] = {
        0x23U,
        XHCI_SETUP_SET_FEATURE,
        (uint8_t)feature,
        (uint8_t)(feature >> 8),
        port,
        0x00U,
        0x00U,
        0x00U,
    };


    if(state == 0 ||
       device == 0 ||
       port == 0U)
    {
        return false;
    }


    return
        xhci_submit_control_transfer_device(
            state,
            device,
            request,
            0U,
            false);
}


/*
 * Compatibility wrapper.
 *
 * Existing Hub paths intentionally keep their old state->device
 * working-context behavior in V3.10.1C.
 */




static uint8_t xhci_hub_port_speed(uint32_t status) {
    if ((status & (1U << 10)) != 0U) return 3U;
    if ((status & (1U << 9)) != 0U) return 2U;
    return 1U;
}

static bool xhci_child_route(const xhci_device_context_t *hub,
                             uint8_t port, uint32_t *route_out) {
    uint32_t route;
    uint32_t shift;
    if (hub == 0 || route_out == 0 || port == 0U || port > 15U) return false;
    route = hub->route_string;
    shift = route == 0U ? 0U : 4U;
    while (shift < 20U && ((route >> shift) & 0x0FU) != 0U) shift += 4U;
    if (shift >= 20U) return false;
    *route_out = route | ((uint32_t)port << shift);
    return true;
}

/*
 * V3.9.6 INITIAL HUB SLOT WALK
 *
 * Initial downstream enumeration is now entirely Slot Table based.
 *
 * Newly discovered Hub Slots are processed in a following pass,
 * allowing arbitrary xHCI-supported Hub nesting without inventory.
 */
/*
 * V3.10.1D DIRECT STARTUP HUB CONTEXT
 *
 * Startup Hub control transfers operate directly on the canonical
 * Slot.context.
 *
 * state->device is reserved for a child while that child is being
 * enumerated.
 */
static bool xhci_probe_hub_downstream(
    xhci_state_t *state)
{
    if(state == 0)
    {
        return false;
    }


    /*
     * 256 Slot IDs / 64 bits = 4 words.
     *
     * Multiple passes allow:
     *
     *     Hub
     *       |
     *      Hub
     *       |
     *     Device
     *
     * even when the newly allocated child Hub has a Slot ID that
     * appears earlier in the table than its parent.
     */
    uint64_t processed[4] = {
        0U,
        0U,
        0U,
        0U
    };


    uint32_t limit =
        state->max_slots;


    if(limit >=
       XHCI_MAX_SLOT_TABLE)
    {
        limit =
            XHCI_MAX_SLOT_TABLE -
            1U;
    }


    for(;;)
    {
        bool progress =
            false;


        for(uint32_t slot_index = 1U;
            slot_index <= limit;
            ++slot_index)
        {
            uint32_t word =
                slot_index >> 6;

            uint64_t mask =
                1ULL <<
                (slot_index & 63U);


            if((processed[word] &
                mask) != 0U)
            {
                continue;
            }


            xhci_slot_device_t *slot_dev =
                &g_xhci_slot_devices[
                    slot_index];


            if(!slot_dev->used ||
               !slot_dev->is_hub ||
               slot_dev->context.device_slot !=
                   (uint8_t)slot_index ||
               slot_dev->context.hub_port_count ==
                   0U)
            {
                continue;
            }


            processed[word] |=
                mask;

            progress =
                true;


            /*
             * Permanent Hub owner.
             *
             * EP0 enqueue and descriptor-buffer state are updated
             * in this context directly.
             */
            xhci_device_context_t *hub =
                &slot_dev->context;


            for(uint32_t port = 1U;
                port <= hub->hub_port_count;
                ++port)
            {
                uint32_t status =
                    0U;

                uint8_t speed =
                    0U;

                uint32_t route =
                    0U;

                uint8_t child_slot =
                    0U;

                bool enabled =
                    false;


                /*
                 * No state->device copy.
                 */
                if(!xhci_hub_get_port_status_device(
                       state,
                       hub,
                       (uint8_t)port,
                       &status) ||
                   (status & 1U) == 0U)
                {
                    continue;
                }


                /*
                 * Do not enumerate an already published child a
                 * second time.
                 */
                uint8_t existing_child =
                    0U;


                if(xhci_find_hub_child(
                       hub->device_slot,
                       (uint8_t)port,
                       &existing_child))
                {
                    continue;
                }


                (void)
                    xhci_hub_set_port_feature_device(
                        state,
                        hub,
                        (uint8_t)port,
                        USB_HUB_FEATURE_PORT_POWER);


                (void)
                    xhci_hub_set_port_feature_device(
                        state,
                        hub,
                        (uint8_t)port,
                        USB_HUB_FEATURE_PORT_RESET);


                for(uint32_t spin = 0U;
                    spin < 10000U;
                    ++spin)
                {
                    if(xhci_hub_get_port_status_device(
                           state,
                           hub,
                           (uint8_t)port,
                           &status) &&
                       (status & 1U) != 0U &&
                       (status & 2U) != 0U)
                    {
                        enabled =
                            true;

                        break;
                    }


                    __asm__ volatile(
                        "pause");
                }


                if(!enabled ||
                   !xhci_child_route(
                       hub,
                       (uint8_t)port,
                       &route))
                {
                    continue;
                }


                speed =
                    xhci_hub_port_speed(
                        status);


                /*
                 * state->device belongs exclusively to the child
                 * during enumeration.
                 */
                xhci_zero_device_context(
                    &state->device);

                xhci_clear_device_flags();


                if(!xhci_submit_command(
                       state,
                       XHCI_COMMAND_RING_TYPE,
                       0U,
                       0U,
                       &child_slot) ||
                   child_slot == 0U ||
                   !xhci_enumerate_device(
                       state,
                       child_slot,
                       (uint8_t)port,
                       speed,
                       hub->root_port,
                       hub->device_slot,
                       (uint8_t)port,
                       route))
                {
                    if(child_slot != 0U)
                    {
                        (void)
                            xhci_submit_command(
                                state,
                                XHCI_DISABLE_SLOT_TYPE,
                                child_slot,
                                0U,
                                0);
                    }


                    (void)
                        xhci_free_device_resources(
                            state);

                    xhci_clear_device_flags();

                    continue;
                }


                uint8_t kind =
                    xhci_context_kind(
                        &state->device);


                if(kind != 0U &&
                   xhci_publish_working_device(
                       state))
                {

                    g_xhci_usb_hub_downstream =
                        true;
                }
                else
                {
                    (void)
                        xhci_submit_command(
                            state,
                            XHCI_DISABLE_SLOT_TYPE,
                            child_slot,
                            0U,
                            0);


                    (void)
                        xhci_free_device_resources(
                            state);

                    xhci_clear_device_flags();
                }
            }


            /*
             * Child enumeration should already leave it empty.
             * Keep this invariant explicit.
             */
            xhci_zero_device_context(
                &state->device);

            xhci_clear_device_flags();
        }


        if(!progress)
        {
            break;
        }
    }


    return true;
}


/*
 * V3.9.2 DIRECT SLOT SUBTREE REMOVE
 *
 * Topology:
 *
 *      Slot
 *       |
 *       +-- child_slots[]
 *
 * Teardown:
 *
 *      xhci_release_slot_device(slot)
 *
 * Runtime inventory access: none.
 */
/*
 * V3.10.6B9A SLOT-ONLY SUBTREE TEARDOWN
 *
 * Published device-tree destruction is entirely Slot-ID based.
 *
 *     parent Slot
 *         |
 *         +-- child_slots[]
 *         |
 *         v
 *     children first
 *         |
 *         v
 * xhci_release_slot_device()
 *
 * No saved context side channel exists.
 */
static bool xhci_remove_device_subtree(
    xhci_state_t *state,
    uint8_t slot)
{
    if(state == 0 ||
       slot == 0U)
    {
        return false;
    }


    xhci_slot_device_t *slot_dev =
        &g_xhci_slot_devices[
            slot];


    if(!slot_dev->used ||
       slot_dev->context.device_slot !=
           slot)
    {
        return false;
    }


    bool removed =
        false;

    uint8_t children[16];


    /*
     * Child teardown unlinks itself from the parent, so snapshot
     * the child Slot IDs before recursive destruction.
     */
    for(uint32_t port = 0U;
        port < 16U;
        ++port)
    {
        children[port] =
            slot_dev->child_slots[
                port];
    }


    for(uint32_t port = 0U;
        port < 16U;
        ++port)
    {
        uint8_t child =
            children[port];


        if(child == 0U ||
           child == slot)
        {
            continue;
        }


        if(xhci_remove_device_subtree(
               state,
               child))
        {
            removed =
                true;
        }
    }


    if(xhci_release_slot_device(
           state,
           slot))
    {
        removed =
            true;
    }


    return removed;
}




/*
 * V3.7.3 PURE SLOT CHILD LOOKUP
 *
 * Topology lookup is now:
 *
 *      parent Slot
 *          |
 *      child_slots[port - 1]
 *          |
 *       child Slot
 *
 * No active-context comparison.
 * No inventory scan.
 * No context copying.
 */
static bool xhci_find_hub_child(
    uint8_t parent_slot,
    uint8_t parent_port,
    uint8_t *child_slot)
{
    if(child_slot == 0)
    {
        return false;
    }


    *child_slot =
        0U;


    if(parent_slot == 0U ||
       parent_port == 0U ||
       parent_port > 16U)
    {
        return false;
    }


    xhci_slot_device_t *parent =
        &g_xhci_slot_devices[
            parent_slot];


    if(!parent->used ||
       !parent->is_hub ||
       parent->context.device_slot !=
           parent_slot)
    {
        return false;
    }


    /*
     * Fast path:
     *
     * child_slots[] is a topology cache only.  Validate both the
     * published Slot identity and the reverse parent relation before
     * accepting it.
     */
    uint8_t slot =
        parent->child_slots[
            parent_port - 1U];


    if(slot != 0U)
    {
        xhci_slot_device_t *child =
            &g_xhci_slot_devices[
                slot];


        if(child->used &&
           child->context.device_slot ==
               slot &&
           child->parent_slot ==
               parent_slot &&
           child->parent_port ==
               parent_port)
        {
            *child_slot =
                slot;

            return true;
        }


        /*
         * Stale cache entry.  Drop only the cache; the canonical
         * Slot Table remains untouched.
         */
        parent->child_slots[
            parent_port - 1U] =
            0U;
    }


    /*
     * Recovery path:
     *
     * Slot Table parent_slot/parent_port is canonical.  Scan all
     * fully published Slots and rebuild child_slots[] if the cache
     * was absent or stale.
     */
    for(uint32_t candidate = 1U;
        candidate < XHCI_MAX_SLOT_TABLE;
        ++candidate)
    {
        xhci_slot_device_t *child =
            &g_xhci_slot_devices[
                candidate];


        if(!child->used ||
           child->context.device_slot !=
               (uint8_t)candidate)
        {
            continue;
        }


        if(child->parent_slot ==
               parent_slot &&
           child->parent_port ==
               parent_port)
        {
            parent->child_slots[
                parent_port - 1U] =
                (uint8_t)candidate;

            *child_slot =
                (uint8_t)candidate;

            return true;
        }
    }


    return false;
}


/*
 * V3.4.4 Slot tree removal
 *
 * Remove children before parent.
 *
 * Topology source:
 *
 *     parent slot
 *          |
 *     child_slots[]
 *
 */
static void __attribute__((used))
xhci_remove_slot_tree(
    uint8_t slot)
{
    if(slot == 0U)
    {
        return;
    }


    xhci_slot_device_t *dev =
        &g_xhci_slot_devices[slot];


    if(!dev->used)
    {
        return;
    }


    /*
     * Remove downstream devices first.
     */
    for(uint32_t port = 0U;
        port < 16U;
        ++port)
    {
        uint8_t child =
            dev->child_slots[port];


        if(child != 0U)
        {
            xhci_remove_slot_tree(
                child);
        }
    }


    /*
     * Hardware slot disable is handled by
     * the existing removal path.
     *
     * This function only maintains
     * software topology.
     */


    /*
     * Clear software topology node.
     */
    __builtin_memset(
        dev,
        0,
        sizeof(*dev));
}




/*
 * V3.10.6B5 CANONICAL HUB RECONCILE
 *
 * Published Hub control state belongs permanently to Slot.context.
 *
 * Hub port control:
 *
 *     Slot.context -> hub
 *
 * New downstream child enumeration:
 *
 *     state->device -> enumerate -> publish Slot.context
 *
 * The two ownership domains never overlap.
 */
static bool xhci_reconcile_one_hub(
    xhci_state_t *state,
    xhci_device_context_t *hub)
{
    bool changed =
        false;

    if(state == 0 ||
       hub == 0 ||

       hub->device_slot == 0U ||
       hub->hub_port_count == 0U)
    {
        return false;
    }

    for(uint32_t port = 1U;
        port <= hub->hub_port_count;
        ++port)
    {
        uint32_t status =
            0U;

        uint8_t child_slot =
            0U;

        bool child_present =
            false;

        bool connected;

        /*
         * Published Hub EP0/control state is used directly.
         *
         * Control transfers may advance EP0 enqueue/cycle state,
         * so this must be the canonical Slot.context rather than
         * a temporary copy.
         */
        if(!xhci_hub_get_port_status_device(
               state,
               hub,
               (uint8_t)port,
               &status))
        {
            continue;
        }

        connected =
            (status & 1U) != 0U;

        child_present =
            xhci_find_hub_child(
                hub->device_slot,
                (uint8_t)port,
                &child_slot);

        /*
         * Disconnect:
         *
         * remove only the published child subtree.
         * The Hub itself remains canonical in Slot.context.
         */
        if(!connected)
        {
            liteos_serial_write(
                "LITEOS_DIAG_HUB_DISCONNECT\r\n");

            if(child_present &&
               child_slot != 0U)
            {
                liteos_serial_write(
                    "LITEOS_DIAG_HUB_CHILD_FOUND\r\n");
            }
            else
            {
                liteos_serial_write(
                    "LITEOS_DIAG_HUB_CHILD_MISSING\r\n");
            }


            if(child_present &&
               child_slot != 0U &&
               xhci_remove_device_subtree(
                   state,
                   child_slot))
            {
                changed =
                    true;
            }

            continue;
        }

        /*
         * Already represented by a published child Slot.
         */
        if(child_present)
        {
            continue;
        }

        /*
         * Newly connected downstream device.
         *
         * Power/reset/status transactions still belong to the
         * published Hub context.
         */
        (void)xhci_hub_set_port_feature_device(
            state,
            hub,
            (uint8_t)port,
            USB_HUB_FEATURE_PORT_POWER);

        (void)xhci_hub_set_port_feature_device(
            state,
            hub,
            (uint8_t)port,
            USB_HUB_FEATURE_PORT_RESET);

        bool enabled =
            false;

        for(uint32_t spin = 0U;
            spin < 10000U;
            ++spin)
        {
            if(xhci_hub_get_port_status_device(
                   state,
                   hub,
                   (uint8_t)port,
                   &status) &&
               (status & 1U) != 0U &&
               (status & 2U) != 0U)
            {
                enabled =
                    true;

                break;
            }

            __asm__ volatile (
                "pause");
        }

        uint32_t route =
            0U;

        if(!enabled ||
           !xhci_child_route(
               hub,
               (uint8_t)port,
               &route))
        {
            continue;
        }

        uint8_t speed =
            xhci_hub_port_speed(
                status);

        uint8_t slot =
            0U;

        /*
         * V3.10.6B5 CHILD ENUMERATION BOUNDARY
         *
         * Everything above this point operates on the published
         * Hub context.
         *
         * Everything below that creates/configures the new child
         * uses state->device as unpublished working storage.
         */
        xhci_zero_device_context(
            &state->device);

        xhci_clear_device_flags();

        if(!xhci_submit_command(
               state,
               XHCI_COMMAND_RING_TYPE,
               0U,
               0U,
               &slot) ||
           slot == 0U ||
           !xhci_enumerate_device(
               state,
               slot,
               (uint8_t)port,
               speed,
               hub->root_port,
               hub->device_slot,
               (uint8_t)port,
               route))
        {
            if(slot != 0U)
            {
                (void)xhci_submit_command(
                    state,
                    XHCI_DISABLE_SLOT_TYPE,
                    slot,
                    0U,
                    0);
            }

            (void)xhci_free_device_resources(
                state);

            xhci_clear_device_flags();

            continue;
        }

        uint8_t kind =
            xhci_context_kind(
                &state->device);

        if(kind != 0U &&
           xhci_publish_working_device(
               state))
        {
            changed =
                true;
        }
        else
        {
            (void)xhci_submit_command(
                state,
                XHCI_DISABLE_SLOT_TYPE,
                slot,
                0U,
                0);

            (void)xhci_free_device_resources(
                state);

            xhci_clear_device_flags();
        }
    }

    /*
     * No unpublished child context may escape reconciliation.
     */
    xhci_zero_device_context(
        &state->device);

    xhci_clear_device_flags();

    return changed;
}


static bool xhci_reconcile_hub_topology(
    xhci_state_t *state)
{
    liteos_serial_write(
        "LITEOS_DIAG_HUB_RECONCILE\r\n");




    bool changed =
        false;

    /*
     * 256 Slot IDs = 256 bits.
     */
    uint64_t processed[4] = {
        0U,
        0U,
        0U,
        0U
    };


    if(state == 0 ||
       !state->initialized ||
       !g_xhci_usb_hub_present)
    {
        return false;
    }


    /*
     * Existing reconcile helpers temporarily use state->device.
     * Preserve the currently active functional device first.
     */
    /*
     * V3.10.6B7D-FIX1
     *
     * Runtime reconciliation begins with empty unpublished working
     * storage. Published devices are already canonical Slot.context.
     */
    if(state->device.device_slot != 0U)
    {
        return false;
    }



    xhci_clear_device_flags();


    uint32_t slot_limit =
        state->max_slots;


    if(slot_limit >=
       XHCI_MAX_SLOT_TABLE)
    {
        slot_limit =
            XHCI_MAX_SLOT_TABLE - 1U;
    }


    /*
     * Continue until every currently visible Hub Slot has been
     * processed once.
     *
     * If processing Hub A discovers Hub B, Hub B enters the Slot
     * Table and is picked up by a following pass without waiting
     * for another global inventory traversal.
     */
    for(;;)
    {
        bool progress =
            false;


        for(uint32_t slot = 1U;
            slot <= slot_limit;
            ++slot)
        {
            uint32_t word =
                slot >> 6;

            uint64_t mask =
                1ULL <<
                (slot & 63U);


            if((processed[word] &
                mask) != 0U)
            {
                continue;
            }


            xhci_slot_device_t *slot_dev =
                &g_xhci_slot_devices[
                    slot];


            if(!slot_dev->used ||
               !slot_dev->is_hub)
            {
                continue;
            }


            /*
             * Mark before walking downstream so a malformed cyclic
             * software topology can never recurse forever.
             */
            processed[word] |=
                mask;

            progress =
                true;


            /*
             * V3.10.6B5 CANONICAL HUB OWNER
             *
             * Do not snapshot Hub DMA/control state.
             *
             * EP0 enqueue/cycle changes made by Hub control
             * transfers must remain in Slot.context.
             */
            xhci_device_context_t *hub =
                &slot_dev->context;

            /*
             * Slot Table corruption/stale context must not route
             * control transfers to another hardware Slot.
             */
            if(hub->device_slot !=
                   (uint8_t)slot ||
               hub->hub_port_count ==
                   0U)
            {
                continue;
            }


            if(xhci_reconcile_one_hub(
                    state,
                    hub))
            {
                changed =
                    true;
            }
        }


        if(!progress)
        {
            break;
        }
    }


    /*
     * Restore the functional device that was active before topology
     * reconciliation.
     */
    /*
     * No active runtime context exists to restore.
     * Every published device remained in Slot.context throughout
     * reconciliation.
     */


    /*
     * V3.10.6B6A FIX DANGLING ELSE
     *
     * No published Slot is activated when no saved working
     * context exists. Topology recomputation remains unconditional.
     */




    xhci_recompute_topology(
        state);


    if(changed)
    {
        liteos_serial_write(
            "LITEOS_USB_RUNTIME_HUB_CHANGE\r\n");
    }


    return changed;
}


static void xhci_init_ring_link(xhci_dma_page_t *ring) {
    xhci_trb_t *trbs;
    if (ring == 0 || ring->cpu == 0) return;
    trbs = (xhci_trb_t *)ring->cpu;
    trbs[XHCI_RING_TRB_COUNT - 1U].parameter = xhci_dma_address(&ring->mapping);
    trbs[XHCI_RING_TRB_COUNT - 1U].control =
        (XHCI_LINK_TRB_TYPE << XHCI_TRB_TYPE_SHIFT) |
        XHCI_TRB_CYCLE | XHCI_TRB_LINK_TOGGLE_CYCLE;
}

/*
 * V3.10.6B10B2-FIX2 INTERRUPT INTERVAL ENCODING
 *
 * xHCI Endpoint Context Interval:
 *
 *     service period = 2^Interval * 125 us
 *
 * USB descriptor bInterval uses different encodings:
 *
 *   Low / Full Speed interrupt:
 *       bInterval is linear milliseconds.
 *
 *   High / Super Speed interrupt:
 *       interval = 2^(bInterval - 1) microframes.
 *
 * Keep the conversion here so endpoint setup never writes raw
 * descriptor bInterval into an xHCI Endpoint Context.
 */
static uint8_t xhci_interrupt_interval(
    uint8_t speed,
    uint8_t b_interval)
{
    if(b_interval == 0U)
    {
        return 0U;
    }

    /*
     * xHCI speed IDs used by this driver:
     *
     *   1 = Full
     *   2 = Low
     *   3 = High
     *   4 = Super
     */
    if(speed >= 3U)
    {
        uint8_t value =
            b_interval;

        if(value > 16U)
        {
            value =
                16U;
        }

        return
            (uint8_t)(
                value - 1U);
    }

    /*
     * Full/Low-Speed bInterval is in 1ms frames.
     *
     * Convert:
     *
     *     milliseconds -> microframes
     *
     * then round DOWN to the nearest power of two, matching the
     * xHCI scheduling rule used by mature host-controller drivers.
     */
    uint32_t microframes =
        (uint32_t)b_interval *
        8U;

    uint8_t exponent =
        0U;

    while(exponent < 15U &&
          (1U <<
           (uint32_t)(
               exponent + 1U)) <=
              microframes)
    {
        ++exponent;
    }

    /*
     * FS/LS periodic endpoint valid useful range:
     *
     *   2^3 microframes =   1 ms
     *   2^10 microframes = 128 ms
     */
    if(exponent < 3U)
    {
        exponent =
            3U;
    }

    if(exponent > 10U)
    {
        exponent =
            10U;
    }

    return exponent;
}


static void xhci_init_endpoint_context(xhci_state_t *state, uint32_t *endpoint,
                                       uint8_t interval, uint8_t type,
                                       uint16_t max_packet,
                                       const dma_mapping_t *ring) {
    uint64_t address = xhci_dma_address(ring);
    uint8_t encoded_interval =
        interval;

    /*
     * Endpoint types:
     *
     *   3 = Interrupt OUT
     *   7 = Interrupt IN
     */
    if(type == 3U ||
       type == 7U)
    {
        encoded_interval =
            xhci_interrupt_interval(
                state->device_speed,
                interval);
    }

    endpoint[0] =
        (uint32_t)encoded_interval <<
        16;
    endpoint[1] = (3U << 1) | ((uint32_t)type << 3) |
                  ((uint32_t)max_packet << 16);
    endpoint[2] = (uint32_t)address | 1U;
    endpoint[3] = (uint32_t)(address >> 32);
    endpoint[4] = 0U;
}

/*
 * V3.10.5A EXPLICIT BT QUEUES
 *
 * Bluetooth endpoint/ring producer state belongs to the explicit
 * device context.  Controller MMIO state remains in xhci_state_t.
 */
static bool xhci_queue_bt_event_device(
    xhci_state_t *state,
    xhci_device_context_t *device) {
    if(device == 0 ||
       device->device_slot == 0U)
    {
        return false;
    }


    xhci_trb_t *ring;
    uint32_t endpoint_id;
    uint32_t index;
    if (state == 0 || device->bt_controller == 0 || device->bt_event_endpoint == 0U ||
        device->bt_event_ring.cpu == 0 || device->bt_event_buffer.cpu == 0 ||
        device->bt_event_transfer_pending) return false;
    endpoint_id = (uint32_t)device->bt_event_endpoint * 2U + 1U;
    index = device->bt_event_enqueue;
    if (endpoint_id > 31U || index >= XHCI_RING_TRB_COUNT - 1U ||
        device->bt_event_max_packet == 0U) return false;
    ring = (xhci_trb_t *)device->bt_event_ring.cpu;
    ring[index].parameter = xhci_dma_address(&device->bt_event_buffer.mapping);
    ring[index].status = device->bt_event_max_packet;
    ring[index].control = (XHCI_NORMAL_TRB_TYPE << XHCI_TRB_TYPE_SHIFT) |
                          XHCI_TRB_DIRECTION_IN |
                          XHCI_TRB_INTERRUPT_ON_COMPLETION | device->bt_event_cycle;
    ++index;
    if (index == XHCI_RING_TRB_COUNT - 1U) {
        ring[XHCI_RING_TRB_COUNT - 1U].control =
            (XHCI_LINK_TRB_TYPE << XHCI_TRB_TYPE_SHIFT) |
            device->bt_event_cycle | XHCI_TRB_LINK_TOGGLE_CYCLE;
        device->bt_event_enqueue = 0U;
        device->bt_event_cycle ^= 1U;
    } else {
        device->bt_event_enqueue = index;
    }
    device->bt_event_transfer_pending = true;
    dma_sync_for_device(&device->bt_event_ring.mapping);
    dma_sync_for_device(&device->bt_event_buffer.mapping);
    dma_wmb();
    *(volatile uint32_t *)(state->mmio + state->doorbell_offset +
                           (uint32_t)device->device_slot * sizeof(uint32_t)) = endpoint_id;
    __asm__ volatile ("mfence" : : : "memory");
    return true;
}

/*
 * Compatibility wrapper.
 *
 * V3.10.5A does not migrate callers yet.
 */
/*
 * V3.10.6B9F BT WORKING WRAPPERS REMOVED
 *
 * Bluetooth enumeration now names state->device explicitly.
 * Runtime Bluetooth paths continue to resolve permanent Slot.context
 * from their Slot ID.
 */


static bool xhci_queue_bt_acl_in_device(
    xhci_state_t *state,
    xhci_device_context_t *device) {
    if(device == 0 ||
       device->device_slot == 0U)
    {
        return false;
    }


    xhci_trb_t *ring;
    uint32_t endpoint_id;
    uint32_t index;
    if (state == 0 || device->bt_controller == 0 || device->bt_acl_in_endpoint == 0U ||
        device->bt_acl_in_ring.cpu == 0 || device->bt_acl_in_buffer.cpu == 0 ||
        device->bt_acl_in_transfer_pending) return false;
    endpoint_id = (uint32_t)device->bt_acl_in_endpoint * 2U + 1U;
    index = device->bt_acl_in_enqueue;
    if (endpoint_id > 31U || index >= XHCI_RING_TRB_COUNT - 1U) return false;
    ring = (xhci_trb_t *)device->bt_acl_in_ring.cpu;
    ring[index].parameter = xhci_dma_address(&device->bt_acl_in_buffer.mapping);
    ring[index].status = PAGE_SIZE;
    ring[index].control = (XHCI_NORMAL_TRB_TYPE << XHCI_TRB_TYPE_SHIFT) |
                          XHCI_TRB_DIRECTION_IN |
                          XHCI_TRB_INTERRUPT_ON_COMPLETION | device->bt_acl_in_cycle;
    ++index;
    if (index == XHCI_RING_TRB_COUNT - 1U) {
        ring[XHCI_RING_TRB_COUNT - 1U].control =
            (XHCI_LINK_TRB_TYPE << XHCI_TRB_TYPE_SHIFT) |
            device->bt_acl_in_cycle | XHCI_TRB_LINK_TOGGLE_CYCLE;
        device->bt_acl_in_enqueue = 0U;
        device->bt_acl_in_cycle ^= 1U;
    } else {
        device->bt_acl_in_enqueue = index;
    }
    device->bt_acl_in_transfer_pending = true;
    dma_sync_for_device(&device->bt_acl_in_ring.mapping);
    dma_sync_for_device(&device->bt_acl_in_buffer.mapping);
    dma_wmb();
    *(volatile uint32_t *)(state->mmio + state->doorbell_offset +
                           (uint32_t)device->device_slot * sizeof(uint32_t)) = endpoint_id;
    __asm__ volatile ("mfence" : : : "memory");
    return true;
}



static bool xhci_queue_bt_acl_out_device(
    xhci_state_t *state,
    xhci_device_context_t *device,
    size_t length) {
    if(device == 0 ||
       device->device_slot == 0U)
    {
        return false;
    }


    xhci_trb_t *ring;
    uint32_t endpoint_id;
    uint32_t index;
    if (state == 0 || device->bt_acl_out_endpoint == 0U ||
        device->bt_acl_out_ring.cpu == 0 || device->bt_acl_out_buffer.cpu == 0 ||
        device->bt_acl_out_buffer.mapping.device == 0 || length == 0U ||
        length > PAGE_SIZE || device->bt_acl_out_buffer.mapping.segment_count == 0U) {
        return false;
    }
    endpoint_id = (uint32_t)device->bt_acl_out_endpoint * 2U;
    index = device->bt_acl_out_enqueue;
    if (endpoint_id > 31U || index >= XHCI_RING_TRB_COUNT - 1U) return false;
    ring = (xhci_trb_t *)device->bt_acl_out_ring.cpu;
    ring[index].parameter = xhci_dma_address(&device->bt_acl_out_buffer.mapping);
    ring[index].status = (uint32_t)length;
    ring[index].control = (XHCI_NORMAL_TRB_TYPE << XHCI_TRB_TYPE_SHIFT) |
                          XHCI_TRB_INTERRUPT_ON_COMPLETION | device->bt_acl_out_cycle;
    ++index;
    if (index == XHCI_RING_TRB_COUNT - 1U) {
        ring[XHCI_RING_TRB_COUNT - 1U].control =
            (XHCI_LINK_TRB_TYPE << XHCI_TRB_TYPE_SHIFT) |
            device->bt_acl_out_cycle | XHCI_TRB_LINK_TOGGLE_CYCLE;
        device->bt_acl_out_enqueue = 0U;
        device->bt_acl_out_cycle ^= 1U;
    } else {
        device->bt_acl_out_enqueue = index;
    }
    device->bt_acl_out_transfer_pending = true;
    dma_sync_for_device(&device->bt_acl_out_ring.mapping);
    dma_sync_for_device(&device->bt_acl_out_buffer.mapping);
    dma_wmb();
    *(volatile uint32_t *)(state->mmio + state->doorbell_offset +
                           (uint32_t)device->device_slot * sizeof(uint32_t)) = endpoint_id;
    __asm__ volatile ("mfence" : : : "memory");
    return true;
}


/*
 * V3.10.6B7B BT ACL-OUT WRAPPER REMOVED
 */


/*
 * Send using the context currently installed in state->device.
 *
 * The public Bluetooth callback below resolves Slot ID first and
 * temporarily installs the owning context when necessary.
 */
/*
 * V3.10.6B7B EXPLICIT BT SEND CORE
 *
 * All Bluetooth TX state belongs to the supplied device context.
 */
static kstatus_t xhci_bt_send_device(
    xhci_state_t *state,
    xhci_device_context_t *device,
    const uint8_t *packet,
    size_t length)
{
    uint8_t setup[8] = {
        0x20U,
        0x00U,
        0x00U,
        0x00U,
        0x00U,
        0x00U,
        0x00U,
        0x00U
    };

    if(state == 0 ||
       device == 0 ||
       device->device_slot == 0U ||
       device->bt_controller == 0 ||
       packet == 0 ||
       length < 4U ||
       length - 1U > PAGE_SIZE)
    {
        return K_EINVAL;
    }

    /*
     * HCI ACL packet -> USB Bulk OUT.
     */
    if(packet[0] == 0x02U)
    {
        if(device->bt_acl_out_endpoint == 0U ||
           device->bt_acl_out_transfer_pending ||
           device->bt_acl_out_buffer.cpu == 0 ||
           length - 1U > PAGE_SIZE)
        {
            return K_EBUSY;
        }

        for(size_t i = 1U;
            i < length;
            ++i)
        {
            ((uint8_t *)
                device->
                    bt_acl_out_buffer.cpu)
                [i - 1U] =
                    packet[i];
        }

        return
            xhci_queue_bt_acl_out_device(
                state,
                device,
                length - 1U)
            ? K_OK
            : K_EIO;
    }

    /*
     * HCI Command packet -> USB class control transfer.
     */
    if(packet[0] != 0x01U ||
       device->descriptor_buffer.cpu == 0)
    {
        return K_EINVAL;
    }

    for(size_t i = 1U;
        i < length;
        ++i)
    {
        ((uint8_t *)
            device->
                descriptor_buffer.cpu)
            [i - 1U] =
                packet[i];
    }

    setup[6] =
        (uint8_t)(
            (length - 1U) &
            0xFFU);

    setup[7] =
        (uint8_t)(
            (length - 1U) >>
            8);

    dma_sync_for_device(
        &device->
            descriptor_buffer.mapping);

    return
        xhci_submit_control_transfer_device(
            state,
            device,
            setup,
            (uint32_t)(
                length - 1U),
            false)
        ? K_OK
        : K_EIO;
}


/*
 * V3.7.7 BT SLOT TRANSPORT
 *
 * Bluetooth Core -> xHCI transmission is now routed by the Slot ID
 * permanently bound when bt_controller is created.
 */
/*
 * V3.10.6B7B CANONICAL BT SEND
 *
 * Bluetooth transport is permanently bound to one hardware Slot:
 *
 *     transport->slot
 *           |
 *           v
 *      Slot.context
 *           |
 *           v
 *   xhci_bt_send_device()
 *
 * No inventory lookup.
 * No state->device activation.
 */
static kstatus_t xhci_bt_send(
    void *context,
    const uint8_t *packet,
    size_t length)
{
    xhci_bt_transport_t *transport =
        (xhci_bt_transport_t *)context;

    if(transport == 0 ||
       transport->state == 0 ||
       transport->slot == 0U)
    {
        return K_EINVAL;
    }

    xhci_state_t *state =
        transport->state;

    uint8_t slot =
        transport->slot;

    xhci_slot_device_t *slot_dev =
        &g_xhci_slot_devices[
            slot];

    if(!slot_dev->used ||
       slot_dev->context.device_slot !=
           slot ||
       slot_dev->context.bt_controller ==
           0)
    {
        return K_EIO;
    }

    return
        xhci_bt_send_device(
            state,
            &slot_dev->context,
            packet,
            length);
}


static bool xhci_configure_bt_endpoints(xhci_state_t *state) {
    uint32_t event_id;
    uint32_t acl_in_id;
    uint32_t acl_out_id;
    uint32_t *input;
    uint32_t *control;
    uint32_t *input_slot;
    uint32_t *output_slot;
    if (state == 0 || state->bt_event_endpoint == 0U || state->bt_event_max_packet == 0U ||
        (state->bt_acl_in_endpoint == 0U && state->bt_acl_out_endpoint == 0U)) return false;
    event_id = (uint32_t)state->bt_event_endpoint * 2U + 1U;
    acl_in_id = state->bt_acl_in_endpoint == 0U ? 0U :
                (uint32_t)state->bt_acl_in_endpoint * 2U + 1U;
    acl_out_id = state->bt_acl_out_endpoint == 0U ? 0U :
                 (uint32_t)state->bt_acl_out_endpoint * 2U;
    if (event_id > 31U || (acl_in_id != 0U && acl_in_id > 31U) ||
        (acl_out_id != 0U && acl_out_id > 31U) || event_id == acl_in_id ||
        event_id == acl_out_id || (acl_in_id != 0U && acl_in_id == acl_out_id)) return false;
    if (!xhci_alloc_page(state, &state->bt_event_ring, DMA_BIDIRECTIONAL) ||
        !xhci_alloc_page(state, &state->bt_event_buffer, DMA_FROM_DEVICE) ||
        (acl_in_id != 0U &&
         (!xhci_alloc_page(state, &state->bt_acl_in_ring, DMA_BIDIRECTIONAL) ||
          !xhci_alloc_page(state, &state->bt_acl_in_buffer, DMA_FROM_DEVICE))) ||
    (acl_out_id != 0U &&
     (!xhci_alloc_page(state, &state->bt_acl_out_ring, DMA_BIDIRECTIONAL) ||
      !xhci_alloc_page(state, &state->bt_acl_out_buffer, DMA_TO_DEVICE)))) return false;
    xhci_init_ring_link(&state->bt_event_ring);
    xhci_init_ring_link(&state->bt_acl_in_ring);
    xhci_init_ring_link(&state->bt_acl_out_ring);
    input = (uint32_t *)state->input_context.cpu;
    control = input;
    input_slot = (uint32_t *)((uint8_t *)input + state->context_size);
    output_slot = (uint32_t *)state->output_context.cpu;
    for (uint32_t i = 0U; i < 4U; ++i) input_slot[i] = output_slot[i];
    uint32_t context_entries = event_id;
    if (acl_in_id > context_entries) context_entries = acl_in_id;
    if (acl_out_id > context_entries) context_entries = acl_out_id;
    input_slot[0] &= ~(0x1FU << 27);
    input_slot[0] |= context_entries << 27;
    control[0] = 0U;
    control[1] = 1U | (1U << event_id) |
                 (acl_in_id == 0U ? 0U : 1U << acl_in_id) |
                 (acl_out_id == 0U ? 0U : 1U << acl_out_id);
    xhci_init_endpoint_context(state,
        (uint32_t *)((uint8_t *)input + state->context_size * (event_id + 1U)),
        state->bt_event_interval == 0U ? 1U : state->bt_event_interval, 7U,
        state->bt_event_max_packet, &state->bt_event_ring.mapping);
    if (acl_in_id != 0U) {
        xhci_init_endpoint_context(state,
            (uint32_t *)((uint8_t *)input + state->context_size * (acl_in_id + 1U)),
            0U, 6U, state->bt_acl_in_max_packet, &state->bt_acl_in_ring.mapping);
    }
    if (acl_out_id != 0U) {
        xhci_init_endpoint_context(state,
            (uint32_t *)((uint8_t *)input + state->context_size * (acl_out_id + 1U)),
            0U, 2U, state->bt_acl_out_max_packet, &state->bt_acl_out_ring.mapping);
    }
    /*
     * Bind this Bluetooth controller permanently to its hardware
     * Slot before Bluetooth Core receives the callback pointer.
     */
    if(state->device_slot == 0U)
    {
        return false;
    }


    xhci_bt_transport_t *transport =
        &g_xhci_bt_transports[
            state->device_slot];


    transport->state =
        state;

    transport->slot =
        state->device_slot;


    dma_sync_for_device(
        &state->input_context.mapping);
    if (!xhci_submit_command(state, XHCI_CONFIGURE_ENDPOINT_TYPE,
                             state->device_slot,
                             xhci_dma_address(&state->input_context.mapping), 0) ||
        bt_controller_create(
            xhci_bt_send,
            transport,
            &state->bt_controller) != K_OK ||
        bt_controller_start(state->bt_controller) != K_OK ||
        !xhci_queue_bt_event_device(
            state,
            &state->device) ||
        (acl_in_id != 0U && !xhci_queue_bt_acl_in_device(
            state,
            &state->device))) return false;
    return true;
}


/*
 * V3.10.6B7C CANONICAL BT TRANSFER EVENT
 *
 * Transfer Event Slot ID is the permanent Bluetooth identity.
 *
 *     Transfer Event
 *          |
 *        Slot ID
 *          |
 *          v
 *     Slot.context
 *          |
 *     +----+----+
 *     |         |
 * completion  re-arm
 *
 * Published Bluetooth runtime state never enters state->device.
 * inventory[] is not involved in BT event routing.
 */
static bool xhci_handle_bt_transfer_event(
    xhci_state_t *state,
    const xhci_trb_t *event)
{
    if(state == 0 ||
       event == 0 ||
       ((event->control >>
         XHCI_TRB_TYPE_SHIFT) &
        0x3FU) !=
           XHCI_TRANSFER_EVENT_TYPE)
    {
        return false;
    }


    uint8_t slot =
        (uint8_t)(
            event->control >>
            XHCI_TRB_SLOT_SHIFT);


    if(slot == 0U)
    {
        return false;
    }


    xhci_slot_device_t *slot_dev =
        &g_xhci_slot_devices[
            slot];


    /*
     * Only a fully published canonical Bluetooth context owns
     * runtime Transfer Events.
     */
    if(!slot_dev->used ||
       slot_dev->context.device_slot !=
           slot ||
       slot_dev->context.bt_controller ==
           0)
    {
        return false;
    }


    xhci_device_context_t *device =
        &slot_dev->context;


    uint32_t endpoint_id =
        (event->control >>
         XHCI_TRB_ENDPOINT_SHIFT) &
        0x1FU;


    uint32_t completion =
        event->status >>
        XHCI_COMPLETION_SHIFT;


    uint32_t residual =
        event->status &
        0x00FFFFFFU;


    /*
     * HCI Event interrupt-IN.
     */
    if(device->bt_event_endpoint !=
           0U &&
       endpoint_id ==
           (uint32_t)
               device->
                   bt_event_endpoint *
               2U + 1U)
    {
        device->bt_event_transfer_pending =
            false;


        if(completion ==
               XHCI_COMPLETION_SUCCESS &&
           residual <=
               device->
                   bt_event_max_packet)
        {
            size_t length =
                device->
                    bt_event_max_packet -
                residual;


            dma_sync_for_cpu(
                &device->
                    bt_event_buffer.mapping);


            if(length != 0U)
            {
                (void)bt_hci_receive_event(
                    device->bt_controller,
                    device->
                        bt_event_buffer.cpu,
                    length);
            }


            (void)xhci_queue_bt_event_device(
                state,
                device);
        }
        else
        {
            g_xhci_error =
                70U +
                completion;
        }


        return true;
    }


    /*
     * ACL bulk-IN.
     */
    if(device->bt_acl_in_endpoint !=
           0U &&
       endpoint_id ==
           (uint32_t)
               device->
                   bt_acl_in_endpoint *
               2U + 1U)
    {
        device->bt_acl_in_transfer_pending =
            false;


        if(completion ==
               XHCI_COMPLETION_SUCCESS &&
           residual <=
               PAGE_SIZE)
        {
            size_t length =
                PAGE_SIZE -
                residual;


            dma_sync_for_cpu(
                &device->
                    bt_acl_in_buffer.mapping);


            if(length != 0U)
            {
                (void)bt_acl_receive(
                    device->bt_controller,
                    device->
                        bt_acl_in_buffer.cpu,
                    length);
            }


            (void)xhci_queue_bt_acl_in_device(
                state,
                device);
        }
        else
        {
            g_xhci_error =
                71U +
                completion;
        }


        return true;
    }


    /*
     * ACL bulk-OUT completion.
     */
    if(device->bt_acl_out_endpoint !=
           0U &&
       endpoint_id ==
           (uint32_t)
               device->
                   bt_acl_out_endpoint *
               2U)
    {
        device->bt_acl_out_transfer_pending =
            false;


        if(completion !=
           XHCI_COMPLETION_SUCCESS)
        {
            g_xhci_error =
                72U +
                completion;
        }


        return true;
    }


    return false;
}


static bool xhci_configure_hid_endpoint(xhci_state_t *state) {
    uint32_t endpoint_id;
    if (state == 0 ||
        (state->hid_protocol != USB_HID_PROTOCOL_KEYBOARD &&
         state->hid_protocol != USB_HID_PROTOCOL_MOUSE) || state->hid_endpoint == 0U ||
        state->hid_max_packet == 0U || state->hid_max_packet > PAGE_SIZE) return false;
    endpoint_id = (uint32_t)state->hid_endpoint * 2U + 1U;
    if (endpoint_id > 31U ||
        !xhci_alloc_page(state, &state->hid_ring, DMA_BIDIRECTIONAL) ||
        !xhci_alloc_page(state, &state->hid_report, DMA_FROM_DEVICE)) {
        xhci_free_page(&state->hid_ring);
        xhci_free_page(&state->hid_report);
        return false;
    }
    state->hid_enqueue = 0U;
    state->hid_cycle = 1U;
    state->hid_transfer_pending = false;
    uint8_t *input = (uint8_t *)state->input_context.cpu;
    uint32_t *control = (uint32_t *)input;
    uint32_t *input_slot = (uint32_t *)(input + state->context_size);
    uint32_t *output_slot = (uint32_t *)state->output_context.cpu;
    uint32_t *endpoint = (uint32_t *)(input + state->context_size * (endpoint_id + 1U));
    for (uint32_t i = 0; i < 4U; ++i) input_slot[i] = output_slot[i];
    input_slot[0] &= ~(0x1FU << 27);
    input_slot[0] |= endpoint_id << 27;
    control[0] = 0U;
    /* Add Context Flags 必须同时包含 Slot Context 和目标端点。 */
    control[1] = 1U | (1U << endpoint_id);
    uint8_t hid_xhci_interval =
        xhci_interrupt_interval(
            state->device_speed,
            state->hid_interval);

    endpoint[0] =
        (uint32_t)hid_xhci_interval <<
        16;
    endpoint[1] = (3U << 1) | (7U << 3) |
                  ((uint32_t)state->hid_max_packet << 16);
    endpoint[2] = (uint32_t)xhci_dma_address(&state->hid_ring.mapping) | 1U;
    endpoint[3] = (uint32_t)(xhci_dma_address(&state->hid_ring.mapping) >> 32);
    endpoint[4] = 0U;
    xhci_trb_t *ring = (xhci_trb_t *)state->hid_ring.cpu;
    ring[XHCI_RING_TRB_COUNT - 1U].parameter =
        xhci_dma_address(&state->hid_ring.mapping);
    ring[XHCI_RING_TRB_COUNT - 1U].control =
        (XHCI_LINK_TRB_TYPE << XHCI_TRB_TYPE_SHIFT) |
        XHCI_TRB_CYCLE | XHCI_TRB_LINK_TOGGLE_CYCLE;
    dma_sync_for_device(&state->input_context.mapping);
    dma_sync_for_device(&state->hid_ring.mapping);
    dma_sync_for_device(&state->hid_report.mapping);
    if (!xhci_submit_command(state, XHCI_CONFIGURE_ENDPOINT_TYPE,
                             state->device_slot,
                             xhci_dma_address(&state->input_context.mapping), 0)) {
        xhci_free_page(&state->hid_ring);
        xhci_free_page(&state->hid_report);
        return false;
    }
    return xhci_queue_hid_report(state, &state->device);
}

static bool xhci_enumerate_device(xhci_state_t *state, uint8_t slot,
                                  uint8_t port, uint8_t speed,
                                  uint8_t root_port, uint8_t parent_slot,
                                  uint8_t parent_port, uint32_t route_string) {
    /*
     * V3.7.2 ENUMERATION FAILURE ROLLBACK
     *
     * Slot Table and USB Core objects can be created before
     * hardware enumeration has fully succeeded.
     *
     * Every failure exit must remove those tentative software
     * objects.  Hardware Disable Slot and DMA teardown remain
     * owned by the existing caller.
     */


    /*
     * V3.5.2 USB CORE BIND
     *
     * Bind xHCI Slot ID to USB Core device.
     */


    /*
     * V3.5.3 USB descriptor sync
     *
     * Bind xHCI enumeration result
     * into USB Core object.
     */

    usb_device_t *usb_dev =
        usb_alloc_device(slot);


    if(usb_dev != 0)
    {
        usb_dev->speed =
            speed;

        usb_dev->parent_slot =
            parent_slot;

        usb_dev->parent_port =
            parent_port;


        /*
         * Device identity.
         *
         * Descriptor parser will
         * fill these fields later.
         */
        usb_dev->device_class =
            0;

        usb_dev->subclass =
            0;

        usb_dev->protocol =
            0;
    }

    /*
     * V3.6.4 USB HUB CLASS BIND
     *
     * Hub devices get their own class object.
     */

    if(usb_dev != 0 &&
       usb_dev->device_class == 0x09)
    {
        usb_hub_init(
            slot,
            0);
    }






    /*
     * V3.2 Slot Table mirror
     *
     * Keep old inventory path unchanged.
     * This only creates a native Slot ID view.
     */
    xhci_slot_device_t *slot_dev =
        &g_xhci_slot_devices[slot];

    __builtin_memset(
        slot_dev,
        0,
        sizeof(*slot_dev));

    slot_dev->used = true;

    slot_dev->slot_id =
        slot;

    slot_dev->speed =
        speed;

    slot_dev->parent_slot =
        parent_slot;

    slot_dev->parent_port =
        parent_port;

    slot_dev->root_port =
        root_port;

    slot_dev->route_string =
        route_string;

    /*
     * parent_slot/parent_port remain software topology.
     *
     * tt_slot/tt_port describe the hardware split-transaction
     * domain required by xHCI Slot Context DW2.
     */
    if(!xhci_resolve_tt(
           speed,
           parent_slot,
           parent_port,
           &slot_dev->tt_slot,
           &slot_dev->tt_port,
           &slot_dev->tt_multi))
    {
        xhci_unpublish_slot_device(
            slot,
            parent_slot,
            parent_port);

        return false;
    }


    static const uint8_t get_device_descriptor[8] = {
        0x80U, XHCI_SETUP_GET_DESCRIPTOR, 0x00U, XHCI_DESCRIPTOR_DEVICE,
        0x00U, 0x00U, XHCI_DESCRIPTOR_DEVICE_LENGTH, 0x00U

    /* V3.2 Slot Table mirror completed */
};
    static const uint8_t get_configuration_descriptor[8] = {
        0x80U, XHCI_SETUP_GET_DESCRIPTOR, 0x00U, XHCI_DESCRIPTOR_CONFIGURATION,
        0x00U, 0x00U, 0xFFU, 0x00U
    };
    uint8_t set_configuration[8] = {0};
    uint8_t set_interface[8] = {0};
    if (!xhci_prepare_device_resources(state, slot, port, speed, root_port,
                                        parent_slot, parent_port,
                                        slot_dev->tt_slot,
                                        slot_dev->tt_port,
                                        slot_dev->tt_multi,
                                        route_string) ||
        !xhci_submit_command(state, XHCI_ADDRESS_DEVICE_TYPE, slot,
                             xhci_dma_address(&state->input_context.mapping), 0)) {
        if (g_xhci_error == 0U) g_xhci_error = 55U;
        do {
        xhci_unpublish_slot_device(
            slot,
            parent_slot,
            parent_port);
        return false;
    } while (0);
    }
    if (!xhci_submit_control_transfer_device(state, &state->device,  get_device_descriptor,
                                      XHCI_DESCRIPTOR_DEVICE_LENGTH, true)) {
        do {
        xhci_unpublish_slot_device(
            slot,
            parent_slot,
            parent_port);
        return false;
    } while (0);
    }
    uint8_t *descriptor = (uint8_t *)state->descriptor_buffer.cpu;
    if (descriptor[0] < XHCI_DESCRIPTOR_DEVICE_LENGTH ||
        descriptor[1] != XHCI_DESCRIPTOR_DEVICE) {
        g_xhci_error = 56U;
        do {
        xhci_unpublish_slot_device(
            slot,
            parent_slot,
            parent_port);
        return false;
    } while (0);
    }
    g_xhci_usb_enumerated = true;
    if (!xhci_submit_control_transfer_device(state, &state->device,  get_configuration_descriptor,
                                      0xFFU, true) ||
        !xhci_parse_configuration(state)) {
        g_xhci_error = 57U;
        do {
        xhci_unpublish_slot_device(
            slot,
            parent_slot,
            parent_port);
        return false;
    } while (0);
    }
    set_configuration[0] = 0x00U;
    set_configuration[1] = XHCI_SETUP_SET_CONFIGURATION;
    set_configuration[2] = state->configuration_value;
    if (!xhci_submit_control_transfer_device(state, &state->device,  set_configuration, 0U, false)) {
        g_xhci_error = 58U;
        do {
        xhci_unpublish_slot_device(
            slot,
            parent_slot,
            parent_port);
        return false;
    } while (0);
    }
    /* Hub 第一阶段只完成类识别和 Hub 描述符读取；下游端口的
     * route string、slot/context 隔离以及端口事件处理在后续阶段接入。 */
    if (state->hub_interface_present) {
        if (!xhci_read_hub_descriptor(state)) do {
        xhci_unpublish_slot_device(
            slot,
            parent_slot,
            parent_port);
        return false;
    } while (0);
        if (state->hub_endpoint != 0U && !xhci_configure_hub_endpoint(state)) {
            if (g_xhci_error == 0U) g_xhci_error = 68U;
            do {
        xhci_unpublish_slot_device(
            slot,
            parent_slot,
            parent_port);
        return false;
    } while (0);
        }
        g_xhci_usb_hub = true;
        g_xhci_usb_hub_ports = state->hub_port_count;
    } else if (state->bt_event_endpoint != 0U) {
        if (!xhci_configure_bt_endpoints(state)) {
            if (g_xhci_error == 0U) g_xhci_error = 65U;
            do {
        xhci_unpublish_slot_device(
            slot,
            parent_slot,
            parent_port);
        return false;
    } while (0);
        }
        g_xhci_usb_bluetooth = true;
    } else if (state->audio_endpoint != 0U) {
        /* USB Audio 的等时端点通常位于 alternate setting 1，
         * 只有切换接口后设备才会真正打开数据带宽。 */
        set_interface[0] = 0x01U;
        set_interface[1] = XHCI_SETUP_SET_INTERFACE;
        set_interface[2] = state->audio_alt_setting;
        set_interface[4] = state->audio_interface;
        if (!xhci_submit_control_transfer_device(state, &state->device,  set_interface, 0U, false)) {
            g_xhci_error = 59U;
            do {
        xhci_unpublish_slot_device(
            slot,
            parent_slot,
            parent_port);
        return false;
    } while (0);
        }
    }
    if (state->hid_endpoint != 0U) {
        uint8_t set_protocol[8] = {
            0x21U, USB_HID_SET_PROTOCOL, USB_HID_PROTOCOL_BOOT, 0x00U,
            state->hid_interface, 0x00U, 0x00U, 0x00U,
        };
        /* A Boot-subclass interface may currently be in report protocol.
         * Select Boot protocol before arming its fixed-format interrupt TRB. */
        if (!xhci_submit_control_transfer_device(state, &state->device,  set_protocol, 0U, false)) {
            g_xhci_error = 59U;
            do {
        xhci_unpublish_slot_device(
            slot,
            parent_slot,
            parent_port);
        return false;
    } while (0);
        }
        if (!xhci_configure_hid_endpoint(state)) {
            if (g_xhci_error == 0U) g_xhci_error = 59U;
            do {
        xhci_unpublish_slot_device(
            slot,
            parent_slot,
            parent_port);
        return false;
    } while (0);
        }
        g_xhci_usb_hid = true;
        if (state->hid_protocol == USB_HID_PROTOCOL_MOUSE) g_xhci_usb_mouse = true;
    } else if (state->audio_endpoint != 0U) {
        if (!xhci_configure_audio_endpoint(state)) {
            if (g_xhci_error == 0U) g_xhci_error = 63U;
            do {
        xhci_unpublish_slot_device(
            slot,
            parent_slot,
            parent_port);
        return false;
    } while (0);
        }
        g_xhci_usb_audio = true;
    } else if (state->bt_event_endpoint != 0U) {
        /* Bluetooth 设备已经在上面的多端点配置路径中完成初始化。 */
    } else if (state->hub_configured) {
        /* Hub 第一阶段没有供内核数据面使用的普通数据端点。 */
    } else {
        if (g_xhci_error == 0U) g_xhci_error = 59U;
        do {
        xhci_unpublish_slot_device(
            slot,
            parent_slot,
            parent_port);
        return false;
    } while (0);
    }


return true;
}

static bool xhci_initialize(xhci_state_t *state, const pci_device_t *pci) {
    if (state == 0 || pci == 0 || state->initialized) return false;
    for (size_t i = 0; i < sizeof(*state); ++i) ((uint8_t *)state)[i] = 0;
    atomic_init(&state->event_lock.state, 0U);
    state->pci = pci;
    if (pci_enable_memory_busmaster((pci_device_t *)pci) != K_OK ||
        !xhci_map_mmio(state)) {
        g_xhci_error = 20U;
        return false;
    }
    uint32_t capability = xhci_read32(state, 0);
    uint8_t cap_length = (uint8_t)(capability & 0xFFU);
    uint32_t hcs_params1 = xhci_read32(state, 0x04U);
    uint32_t hcc_params1 = xhci_read32(state, 0x10U);
    uint32_t doorbell_offset = xhci_read32(state, 0x14U) & ~3U;
    uint32_t runtime_offset = xhci_read32(state, 0x18U) & ~31U;
    state->operational_offset = cap_length;
    state->doorbell_offset = doorbell_offset;
    state->runtime_offset = runtime_offset;
    state->max_slots = hcs_params1 & 0xFFU;
    state->max_ports = (hcs_params1 >> 24) & 0xFFU;
    state->context_size = (hcc_params1 & (1U << 2)) != 0U ? 64U : 32U;
    if (cap_length < 0x20U || state->max_slots == 0U ||
        state->max_ports == 0U ||
        doorbell_offset >= state->mmio_span || runtime_offset >= state->mmio_span ||
        state->operational_offset + XHCI_CONFIG + sizeof(uint32_t) > state->mmio_span ||
        state->doorbell_offset + sizeof(uint32_t) > state->mmio_span ||
        state->runtime_offset + XHCI_RUNTIME_INTR0 + XHCI_RUNTIME_ERDP +
            sizeof(uint64_t) > state->mmio_span) {
        g_xhci_error = 21U;
        xhci_unmap_mmio(state);
        return false;
    }
    if (state->max_slots > 255U) state->max_slots = 255U;
    if (!xhci_reset(state) || !xhci_setup_rings(state)) {
        g_xhci_error = 22U;
        xhci_free_rings(state);
        xhci_unmap_mmio(state);
        return false;
    }
    state->event_index = 0;
    state->event_cycle = 1U;
    state->command_index = 0U;
    state->command_cycle = 1U;
    state->initialized = true;
    return true;
}

/*
 * V3.10.6B9E-FIX2 DESTROY ORDER
 *
 * xHCI commands require the controller command ring to be running.
 *
 * Therefore the teardown order is:
 *
 *     stop/disable/free every device Slot
 *                  |
 *                  v
 *             halt controller
 *                  |
 *                  v
 *             release rings/MMIO
 *
 * Never halt the controller before Disable Slot.
 *
 * If destroy() is cleaning up an earlier failure, preserve that
 * original diagnostic instead of replacing it with a cleanup error.
 */
static bool xhci_destroy(
    xhci_state_t *state)
{
    if(state == 0)
    {
        return false;
    }


    uint32_t original_error =
        g_xhci_error;

    bool released =
        true;


    g_xhci_runtime_ready =
        false;

    g_xhci_runtime_event_batches =
        0U;


    /*
     * Runtime IRQ delivery is no longer needed.
     *
     * Synchronous xHCI commands below consume Command Completion
     * Events directly from the Event Ring.
     */
    xhci_unbind_msix(
        state);


    /*
     * DEVICE/SLOT TEARDOWN FIRST.
     *
     * Stop Endpoint and Disable Slot are xHCI commands and cannot
     * complete after USBCMD.RUN has been cleared.
     */
    if(!xhci_free_slot_resources(
           state))
    {
        released =
            false;
    }


    /*
     * All device DMA ownership has ended.
     * The controller can now be halted safely.
     */
    if(state->mmio != 0)
    {
        if(!xhci_write32(
               state,
               state->operational_offset +
                   XHCI_USBCMD,
               0U))
        {
            released =
                false;
        }
        else
        {
            bool halted =
                false;


            for(uint32_t spin = 0U;
                spin < 10000U;
                ++spin)
            {
                if((xhci_read32(
                        state,
                        state->operational_offset +
                            XHCI_USBSTS) &
                    XHCI_USBSTS_HCH) != 0U)
                {
                    halted =
                        true;

                    break;
                }


                __asm__ volatile (
                    "pause");
            }


            if(!halted)
            {
                released =
                    false;
            }
        }
    }


    if(!xhci_free_rings(
           state))
    {
        released =
            false;
    }


    xhci_zero_device_context(
        &state->device);

    xhci_clear_device_flags();


    xhci_unmap_mmio(
        state);


    state->initialized =
        false;

    state->pci =
        0;


    /*
     * Cleanup commands normally set g_xhci_error back to zero.
     *
     * If destroy() was entered because something else had already
     * failed, that first error is the useful diagnostic.
     */
    if(original_error != 0U)
    {
        g_xhci_error =
            original_error;
    }


    return released;
}

bool xhci_hardware_present(void) {
    return g_xhci_present;
}

bool xhci_hardware_self_test(void) {
    /* V3.10.3D1 SELF TEST ACTIVATION INLINED
     * No self-test activation helper remained after V3.10.3C.
     */

    const pci_host_t *host = pci_current_host();
    const pci_device_t *pci = host == 0 ? 0 : pci_find_class(host,
        XHCI_CLASS_SERIAL_BUS, XHCI_SUBCLASS_USB, XHCI_PROG_IF);
    g_xhci_present = pci != 0;
    g_xhci_usb_device_count = 0U;
    xhci_clear_device_flags();
    g_xhci_usb_hub_present = false;
    g_xhci_usb_hub_inventory_ports = 0U;
    g_xhci_usb_hub_downstream = false;
    g_xhci_runtime_ready = false;
    atomic_init(&g_xhci_work_queued, false);
    atomic_init(&g_xhci_irq_pending, false);
    atomic_init(&g_xhci_input_seen, false);
    atomic_init(&g_xhci_mouse_input_seen, false);
    atomic_init(&g_xhci_irq_seen, false);
    atomic_init(&g_xhci_hid_transfer_seen, false);
    atomic_init(&g_xhci_hid_completion_count, 0U);
    atomic_init(&g_xhci_hid_completion_milestone, 0U);
    if (pci == 0) return true;
    g_xhci_error = 0;
    if (!xhci_initialize(&g_xhci, pci)) return false;
    uint8_t selected_slot = 0U;
    bool has_device =
        xhci_probe_connected_ports(
            &g_xhci,
            &selected_slot);
    if (!has_device && g_xhci_error != 0U) {
        xhci_destroy(&g_xhci);
        return false;
    }
    uint8_t slot = 0;
    xhci_device_context_t *self_test_device = 0;
    bool keep_controller = false;
    bool success;
    if(has_device)
    {
        success =
            false;

        if(selected_slot != 0U)
        {
            xhci_slot_device_t *slot_dev =
                &g_xhci_slot_devices[
                    selected_slot];

            if(slot_dev->used &&
               slot_dev->context.device_slot ==
                   selected_slot)
            {
                /*
                 * V3.10.6B8C DIRECT SELF-TEST SLOT
                 *
                 * selected_slot already names the permanent
                 * canonical context.
                 */
                self_test_device =
                    &slot_dev->context;

                xhci_recompute_topology(
                    &g_xhci);

                success =
                    true;
            }
        }

        if(!success)
        {
            g_xhci_error =
                69U;
        }
    } else {
        success = xhci_submit_command(&g_xhci, XHCI_COMMAND_RING_TYPE, 0, 0, &slot) &&
                  slot != 0U;
    }
    uint32_t saved_error = success ? 0U : g_xhci_error;
    if (success && has_device) {
        if (!xhci_reenumerate_self_test(
                &g_xhci,
                self_test_device)) {
            saved_error = g_xhci_error;
            success = false;
        } else {
            keep_controller = true;
        }
    }
    if (success && keep_controller) {
        xhci_recompute_topology(&g_xhci);
        /* Runtime input is interrupt-only.  Do not silently fall back to the
         * old timer poll path if MSI-X cannot be routed. */
        g_xhci_runtime_ready = true;
        if (!xhci_bind_msix(&g_xhci)) {
            g_xhci_runtime_ready = false;
            g_xhci_error = 70U;
            liteos_serial_write("LITEOS_XHCI_MSIX_FAIL\r\n");
            success = false;
            keep_controller = false;
        } else {
            liteos_serial_write("LITEOS_XHCI_MSIX_OK\r\n");
            /* Count only post-MSI-X runtime HID completions. */
            atomic_store_explicit(&g_xhci_hid_completion_count, 0U,
                                  memory_order_release);
            atomic_store_explicit(&g_xhci_hid_completion_milestone, 0U,
                                  memory_order_release);
            /* Enumeration can complete a HID TRB before MSI-X is bound.  A
             * single init-time deferred drain arms the first report; all
             * subsequent runtime work is driven by MSI-X, never by a timer. */
            (void)xhci_schedule_deferred_work();
        }
    }
    if (slot != 0U && !keep_controller &&
        !xhci_submit_command(&g_xhci, XHCI_DISABLE_SLOT_TYPE, slot, 0, 0)) {
        if (success) saved_error = g_xhci_error;
        success = false;
    }
    if (!success && saved_error == 0U) saved_error = g_xhci_error != 0U ? g_xhci_error : 23U;
    if (!success) g_xhci_error = saved_error;
    if (!success) g_xhci_runtime_ready = false;
    if (!success || !keep_controller) xhci_destroy(&g_xhci);
    return success;
}

bool xhci_usb_device_enumerated(void) {
    return g_xhci_usb_enumerated;
}

uint32_t xhci_usb_device_count(void) {
    return g_xhci_usb_device_count;
}

bool xhci_usb_hid_configured(void) {
    return g_xhci_usb_hid;
}

bool xhci_usb_mouse_configured(void) {
    return g_xhci_usb_mouse;
}

bool xhci_usb_audio_configured(void) {
    return g_xhci_usb_audio;
}

bool xhci_usb_hub_configured(void) {
    return g_xhci_usb_hub_present;
}

uint8_t xhci_usb_hub_port_count(void) {
    return g_xhci_usb_hub_inventory_ports;
}

bool xhci_usb_hub_downstream_configured(void) {
    return g_xhci_usb_hub_downstream;
}

bool xhci_usb_bluetooth_configured(void) {
    return g_xhci_usb_bluetooth;
}

/*
 * V3.8.6 AUDIO UAPI SLOT OWNER
 *
 * Audio UAPI never assumes that the Audio device occupies
 * g_xhci.device.
 *
 * The Slot ID is cached after first resolution.  Normal UAPI
 * calls are therefore O(1).  A Slot Table scan is used only when
 * the cache is empty or stale.
 */
/*
 * V3.10.6B8G DIRECT AUDIO SLOT CONTEXT
 *
 * Runtime Audio ownership is always:
 *
 *     g_xhci_audio_slot -> Slot.context
 *
 * The Slot cache provides the O(1) steady-state path. A Slot Table
 * scan is used only when the cache is empty or stale.
 */
static xhci_device_context_t *
xhci_audio_context(
    xhci_state_t *state)
{
    if(state == 0 ||
       !state->initialized)
    {
        return 0;
    }


    /*
     * O(1) steady-state path.
     */
    if(g_xhci_audio_slot != 0U)
    {
        xhci_slot_device_t *slot_dev =
            &g_xhci_slot_devices[
                g_xhci_audio_slot];


        if(slot_dev->used &&
           slot_dev->context.device_slot ==
               g_xhci_audio_slot &&
           slot_dev->context.audio_endpoint !=
               0U)
        {
            return
                &slot_dev->context;
        }


        /*
         * Device was unplugged or Slot was reused.
         */
        g_xhci_audio_slot =
            0U;
    }


    /*
     * Slow discovery path.
     */
    uint32_t limit =
        state->max_slots;


    if(limit >=
       XHCI_MAX_SLOT_TABLE)
    {
        limit =
            XHCI_MAX_SLOT_TABLE -
            1U;
    }


    for(uint32_t slot = 1U;
        slot <= limit;
        ++slot)
    {
        xhci_slot_device_t *slot_dev =
            &g_xhci_slot_devices[
                slot];


        if(!slot_dev->used ||
           slot_dev->context.device_slot !=
               (uint8_t)slot ||
           slot_dev->context.audio_endpoint ==
               0U)
        {
            continue;
        }


        g_xhci_audio_slot =
            (uint8_t)slot;


        return
            &slot_dev->context;
    }


    return 0;
}



/*
 * V3.10.6B8E AUDIO CANONICAL UAPI
 *
 * xhci_audio_context_commit() removed.
 *
 * Audio UAPI mutates the canonical Slot.context directly;
 * there is no secondary context to commit or synchronize.
 */



/*
 * xhci_queue_audio_transfer() still consumes state->audio_*.
 *
 * Adapt an inactive canonical Slot context to that old ABI only
 * for the duration of the doorbell operation.
 */
/*
 * V3.10.4B DIRECT AUDIO OWNER
 *
 * Published Audio runtime state lives permanently in the supplied
 * device context.
 *
 * No Slot.context -> state->device -> Slot.context adaptation is
 * required for queue submission anymore.
 */
/*
 * V3.10.6B8F DIRECT AUDIO QUEUE
 *
 * xhci_queue_audio_owner() removed.
 *
 * Audio UAPI already owns the canonical Slot.context pointer and
 * submits directly through xhci_queue_audio_transfer_device().
 */



uint32_t
xhci_usb_audio_completed(void)
{
    if(!g_xhci.initialized ||
       !g_xhci_usb_audio)
    {
        return 0U;
    }


    xhci_device_context_t *device =
        xhci_audio_context(
            &g_xhci);


    return
        device != 0
        ? device->audio_completed
        : 0U;
}


struct device *
xhci_audio_device(void)
{
    return
        g_xhci.initialized &&
        g_xhci_usb_audio &&
        g_xhci.pci != 0
        ? (struct device *)
            &g_xhci.pci->device
        : 0;
}


static void
xhci_audio_lock(void)
{
    while(atomic_exchange_explicit(
              &g_xhci.event_lock.state,
              1U,
              memory_order_acquire) !=
          0U)
    {
        __asm__ volatile(
            "pause");
    }
}


static void
xhci_audio_unlock(void)
{
    atomic_store_explicit(
        &g_xhci.event_lock.state,
        0U,
        memory_order_release);
}


static bool
xhci_audio_format_supported(
    const xhci_device_context_t *device,
    const audio_format_t *format)
{
    uint32_t sample_bits;


    if(device == 0 ||
       format == 0 ||
       format->channels !=
           device->audio_channels ||
       format->sample_rate !=
           device->audio_sample_rate)
    {
        return false;
    }


    switch(format->sample_format)
    {
        case AUDIO_SAMPLE_S16_LE:
            sample_bits = 16U;
            break;

        case AUDIO_SAMPLE_S24_LE:
            sample_bits = 24U;
            break;

        case AUDIO_SAMPLE_S32_LE:
            sample_bits = 32U;
            break;

        default:
            return false;
    }


    return
        sample_bits ==
        device->
            audio_bit_resolution;
}


kstatus_t
xhci_audio_stream_configure(
    struct audio_stream *stream)
{
    audio_stream_t *audio =
        (audio_stream_t *)stream;

    audio_format_t format;


    if(audio == 0)
    {
        return K_EINVAL;
    }


    if(!g_xhci.initialized ||
       !g_xhci_usb_audio ||
       audio_stream_device(audio) !=
           xhci_audio_device())
    {
        return K_ENOENT;
    }


    audio_stream_get_format(
        audio,
        &format);


    xhci_audio_lock();


    xhci_device_context_t *device =
        xhci_audio_context(
            &g_xhci);


    if(device == 0)
    {
        xhci_audio_unlock();
        return K_ENOENT;
    }


    if(audio_stream_direction(audio) !=
           (device->audio_endpoint_in
                ? AUDIO_CAPTURE
                : AUDIO_PLAYBACK) ||
       !xhci_audio_format_supported(
           device,
           &format) ||
       audio_stream_period_bytes(audio) >
           PAGE_SIZE)
    {
        xhci_audio_unlock();
        return K_EINVAL;
    }


    if(device->audio_stream != 0 &&
       device->audio_stream != audio)
    {
        xhci_audio_unlock();
        return K_EBUSY;
    }


    device->audio_stream =
        audio;

    device->audio_stream_bound =
        true;

    device->audio_stream_running =
        false;

    device->audio_stream_queued =
        false;

    device->audio_period =
        0U;

    device->audio_frames =
        0U;




    xhci_audio_unlock();

    return K_OK;
}


kstatus_t
xhci_audio_stream_start(
    struct audio_stream *stream)
{
    audio_stream_t *audio =
        (audio_stream_t *)stream;

    bool success =
        true;


    if(audio == 0)
    {
        return K_EINVAL;
    }


    if(!g_xhci.initialized ||
       !g_xhci_usb_audio)
    {
        return K_ENOENT;
    }


    xhci_audio_lock();


    xhci_device_context_t *device =
        xhci_audio_context(
            &g_xhci);


    if(device == 0 ||
       device->audio_stream != audio ||
       !device->audio_stream_bound)
    {
        xhci_audio_unlock();
        return K_ENOENT;
    }


    device->audio_stream_running =
        true;


    if(device->audio_stream_queued &&
       !device->audio_transfer_pending)
    {
        success =
            xhci_queue_audio_transfer_device(
                &g_xhci,
                device);


        if(!success)
        {
            device->
                audio_stream_running =
                    false;
        }
    }




    xhci_audio_unlock();


    return
        success
        ? K_OK
        : K_EIO;
}


kstatus_t
xhci_audio_stream_stop(
    struct audio_stream *stream)
{
    audio_stream_t *audio =
        (audio_stream_t *)stream;


    if(audio == 0)
    {
        return K_EINVAL;
    }


    if(!g_xhci.initialized ||
       !g_xhci_usb_audio)
    {
        return K_ENOENT;
    }


    xhci_audio_lock();


    xhci_device_context_t *device =
        xhci_audio_context(
            &g_xhci);


    if(device == 0 ||
       device->audio_stream != audio ||
       !device->audio_stream_bound)
    {
        xhci_audio_unlock();
        return K_ENOENT;
    }


    device->audio_stream_running =
        false;


    if(!device->
           audio_transfer_pending)
    {
        device->audio_stream_queued =
            false;
    }




    xhci_audio_unlock();

    return K_OK;
}


kstatus_t
xhci_audio_stream_queue(
    struct audio_stream *stream,
    uint32_t period,
    uint32_t frames)
{
    audio_stream_t *audio =
        (audio_stream_t *)stream;

    audio_format_t format;

    bool success =
        true;


    if(audio == 0 ||
       frames == 0U)
    {
        return K_EINVAL;
    }


    if(!g_xhci.initialized ||
       !g_xhci_usb_audio)
    {
        return K_ENOENT;
    }


    audio_stream_get_format(
        audio,
        &format);


    xhci_audio_lock();


    xhci_device_context_t *device =
        xhci_audio_context(
            &g_xhci);


    if(device == 0 ||
       device->audio_stream != audio ||
       !device->audio_stream_bound)
    {
        xhci_audio_unlock();
        return K_ENOENT;
    }


    if(device->audio_stream_queued ||
       device->audio_transfer_pending)
    {
        xhci_audio_unlock();
        return K_EBUSY;
    }


    if(period >=
           format.period_count ||
       frames >
           format.period_frames)
    {
        xhci_audio_unlock();
        return K_EINVAL;
    }


    uint64_t bytes =
        audio_stream_bytes_for_frames(
            audio,
            frames);


    if(bytes == 0U ||
       bytes > PAGE_SIZE)
    {
        xhci_audio_unlock();
        return K_EINVAL;
    }


    device->audio_period =
        period;

    device->audio_frames =
        frames;

    device->audio_stream_queued =
        true;


    if(device->audio_stream_running)
    {
        success =
            xhci_queue_audio_transfer_device(
                &g_xhci,
                device);


        if(!success)
        {
            device->
                audio_stream_queued =
                    false;
        }
    }




    xhci_audio_unlock();


    return
        success
        ? K_OK
        : K_EIO;
}


kstatus_t
xhci_audio_stream_reset(
    struct audio_stream *stream)
{
    audio_stream_t *audio =
        (audio_stream_t *)stream;


    if(audio == 0)
    {
        return K_EINVAL;
    }


    if(!g_xhci.initialized ||
       !g_xhci_usb_audio)
    {
        return K_ENOENT;
    }


    xhci_audio_lock();


    xhci_device_context_t *device =
        xhci_audio_context(
            &g_xhci);


    if(device == 0 ||
       device->audio_stream != audio ||
       !device->audio_stream_bound)
    {
        xhci_audio_unlock();
        return K_ENOENT;
    }


    device->audio_stream_running =
        false;

    device->audio_stream_queued =
        false;

    device->audio_period =
        0U;

    device->audio_frames =
        0U;




    xhci_audio_unlock();

    return K_OK;
}


kstatus_t
xhci_audio_stream_disconnect(
    struct audio_stream *stream)
{
    audio_stream_t *audio =
        (audio_stream_t *)stream;


    if(audio == 0)
    {
        return K_EINVAL;
    }


    if(!g_xhci.initialized ||
       !g_xhci_usb_audio)
    {
        return K_ENOENT;
    }


    xhci_audio_lock();


    xhci_device_context_t *device =
        xhci_audio_context(
            &g_xhci);


    if(device == 0 ||
       device->audio_stream != audio)
    {
        xhci_audio_unlock();
        return K_ENOENT;
    }


    device->audio_stream =
        0;

    device->audio_stream_running =
        false;

    device->audio_stream_queued =
        false;


    /*
     * Keep bound set until any already posted Transfer Event has
     * been consumed.  This preserves the previous behavior and
     * prevents the autonomous self-test queue from restarting.
     */
    device->audio_stream_bound =
        true;




    xhci_audio_unlock();

    return K_OK;
}


bool xhci_process_events(uint32_t budget) {
    bool consumed;
    if (budget == 0U) budget = 1U;
    if (!g_xhci_runtime_ready) return false;
    ++g_xhci_runtime_event_batches;
    if (g_xhci_runtime_event_batches == 1U) {
        liteos_serial_write("LITEOS_USB_RUNTIME_IRQ_OK\r\n");
    }
    /* 该函数会在 LAPIC 定时器中断中调用；抢不到锁时直接延后本轮。 */
    /*
     * Runtime callers are the coalesced MSI-X worker, never a LAPIC timer
     * polling path.  If another worker is already draining the ring it owns
     * the pending completions and this invocation can simply return.
     */
    if (atomic_exchange_explicit(&g_xhci.event_lock.state, 1U,
                                 memory_order_acquire) != 0U) return false;
    consumed = xhci_process_event_ring(&g_xhci, budget);
    xhci_event_handler_complete(&g_xhci);
    /*
     * 根口状态由事件环每轮处理；Hub 没有使用中断状态端点时才做周期
     * GET_STATUS。每 32 轮查询一次，避免一次 deferred work 同步等待
     * Hub 的全部端口而长期占用用户态系统调用返回路径。
     */
    atomic_store_explicit(&g_xhci.event_lock.state, 0U, memory_order_release);
    return consumed;
}

bool xhci_schedule_deferred_work(void) {
    bool expected = false;
    if (!g_xhci_runtime_ready ||
        !atomic_compare_exchange_strong_explicit(&g_xhci_work_queued, &expected, true,
                                                 memory_order_acq_rel,
                                                 memory_order_acquire)) return false;
    if (!deferred_try_schedule(xhci_deferred_work, 0)) {
        /*
         * IMAN.IP has already been acknowledged.  Do not lose this sole
         * interrupt-IN wakeup merely because ordinary deferred work is full:
         * retain the coalesced xHCI worker in the reserved critical slot.
         * This remains MSI-X driven; the LAPIC timer never polls xHCI.
         */
        if (!deferred_schedule_critical(xhci_deferred_work, 0)) {
            atomic_store_explicit(&g_xhci_work_queued, false,
                                  memory_order_release);
            return false;
        }
    }
    return true;
}

void xhci_deferred_work(void *argument) {
    bool consumed = false;
    bool pending = false;
    uint32_t pass = 0U;
    (void)argument;
    /* Consume the interrupt which caused this work item before draining the
     * ring.  The previous code tested this same bit only at the end, so the
     * interrupt that scheduled the item was mistaken for a new interrupt and
     * the worker continuously re-queued itself even with an empty ring. */
    (void)atomic_exchange_explicit(&g_xhci_irq_pending, false,
                                   memory_order_acq_rel);
    do {
        consumed = xhci_process_events(64U);
        ++pass;
    } while (consumed && pass < 8U);
    xhci_report_hid_completion_milestones();
    atomic_store_explicit(&g_xhci_work_queued, false, memory_order_release);
    pending = xhci_event_pending(&g_xhci);
    (void)atomic_exchange_explicit(&g_xhci_irq_pending, false,
                                   memory_order_acq_rel);
    /* An IRQ can be raised by QEMU while IP/ERDP is being acknowledged even
     * though the event ring has no new TRB.  Re-queueing solely because an IRQ
     * flag was observed creates an endless deferred-work loop and starves the
     * user input waiter.  A follow-up is needed only when a real event is
     * visible; a later genuine IRQ will schedule the worker again. */
    if (pending) {
        (void)xhci_schedule_deferred_work();
    }
}

static void xhci_report_hid_completion_milestones(void) {
    uint32_t completed = atomic_load_explicit(&g_xhci_hid_completion_count,
                                              memory_order_acquire);
    unsigned target = completed >= XHCI_RING_TRB_COUNT * 2U ? 2U :
                      completed >= XHCI_RING_TRB_COUNT ? 1U : 0U;
    unsigned observed = atomic_load_explicit(&g_xhci_hid_completion_milestone,
                                             memory_order_acquire);
    while (observed < target) {
        unsigned next = observed + 1U;
        if (!atomic_compare_exchange_weak_explicit(&g_xhci_hid_completion_milestone,
                                                   &observed, next,
                                                   memory_order_acq_rel,
                                                   memory_order_acquire)) {
            continue;
        }
        if (next == 1U) {
            liteos_serial_write("LITEOS_XHCI_HID_EVENTS_256\r\n");
        } else if (next == 2U) {
            liteos_serial_write("LITEOS_XHCI_HID_EVENTS_512\r\n");
        }
    }
}

uint32_t xhci_last_error(void) {
    return g_xhci_error;
}
