#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-.}"
PKG_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET_REL="kernel/drivers/xhci.c"
TARGET="$ROOT/$TARGET_REL"
FIXED="$PKG_DIR/xhci.c.B10B_hotplug_FINAL.fixed"
OLD_BLOB="87cb66d92058744e1f2746400ae80c67cf425d35"
NEW_BLOB="80f9926586d1fca33b6209e95b2311809b30e096"

if [[ ! -f "$TARGET" ]]; then
    echo "ERROR: $TARGET not found" >&2
    exit 1
fi
if [[ ! -f "$FIXED" ]]; then
    echo "ERROR: $FIXED not found" >&2
    exit 1
fi

CURRENT_BLOB="$(git -C "$ROOT" hash-object "$TARGET_REL")"
if [[ "$CURRENT_BLOB" == "$NEW_BLOB" ]]; then
    echo "PASS: xhci hotplug final fix is already installed"
    exit 0
fi
if [[ "$CURRENT_BLOB" != "$OLD_BLOB" ]]; then
    echo "ERROR: current xhci.c does not match the expected source" >&2
    echo "expected: $OLD_BLOB" >&2
    echo "current : $CURRENT_BLOB" >&2
    echo "No file was changed." >&2
    exit 2
fi

BACKUP="$TARGET.before-b10b-hotplug-final"
cp -f "$TARGET" "$BACKUP"
cp -f "$FIXED" "$TARGET"

INSTALLED_BLOB="$(git -C "$ROOT" hash-object "$TARGET_REL")"
if [[ "$INSTALLED_BLOB" != "$NEW_BLOB" ]]; then
    cp -f "$BACKUP" "$TARGET"
    echo "ERROR: installed file hash mismatch; original restored" >&2
    exit 3
fi

git -C "$ROOT" diff --check -- "$TARGET_REL"

echo "PASS: installed LiteOS xHCI B10B hotplug final fix"
echo "backup: $BACKUP"
echo "blob  : $INSTALLED_BLOB"
