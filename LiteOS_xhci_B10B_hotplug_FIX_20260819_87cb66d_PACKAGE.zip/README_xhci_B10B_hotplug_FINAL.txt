LiteOS xHCI B10B Hotplug Final Fix
===================================
Target: kernel/drivers/xhci.c
Expected original Git blob:
87cb66d92058744e1f2746400ae80c67cf425d35
Patched Git blob:
80f9926586d1fca33b6209e95b2311809b30e096

Recommended install (does not use git apply):
  unzip LiteOS_xhci_B10B_hotplug_FIX_20260819_87cb66d_PACKAGE.zip -d /tmp/xhci-fix
  cd ~/LiteOS
  /tmp/xhci-fix/apply_xhci_B10B_hotplug_FINAL.sh .

Patch install alternative:
  cd ~/LiteOS
  git apply --check /tmp/xhci-fix/LiteOS_xhci_B10B_hotplug_FIX_20260819_87cb66d.patch
  git apply /tmp/xhci-fix/LiteOS_xhci_B10B_hotplug_FIX_20260819_87cb66d.patch

Verify:
  git hash-object kernel/drivers/xhci.c
Expected:
  80f9926586d1fca33b6209e95b2311809b30e096
